// Inver Local AI — встроенная нейросеть без установки и командной строки.
// При первом запросе Inver сам скачивает движок llama.cpp (llama-server) и небольшую модель Qwen 2.5,
// распаковывает их в папку программы и запускает на 127.0.0.1. Дальше работает без интернета.
const { app, net } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn, execFile } = require('child_process');
const http = require('http');

const MODELS = {
  light: { name: 'Лёгкая', file: 'qwen2.5-1.5b-instruct-q4_k_m.gguf', repo: 'Qwen/Qwen2.5-1.5B-Instruct-GGUF', size: 1.12e9 },
  smart: { name: 'Умнее', file: 'qwen2.5-3b-instruct-q4_k_m.gguf', repo: 'Qwen/Qwen2.5-3B-Instruct-GGUF', size: 2.1e9 }
};
const HF_HOSTS = ['https://huggingface.co', 'https://hf-mirror.com'];
let PORT = 0; // выбирается свободный при каждом запуске, чтобы не попасть в зависший старый движок

let state = { phase: 'idle', progress: 0, text: '', error: '' }; // idle | downloading | starting | ready | error
let proc = null, ses = null, onState = () => {}, busy = null, currentModel = null;

// Движок llama.cpp на Windows не открывает файлы, если в пути есть русские буквы (например, имя пользователя).
// Поэтому храним нейросеть в папке с латинским путём и переносим туда уже скачанное.
let rootDir = null;
const ascii = (p) => /^[\x20-\x7e]*$/.test(p);
function writable(dir) {
  try { fs.mkdirSync(dir, { recursive: true }); const t = path.join(dir, '.w'); fs.writeFileSync(t, '1'); fs.unlinkSync(t); return true; } catch (e) { return false; }
}
function moveDir(from, to) {
  if (!fs.existsSync(from)) return;
  fs.mkdirSync(path.dirname(to), { recursive: true });
  try { fs.renameSync(from, to); return; } catch (e) {}
  try { fs.cpSync(from, to, { recursive: true }); fs.rmSync(from, { recursive: true, force: true }); } catch (e) {}
}
function root() {
  if (rootDir) return rootDir;
  const legacy = path.join(app.getPath('userData'), 'ai');
  const options = [legacy, path.join(process.env.ProgramData || 'C:\\ProgramData', 'InverAI'), path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'InverAI'), 'C:\\InverAI'];
  rootDir = options.find((d) => ascii(d) && writable(d)) || legacy;
  if (rootDir !== legacy && fs.existsSync(legacy)) {
    ['bin', 'models'].forEach((sub) => { if (!fs.existsSync(path.join(rootDir, sub))) moveDir(path.join(legacy, sub), path.join(rootDir, sub)); });
  }
  return rootDir;
}
const binDir = () => path.join(root(), 'bin');
const modelPath = (key) => path.join(root(), 'models', MODELS[key].file);

function set(patch) { state = Object.assign({}, state, patch); try { onState(state); } catch (e) {} }

function findFile(dir, name) {
  if (!fs.existsSync(dir)) return null;
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, ent.name);
    if (ent.isFile() && ent.name.toLowerCase() === name) return p;
    if (ent.isDirectory()) { const f = findFile(p, name); if (f) return f; }
  }
  return null;
}
const serverExe = () => findFile(binDir(), process.platform === 'win32' ? 'llama-server.exe' : 'llama-server');

function request(url, opts) {
  opts = opts || {};
  return new Promise((resolve, reject) => {
    const req = net.request({ url, session: ses || undefined, redirect: 'follow', useSessionCookies: false });
    req.setHeader('user-agent', 'Inver-Browser');
    if (opts.headers) Object.keys(opts.headers).forEach((k) => req.setHeader(k, opts.headers[k]));
    req.on('response', (res) => resolve({ res, req }));
    req.on('error', reject);
    req.end();
  });
}
async function getJson(url) {
  const { res } = await request(url, { headers: { accept: 'application/vnd.github+json' } });
  return new Promise((resolve, reject) => {
    const chunks = [];
    res.on('data', (c) => chunks.push(c));
    res.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch (e) { reject(e); } });
    res.on('error', reject);
  });
}

// Скачивание с докачкой: если связь оборвётся, следующий запуск продолжит с того же места
async function download(url, dest, expected, label, from, span) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const part = dest + '.part';
  let have = fs.existsSync(part) ? fs.statSync(part).size : 0;
  const { res } = await request(url, { headers: have ? { range: 'bytes=' + have + '-' } : {} });
  if (res.statusCode === 416) { fs.renameSync(part, dest); return; }
  if (res.statusCode !== 200 && res.statusCode !== 206) throw new Error('Сервер ответил ' + res.statusCode);
  if (res.statusCode === 200) have = 0;
  const lenH = res.headers['content-length'];
  const total = have + (Number(Array.isArray(lenH) ? lenH[0] : lenH) || Math.max(0, expected - have));
  const out = fs.createWriteStream(part, { flags: have ? 'a' : 'w' });
  let got = have, last = 0;
  await new Promise((resolve, reject) => {
    res.on('data', (c) => {
      out.write(c); got += c.length;
      const now = Date.now();
      if (now - last > 300) { last = now; set({ progress: from + span * Math.min(1, got / total), text: label + ' · ' + (got / 1e6).toFixed(0) + ' из ' + (total / 1e6).toFixed(0) + ' МБ' }); }
    });
    res.on('end', () => out.end(resolve));
    res.on('error', (e) => { out.end(); reject(e); });
  });
  if (got < total * 0.98) throw new Error('Загрузка прервалась, попробуй ещё раз — продолжится с того же места');
  fs.renameSync(part, dest);
}

function unzip(zip, dir) {
  fs.mkdirSync(dir, { recursive: true });
  return new Promise((resolve, reject) => {
    // В Windows 10/11 есть встроенный tar, он умеет zip. Запасной путь — PowerShell
    execFile('tar', ['-xf', zip, '-C', dir], { windowsHide: true }, (err) => {
      if (!err) return resolve();
      execFile('powershell.exe', ['-NoProfile', '-Command', 'Expand-Archive -LiteralPath "' + zip + '" -DestinationPath "' + dir + '" -Force'], { windowsHide: true }, (e2) => e2 ? reject(e2) : resolve());
    });
  });
}

// Узнаём номер последней версии по переадресации страницы релизов (работает, даже когда API GitHub недоступен)
function latestTag() {
  return new Promise((resolve) => {
    let req;
    try { req = net.request({ url: 'https://github.com/ggml-org/llama.cpp/releases/latest', session: ses || undefined, redirect: 'manual' }); } catch (e) { return resolve(null); }
    const t = setTimeout(() => { try { req.abort(); } catch (e) {} resolve(null); }, 8000);
    req.setHeader('user-agent', 'Inver-Browser');
    req.on('redirect', (_s, _m, url) => { clearTimeout(t); try { req.abort(); } catch (e) {} const m = /\/tag\/(b\d+)/.exec(url || ''); resolve(m ? m[1] : null); });
    req.on('response', (res) => { clearTimeout(t); res.on('data', () => {}); resolve(null); });
    req.on('error', () => { clearTimeout(t); resolve(null); });
    req.end();
  });
}
const PINNED_TAG = 'b8863'; // проверенная версия на случай, если последнюю узнать не получилось
const engineUrl = (tag) => 'https://github.com/ggml-org/llama.cpp/releases/download/' + tag + '/llama-' + tag + '-bin-win-cpu-x64.zip';

async function engineCandidates() {
  const list = [];
  try {
    const rel = await getJson('https://api.github.com/repos/ggml-org/llama.cpp/releases/latest');
    const assets = (rel.assets || []).filter((a) => /\.zip$/i.test(a.name) && /win/i.test(a.name) && /x64/i.test(a.name) && !/cuda|hip|sycl|opencl|arm64|cudart|kompute/i.test(a.name));
    const pick = assets.find((a) => /cpu/i.test(a.name)) || assets.find((a) => /avx2/i.test(a.name)) || assets.find((a) => /vulkan/i.test(a.name));
    if (pick) list.push({ url: pick.browser_download_url, size: pick.size });
  } catch (e) {}
  const tag = await latestTag();
  if (tag) list.push({ url: engineUrl(tag), size: 3e7 });
  list.push({ url: engineUrl(PINNED_TAG), size: 3e7 });
  return list.filter((x, i, a) => a.findIndex((y) => y.url === x.url) === i);
}

async function installEngine() {
  if (serverExe()) return;
  if (process.platform !== 'win32') throw new Error('Автоустановка пока только для Windows');
  set({ phase: 'downloading', progress: 0.01, text: 'Ищу движок' });
  const zip = path.join(root(), 'engine.zip');
  let ok = false, lastErr = null;
  for (const c of await engineCandidates()) {
    try {
      try { fs.unlinkSync(zip + '.part'); } catch (e) {}
      await download(c.url, zip, c.size || 3e7, 'Движок', 0.01, 0.07);
      ok = true; break;
    } catch (e) { lastErr = e; }
  }
  if (!ok) throw new Error('Не получилось скачать движок с GitHub' + (lastErr ? ' (' + lastErr.message + ')' : '') + '. Если GitHub у тебя открывается только через VPN, включи обход блокировок в Inver и нажми «Попробовать ещё раз»');
  set({ text: 'Распаковываю движок' });
  await unzip(zip, binDir());
  try { fs.unlinkSync(zip); } catch (e) {}
  if (!serverExe()) throw new Error('В архиве движка нет llama-server');
}

async function installModel(key) {
  const dest = modelPath(key);
  if (fs.existsSync(dest)) return;
  const m = MODELS[key];
  let lastErr;
  for (const host of HF_HOSTS) {
    try { await download(host + '/' + m.repo + '/resolve/main/' + m.file + '?download=true', dest, m.size, 'Нейросеть «' + m.name + '»', 0.08, 0.9); return; }
    catch (e) { lastErr = e; }
  }
  throw lastErr || new Error('Не получилось скачать модель');
}

function health() {
  return new Promise((resolve) => {
    if (!PORT) return resolve(false);
    const req = net.request({ url: 'http://127.0.0.1:' + PORT + '/health' });
    const t = setTimeout(() => { try { req.abort(); } catch (e) {} resolve(false); }, 1500);
    req.on('response', (res) => { clearTimeout(t); res.on('data', () => {}); res.on('end', () => resolve(res.statusCode === 200)); });
    req.on('error', () => { clearTimeout(t); resolve(false); });
    req.end();
  });
}

// Свободный порт от системы
function freePort() {
  return new Promise((resolve) => {
    const srv = require('net').createServer();
    srv.listen(0, '127.0.0.1', () => { const p = srv.address().port; srv.close(() => resolve(p)); });
    srv.on('error', () => resolve(11475 + Math.floor(Math.random() * 400)));
  });
}
// Движки, оставшиеся от прошлых запусков Inver (если его закрыли через диспетчер задач или обновление)
function killOrphans() {
  if (process.platform !== 'win32') return Promise.resolve();
  return new Promise((resolve) => execFile('taskkill', ['/IM', 'llama-server.exe', '/F'], { windowsHide: true }, () => resolve()));
}

let logStream = null;
async function startServer(key) {
  if (proc && currentModel === key && await health()) return;
  stop();
  if (!proc) await killOrphans();
  set({ phase: 'starting', progress: 0.99, text: 'Запускаю нейросеть' });
  // Физические ядра обычно вдвое меньше логических: лишние потоки только тормозят генерацию
  const threads = Math.max(2, Math.min(8, Math.floor((os.cpus() || []).length / 2)));
  const logFile = path.join(root(), 'server.log');
  try { if (logStream) logStream.end(); logStream = fs.createWriteStream(logFile, { flags: 'w' }); } catch (e) { logStream = null; }
  let tail = '';
  PORT = await freePort();
  const args = ['-m', modelPath(key), '--host', '127.0.0.1', '--port', String(PORT), '-c', '4096', '-t', String(threads), '-np', '1'];
  if (logStream) logStream.write('[inver] ' + new Date().toISOString() + ' ' + serverExe() + ' ' + args.join(' ') + '\n');
  proc = spawn(serverExe(), args, { windowsHide: true, cwd: path.dirname(serverExe()), stdio: ['ignore', 'pipe', 'pipe'] });
  const keep = (d) => { tail = (tail + d.toString()).slice(-6000); if (logStream) try { logStream.write(d); } catch (e) {} };
  proc.stdout.on('data', keep); proc.stderr.on('data', keep);
  currentModel = key;
  let died = false, code = null;
  const me = proc;
  proc.on('exit', (c) => { died = true; code = c; if (proc === me) proc = null; if (logStream) try { logStream.write('\n[inver] exit ' + c + '\n'); } catch (e) {} if (state.phase === 'ready') set({ phase: 'idle', text: 'Нейросеть остановлена' }); });
  proc.on('error', (e) => { died = true; tail += '\n' + e.message; });
  for (let i = 0; i < 150; i++) {
    if (died) {
      // Старый движок иногда не отпускает порт сразу — одна повторная попытка на другом порту
      if (/bind|address already in use|couldn't bind/i.test(tail) && !startServer._retry) { startServer._retry = true; try { return await startServer(key); } finally { startServer._retry = false; } }
      throw new Error(explainExit(code, tail));
    }
    if (await health()) return;
    await new Promise((r) => setTimeout(r, 1000));
  }
  throw new Error('Нейросеть слишком долго запускается');
}
async function restart(key) { stop(); await killOrphans(); return ensure(key); }

// Понятное объяснение, почему движок закрылся
function explainExit(code, log) {
  const u = code == null ? null : (code >>> 0);
  if (u === 0xC0000135 || /0xc0000135|\.dll was not found|не найден/i.test(log)) return 'Движку не хватает системного компонента Microsoft Visual C++. Установи «Microsoft Visual C++ Redistributable x64» с сайта Microsoft и нажми «Попробовать ещё раз»';
  if (u === 0xC000001D) return 'Процессор не поддерживает нужные инструкции (AVX2). Встроенная нейросеть на этом компьютере не заработает';
  if (/failed to (load|open) model|unable to load model|gguf/i.test(log)) return 'Файл нейросети повреждён. Удали её в настройках (раздел AI) и скачай заново';
  if (/bind|address already in use|port/i.test(log)) return 'Порт занят другим процессом. Перезапусти Inver';
  if (/out of memory|failed to allocate|not enough memory/i.test(log)) return 'Не хватает оперативной памяти. Выбери «Лёгкую» нейросеть в настройках';
  const last = log.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).slice(-1)[0] || '';
  return 'Движок не запустился' + (code != null ? ' (код ' + code + ')' : '') + (last ? ': ' + last.slice(0, 160) : '');
}

function ensure(key) {
  key = MODELS[key] ? key : 'light';
  lastKey = key;
  if (busy) return busy;
  busy = (async () => {
    try {
      await installEngine();
      await installModel(key);
      await startServer(key);
      set({ phase: 'ready', progress: 1, text: 'Готово', error: '' });
      return { ok: true, port: PORT };
    } catch (e) {
      let msg = e.message || String(e);
      if (/aborted|ECONN|socket|ERR_|ETIMEDOUT|network/i.test(msg)) msg = 'Связь прервалась. Нажми «Попробовать ещё раз» — загрузка продолжится с того же места';
      set({ phase: 'error', error: msg });
      return { ok: false, error: msg };
    } finally { busy = null; }
  })();
  return busy;
}

function status(key) {
  key = MODELS[key] ? key : 'light';
  return Object.assign({}, state, { installed: !!serverExe() && fs.existsSync(modelPath(key)), port: PORT, models: Object.keys(MODELS).map((k) => ({ key: k, name: MODELS[k].name, sizeMb: Math.round(MODELS[k].size / 1e6), installed: fs.existsSync(modelPath(k)) })) });
}

function stop() { if (proc) { try { proc.kill(); } catch (e) {} proc = null; } }
function remove(key) {
  stop();
  try { fs.unlinkSync(modelPath(key)); } catch (e) {}
  set({ phase: 'idle', progress: 0, text: '' });
}

// Запрос к нейросети напрямую из главного процесса (без CORS и ограничений окна), ответ идёт кусками
function chat(messages, system, maxTokens, onDelta) {
  return ensure(currentModel || lastKey).then((r) => {
    if (!r.ok) throw new Error(r.error || 'Нейросеть не запустилась');
    return new Promise((resolve, reject) => {
      const body = JSON.stringify({ messages: [{ role: 'system', content: system }].concat(messages), temperature: 0.5, max_tokens: maxTokens || 600, stream: true, cache_prompt: true });
      let text = '', buf = '', done = false, idle = null;
      const finish = (err) => { if (done) return; done = true; clearTimeout(idle); err ? reject(err) : resolve(text.trim()); };
      const arm = (ms) => { clearTimeout(idle); idle = setTimeout(() => { try { req.destroy(); } catch (e) {} finish(new Error(text ? 'Нейросеть замолчала на полуслове' : 'Нейросеть не начала отвечать за 2 минуты. Нажми «Перезапустить нейросеть». Если повторится — пришли файл C:\\ProgramData\\InverAI\\server.log')); }, ms); };
      const req = http.request({ host: '127.0.0.1', port: PORT, path: '/v1/chat/completions', method: 'POST', headers: { 'content-type': 'application/json', 'content-length': Buffer.byteLength(body) } }, (res) => {
        if (res.statusCode !== 200) { let e = ''; res.on('data', (c) => { e += c; }); res.on('end', () => finish(new Error('Нейросеть ответила ' + res.statusCode + (e ? ': ' + e.slice(0, 160) : '')))); return; }
        res.setEncoding('utf8');
        res.on('data', (chunk) => {
          arm(60000);
          buf += chunk;
          const lines = buf.split('\n'); buf = lines.pop();
          for (const ln of lines) {
            const l = ln.trim(); if (!l.startsWith('data:')) continue;
            const data = l.slice(5).trim(); if (data === '[DONE]') continue;
            try { const d = JSON.parse(data); const piece = d.choices && d.choices[0] && d.choices[0].delta && d.choices[0].delta.content; if (piece) { text += piece; onDelta && onDelta(text); } } catch (e) {}
          }
        });
        res.on('end', () => finish());
        res.on('error', finish);
      });
      req.on('error', (e) => finish(new Error('Нет связи с нейросетью: ' + e.message)));
      arm(120000);
      req.end(body);
    });
  });
}
let lastKey = 'light';

app.on('will-quit', stop);

module.exports = {
  init(session, cb) { ses = session; onState = cb || onState; },
  ensure, status, stop, remove, chat, restart, get PORT() { return PORT; }, _download: download
};
