// Inver Snap — скриншот экрана компьютера по горячей клавише.
// Качество: кадр берётся прямо из видеопотока экрана в родном разрешении (без пережатия),
// а запасной путь — снимок системы в полном размере.
const { app, BrowserWindow, ipcMain, globalShortcut, desktopCapturer, screen, nativeImage, clipboard, shell, session } = require('electron');
const path = require('path');
const fs = require('fs');

let overlay = null, ctx = null, busy = false, keys = [];
const KEYS = ['PrintScreen', 'CommandOrControl+Shift+PrintScreen', 'CommandOrControl+Alt+S'];

function snapSession() {
  const ses = session.fromPartition('inver-snap');
  if (!ses.__inver) {
    ses.__inver = true;
    ses.setPermissionRequestHandler((_wc, perm, cb) => cb(perm === 'media' || perm === 'display-capture'));
    ses.setPermissionCheckHandler((_wc, perm) => perm === 'media' || perm === 'display-capture');
  }
  return ses;
}

async function start() {
  if (busy || overlay) return;
  busy = true;
  try {
    const point = screen.getCursorScreenPoint();
    const display = screen.getDisplayNearestPoint(point);
    const sf = display.scaleFactor || 1;
    const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 64, height: 64 } });
    const src = sources.find((s) => String(s.display_id) === String(display.id)) || sources[0];
    if (!src) { busy = false; return; }
    ctx = { sourceId: src.id, display, sf, w: display.bounds.width, h: display.bounds.height };
    overlay = new BrowserWindow({
      x: display.bounds.x, y: display.bounds.y, width: display.bounds.width, height: display.bounds.height,
      frame: false, backgroundColor: '#000000', resizable: false, movable: false, fullscreenable: false, minimizable: false, maximizable: false,
      skipTaskbar: true, alwaysOnTop: true, show: false, hasShadow: false, enableLargerThanScreen: true, paintWhenInitiallyHidden: true,
      webPreferences: { preload: path.join(__dirname, 'snap', 'preload.js'), contextIsolation: true, nodeIntegration: false, backgroundThrottling: false, session: snapSession() }
    });
    overlay.setAlwaysOnTop(true, 'screen-saver');
    overlay.setBounds(display.bounds);
    overlay.loadFile(path.join(__dirname, 'snap', 'snap.html'));
    overlay.on('closed', () => { overlay = null; ctx = null; });
    // Если окно так и не сообщило о готовности — показываем всё равно
    setTimeout(() => { if (overlay && !overlay.isDestroyed() && !overlay.isVisible()) { overlay.show(); overlay.focus(); } }, 2500);
  } catch (e) {
    console.error('snap failed', e);
  }
  busy = false;
}

function close() { if (overlay && !overlay.isDestroyed()) overlay.close(); }

function saveFile(img) {
  const dir = path.join(app.getPath('pictures'), 'Inver');
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const file = path.join(dir, 'screen-' + stamp + '.png');
  fs.writeFileSync(file, img.toPNG());
  return file;
}

ipcMain.handle('snap-init', () => ctx ? { sourceId: ctx.sourceId, w: ctx.w, h: ctx.h, sf: ctx.sf, accent: module.exports.accent } : null);
// Запасной путь: снимок системы в полном разрешении
ipcMain.handle('snap-fallback', async () => {
  if (!ctx) return null;
  const size = { width: Math.round(ctx.w * ctx.sf), height: Math.round(ctx.h * ctx.sf) };
  const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: size });
  const src = sources.find((s) => s.id === ctx.sourceId) || sources[0];
  return src ? src.thumbnail.toDataURL() : null;
});
ipcMain.on('snap-ready', () => { if (overlay && !overlay.isDestroyed()) { overlay.show(); overlay.focus(); } });
ipcMain.handle('snap-done', (_e, action, dataUrl) => {
  const img = nativeImage.createFromDataURL(dataUrl || '');
  if (img.isEmpty()) { close(); return null; }
  clipboard.writeImage(img);
  const file = action === 'save' ? saveFile(img) : null;
  close();
  if (file && module.exports.onSaved) module.exports.onSaved(file);
  return file;
});
ipcMain.on('snap-cancel', close);

function register(enabled) {
  keys.forEach((k) => { try { globalShortcut.unregister(k); } catch (e) {} });
  keys = [];
  if (!enabled) return [];
  KEYS.forEach((k) => { try { if (globalShortcut.register(k, start)) keys.push(k); } catch (e) {} });
  return keys.slice();
}

app.on('will-quit', () => { try { globalShortcut.unregisterAll(); } catch (e) {} });

module.exports = { start, register, accent: '#7C3AED', onSaved: null };
