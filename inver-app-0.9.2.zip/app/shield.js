// Inver Shield — блокировщик рекламы и трекеров (главный процесс, без внешних библиотек)

// Рекламные и следящие домены. Блокируются сами домены и все их поддомены.
const AD_HOSTS = [
  // Google
  'doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'google-analytics.com', 'googletagservices.com',
  'googletagmanager.com', 'adservice.google.com', 'adservice.google.ru', 'pagead2.googlesyndication.com', 'imasdk.googleapis.com',
  'googleads.g.doubleclick.net', 'fundingchoicesmessages.google.com',
  // Яндекс, Mail.ru, VK и прочий рунет
  'an.yandex.ru', 'mc.yandex.ru', 'yabs.yandex.ru', 'adfox.ru', 'ads.adfox.ru', 'adfox.yandex.ru', 'awaps.yandex.net',
  'top-fwz1.mail.ru', 'ad.mail.ru', 'rs.mail.ru', 'r3.mail.ru', 'mediator.mail.ru', 'ads.vk.com', 'ad.vk.com', 'tns-counter.ru',
  'counter.yadro.ru', 'mediametrics.ru', 'smi2.ru', 'smi2.net', 'relap.io', 'tgtrack.ru', 'adriver.ru', 'soloway.ru',
  'otm-r.com', 'betweendigital.com', 'buzzoola.com', 'hybrid.ai', 'segmento.ru', 'admitad.com', 'luxup.ru', 'directadvert.ru',
  'mediasniper.ru', 'begun.ru', 'lentainform.com', 'marketgid.com', 'mgid.com', 'traffic-media.co', 'adhigh.net',
  // Международные сети
  'adnxs.com', 'adsrvr.org', 'amazon-adsystem.com', 'criteo.com', 'criteo.net', 'taboola.com', 'outbrain.com', 'outbrainimg.com',
  'pubmatic.com', 'rubiconproject.com', 'openx.net', 'casalemedia.com', 'smartadserver.com', 'adform.net', 'yieldmo.com',
  'moatads.com', 'scorecardresearch.com', 'quantserve.com', 'quantcount.com', 'zedo.com', 'advertising.com', 'media.net',
  'bidswitch.net', 'sharethrough.com', 'teads.tv', 'teads.com', 'spotxchange.com', 'spotx.tv', '3lift.com', 'triplelift.com',
  'indexww.com', 'contextweb.com', 'lijit.com', 'sovrn.com', 'gumgum.com', 'undertone.com', 'adcolony.com', 'applovin.com',
  'unityads.unity3d.com', 'propellerads.com', 'popads.net', 'popcash.net', 'exoclick.com', 'exosrv.com', 'juicyads.com',
  'trafficjunky.net', 'trafficjunky.com', 'adsterra.com', 'adsterratools.com', 'hilltopads.net', 'clickadu.com',
  'onclickads.net', 'onclkds.com', 'propu.sh', 'pushame.com', 'richpush.co', 'mobicow.com', 'admaven.com', 'ad-maven.com',
  'a-ads.com', 'coinzilla.com', 'bitmedia.io', 'revcontent.com', 'mgid.ru', 'zergnet.com', 'adblade.com', 'adroll.com',
  'yieldlab.net', 'lkqd.net', 'springserve.com', 'smaato.net', 'inmobi.com', 'chartboost.com', 'vungle.com',
  'trafficstars.com', 'tsyndicate.com', 'realsrv.com', 'magsrv.com', 'ero-advertising.com', 'twinrdsrv.com',
  // Трекеры и аналитика
  'hotjar.com', 'hotjar.io', 'mixpanel.com', 'segment.io', 'segment.com', 'amplitude.com', 'fullstory.com', 'mouseflow.com',
  'crazyegg.com', 'clarity.ms', 'newrelic.com', 'nr-data.net', 'branch.io', 'appsflyer.com', 'adjust.com', 'kochava.com',
  'bat.bing.com', 'ads.linkedin.com', 'analytics.tiktok.com', 'ads.tiktok.com', 'ads-api.tiktok.com', 'connect.facebook.net',
  'pixel.facebook.com', 'an.facebook.com', 'ads.twitter.com', 'static.ads-twitter.com', 'analytics.twitter.com',
  'ads.pinterest.com', 'ct.pinterest.com', 'ads.reddit.com', 'events.redditmedia.com', 'snap.licdn.com', 'tr.snapchat.com',
  'sc-static.net', 'omtrdc.net', 'demdex.net', 'everesttech.net', 'krxd.net', 'bluekai.com', 'exelator.com', 'rlcdn.com',
  'agkn.com', 'tapad.com', 'mathtag.com', 'turn.com', 'serving-sys.com', 'eyeota.net', 'adsymptotic.com', 'id5-sync.com',
  'liveintent.com', 'chartbeat.com', 'chartbeat.net', 'parsely.com', 'mxpnl.com', 'statcounter.com', 'heapanalytics.com',
  'optimizely.com', 'kissmetrics.com', 'onesignal.com', 'pushwoosh.com', 'sendpulse.com'
];

// Части адресов, по которым узнаётся реклама на любых доменах
const AD_PATHS = /\/(pagead|adserver|adsbygoogle|ads\/(?:banner|display|show)|ad_?banner|adframe|advert(?:s|isement)?\/|prebid(?:\.min)?\.js|pubads|ad-?manager)[/?._-]/i;

const hostSet = new Set(AD_HOSTS);

function isAdHost(host) {
  let h = host.toLowerCase();
  while (h) {
    if (hostSet.has(h)) return true;
    const dot = h.indexOf('.');
    if (dot < 0) return false;
    h = h.slice(dot + 1);
  }
  return false;
}

function hostOf(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch (e) { return ''; }
}

// Подключает блокировщик к сессии вкладок. state — общий объект настроек, onCount — колбэк счётчика.
function attach(ses, state, onCount) {
  const counts = new Map();
  ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*', 'ws://*/*', 'wss://*/*'] }, (details, cb) => {
    const id = details.webContentsId;
    if (details.resourceType === 'mainFrame') {
      if (id) { counts.set(id, 0); onCount(id, 0); }
      return cb({});
    }
    if (!state.adblock) return cb({});
    let page = '';
    try { page = details.webContents ? details.webContents.getURL() : ''; } catch (e) {}
    const pageHost = hostOf(page);
    if (pageHost && state.allow.indexOf(pageHost) >= 0) return cb({});
    let host = '';
    try { host = new URL(details.url).hostname; } catch (e) { return cb({}); }
    // Не трогаем запросы сайта к самому себе, кроме явных рекламных путей
    const sameSite = pageHost && (host === pageHost || host.endsWith('.' + pageHost));
    const block = (!sameSite && isAdHost(host)) || AD_PATHS.test(details.url);
    if (block && id) {
      const n = (counts.get(id) || 0) + 1;
      counts.set(id, n);
      onCount(id, n);
    }
    cb({ cancel: block });
  });
}

// Прячет пустые рекламные места, которые остаются после блокировки
const COSMETIC = [
  'ins.adsbygoogle', '.adsbygoogle', '[id^="google_ads_"]', '[id^="div-gpt-ad"]', 'iframe[src*="doubleclick.net"]',
  'iframe[src*="googlesyndication"]', '[id^="yandex_rtb"]', '[id^="adfox_"]', '[class*="adfox"]', '.ya-partner',
  '[data-ad-slot]', '[data-google-query-id]', '.taboola', '[id^="taboola-"]', '.OUTBRAIN', '[data-widget-id][class*="mgid"]',
  '.trc_related_container', 'amp-ad', 'amp-embed[type="taboola"]', '[aria-label="Advertisement"]', '[aria-label="Реклама"]',
  'ytd-ad-slot-renderer', 'ytd-in-feed-ad-layout-renderer', 'ytd-promoted-sparkles-web-renderer', 'ytd-banner-promo-renderer',
  'ytd-display-ad-renderer', 'ytd-player-legacy-desktop-watch-ads-renderer', '#masthead-ad', '.ytp-ad-overlay-container'
].join(',') + '{display:none!important}';

// На YouTube реклама идёт с того же домена: пропускаем её прямо в плеере
const YOUTUBE = `(() => {
  if (window.__inverYT) return; window.__inverYT = true;
  setInterval(() => {
    const p = document.querySelector('.html5-video-player');
    if (!p || !p.classList.contains('ad-showing')) return;
    const v = p.querySelector('video');
    if (v && isFinite(v.duration)) { v.muted = true; v.currentTime = v.duration; }
    const s = document.querySelector('.ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern');
    if (s) s.click();
  }, 300);
})();`;

// Уведомления о cookie: прячем баннеры популярных систем согласия и возвращаем прокрутку
const COOKIES = [
  '#onetrust-banner-sdk', '#onetrust-consent-sdk', '#CybotCookiebotDialog', '#CybotCookiebotDialogBodyUnderlay', '.cc-window', '.cc-banner',
  '#cookie-law-info-bar', '#cookie-notice', '#cookieNotice', '.cookie-notice', '#gdpr-cookie-message', '.qc-cmp2-container', '#qc-cmp2-container',
  '#usercentrics-root', '#usercentrics-cmp-ui', '#didomi-host', '#truste-consent-track', '.truste_box_overlay', '#cmpbox', '#cmpbox2', '.osano-cm-window',
  '#hs-eu-cookie-confirmation', '.fc-consent-root', '#cookiescript_injected', '.cky-consent-container', '.cky-overlay', '#moove_gdpr_cookie_info_bar',
  '.iubenda-cs-container', '#iubenda-cs-banner', '#termly-code-snippet-support', '#BorlabsCookieBox', '.cmplz-cookiebanner', '#cookie-consent-banner',
  '.js-consent-banner', '#consent_blackbar', '#axeptio_overlay', '#tarteaucitronRoot', '.klaro', '#cookiebanner', '.cookiebanner', '.cookie-banner'
].join(',') + '{display:none!important}' +
  'html.sp-message-open,body.didomi-popup-open,body.qc-cmp-showing,html.cmplz-cookiebanner-open,body.cookie-consent-open{overflow:auto!important}';

module.exports = { attach, COSMETIC, COOKIES, YOUTUBE, hostOf };
