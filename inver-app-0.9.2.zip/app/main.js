// Inver — главный процесс Electron
const { app, BrowserWindow, ipcMain, Menu, nativeImage, clipboard, shell, session, Tray } = require('electron');
const path = require('path');
const fs = require('fs');
const shield = require('./shield');
const icons = require('./icons');
const snap = require('./snap');
const aiLocal = require('./ai-local');
const updater = require('./updater');

let win;

// Общие настройки, которые приходят из интерфейса
const state = {
  adblock: true,
  allow: [],                 // сайты, где блокировщик выключен
  vpn: { on: false, mode: 'list', proxy: 'socks5://127.0.0.1:40000', domains: [] }
};

function tabsSession() { return session.fromPartition('persist:inver'); }

function createWindow() {
  win = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 980,
    minHeight: 640,
    backgroundColor: '#050507',
    frame: false,
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'hidden',
    show: false,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      autoplayPolicy: 'no-user-gesture-required'
    }
  });

  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => { if (!process.argv.includes('--hidden')) win.show(); });
  if (process.argv.includes('--dev')) win.webContents.openDevTools({ mode: 'detach' });

  win.on('close', (e) => { if (keepInTray && !quitting) { e.preventDefault(); win.hide(); } });
  win.on('maximize', () => win.webContents.send('win-state', 'max'));
  win.on('unmaximize', () => win.webContents.send('win-state', 'normal'));

  // Ссылки target=_blank из вкладок открываем как новые вкладки Inver
  app.on('web-contents-created', (_e, contents) => {
    if (contents.getType() === 'webview') {
      contents.setWindowOpenHandler(({ url }) => {
        win.webContents.send('shortcut', 'open-url', url);
        return { action: 'deny' };
      });
    }
  });
}

// Горячие клавиши работают даже когда фокус внутри страницы (webview)
function buildMenu() {
  const send = (name) => () => win && win.webContents.send('shortcut', name);
  const template = [
    {
      label: 'Inver',
      submenu: [
        { label: 'Перейти в Space', accelerator: 'CmdOrCtrl+Shift+S', click: send('space') },
        { label: 'Скриншот', accelerator: 'CmdOrCtrl+Shift+X', click: send('screenshot') },
        { label: 'Новая вкладка', accelerator: 'CmdOrCtrl+T', click: send('new-tab') },
        { label: 'Закрыть вкладку', accelerator: 'CmdOrCtrl+W', click: send('close-tab') },
        { label: 'Адресная строка', accelerator: 'CmdOrCtrl+L', click: send('focus-address') },
        { label: 'Обновить', accelerator: 'CmdOrCtrl+R', click: send('reload') },
        { label: 'Настройки', accelerator: 'CmdOrCtrl+,', click: send('settings') },
        { label: 'Док приложений', accelerator: 'CmdOrCtrl+B', click: send('panel') },
        { label: 'Найти на странице', accelerator: 'CmdOrCtrl+F', click: send('find') },
        { label: 'История', accelerator: 'CmdOrCtrl+H', click: send('history') },
        { label: 'Закладки', accelerator: 'CmdOrCtrl+Shift+O', click: send('bookmarks') },
        { label: 'Добавить в закладки', accelerator: 'CmdOrCtrl+D', click: send('bookmark') },
        { label: 'Загрузки', accelerator: 'CmdOrCtrl+J', click: send('downloads') },
        { label: 'Вернуть закрытую вкладку', accelerator: 'CmdOrCtrl+Shift+T', click: send('reopen') },
        { label: 'Командная строка', accelerator: 'CmdOrCtrl+K', click: send('palette') },
        { label: 'Приватная вкладка', accelerator: 'CmdOrCtrl+Shift+N', click: send('private') },
        { label: 'Видео поверх окон', accelerator: 'Alt+P', click: send('pip') },
        { label: 'Режим чтения', accelerator: 'Alt+R', click: send('reader') },
        { label: 'AI-помощник', accelerator: 'F11', click: send('ai') },
        { label: 'AI-помощник ', accelerator: 'Alt+A', click: send('ai') },
        { label: 'Во весь экран', accelerator: 'Shift+F11', click: () => win && win.setFullScreen(!win.isFullScreen()) },
        { label: 'Режим фокуса', accelerator: 'Alt+F', click: send('focus') },
        { label: 'Разделить экран', accelerator: 'Alt+S', click: send('split') },
        ...[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => ({ label: 'Комната ' + n, accelerator: 'Alt+' + n, click: () => win && win.webContents.send('shortcut', 'room', n) })),
        { type: 'separator' },
        { role: 'toggleDevTools', label: 'Инструменты разработчика' },
        { role: 'quit', label: 'Выйти' }
      ]
    },
    {
      label: 'Правка',
      submenu: [
        { role: 'undo' }, { role: 'redo' }, { type: 'separator' },
        { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

/* ---------- Обход блокировок ---------- */
// "socks5://127.0.0.1:40000" → "SOCKS5 127.0.0.1:40000"
function pacTarget(proxy) {
  const m = String(proxy || '').trim().match(/^(socks5|socks4|socks|https?):\/\/([^/\s]+)\/?$/i);
  if (!m) return null;
  const kind = m[1].toLowerCase();
  if (kind === 'http') return 'PROXY ' + m[2];
  if (kind === 'https') return 'HTTPS ' + m[2];
  if (kind === 'socks4') return 'SOCKS ' + m[2];
  return 'SOCKS5 ' + m[2] + '; SOCKS ' + m[2];
}

function pacScript(target, domains) {
  return 'function FindProxyForURL(url, host) {\n' +
    '  var d = ' + JSON.stringify(domains) + ';\n' +
    '  for (var i = 0; i < d.length; i++) if (host === d[i] || dnsDomainIs(host, "." + d[i])) return "' + target + '";\n' +
    '  return "DIRECT";\n}';
}

async function applyProxy() {
  await applyProxyTo(session.fromPartition('inver-private'));
  return applyProxyTo(tabsSession());
}
async function applyProxyTo(ses) {
  const v = state.vpn;
  const target = pacTarget(v.proxy);
  if (!v.on || !target) return ses.setProxy({ mode: 'direct' });
  if (v.mode === 'all') return ses.setProxy({ proxyRules: v.proxy.trim(), proxyBypassRules: '<local>' });
  const pac = pacScript(target, v.domains);
  return ses.setProxy({ mode: 'pac_script', pacScript: 'data:application/x-ns-proxy-autoconfig;base64,' + Buffer.from(pac).toString('base64') });
}

// Проверка: идём через прокси на Cloudflare и узнаём страну выхода
async function testProxy(proxy) {
  if (!pacTarget(proxy)) return { ok: false, error: 'Адрес должен быть вида socks5://127.0.0.1:40000 или http://хост:порт' };
  const ses = session.fromPartition('inver-proxy-test');
  await ses.setProxy({ proxyRules: proxy.trim() });
  await ses.closeAllConnections();
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 8000);
    const res = await ses.fetch('https://www.cloudflare.com/cdn-cgi/trace', { signal: ctrl.signal, cache: 'no-store' });
    clearTimeout(timer);
    const text = await res.text();
    const get = (k) => (text.match(new RegExp('^' + k + '=(.*)$', 'm')) || [])[1] || '';
    return { ok: true, ip: get('ip'), loc: get('loc'), warp: get('warp') };
  } catch (e) {
    return { ok: false, error: e.name === 'AbortError' ? 'Прокси не ответил за 8 секунд' : 'Прокси не отвечает. Проверь, что он запущен.' };
  }
}

ipcMain.handle('config', async (_e, cfg) => {
  if (cfg && typeof cfg.adblock === 'boolean') state.adblock = cfg.adblock;
  if (cfg && Array.isArray(cfg.allow)) state.allow = cfg.allow.slice(0, 500);
  if (cfg && cfg.vpn) {
    const v = cfg.vpn;
    state.vpn = {
      on: !!v.on,
      mode: v.mode === 'all' ? 'all' : 'list',
      proxy: String(v.proxy || state.vpn.proxy),
      domains: (Array.isArray(v.domains) ? v.domains : []).map((d) => String(d).trim().toLowerCase().replace(/^\*?\./, '')).filter(Boolean).slice(0, 1000)
    };
    await applyProxy();
    await tabsSession().closeAllConnections();
  }
  return { ok: true, proxyValid: !!pacTarget(state.vpn.proxy) };
});

ipcMain.handle('proxy-test', (_e, proxy) => testProxy(proxy));

ipcMain.handle('shield-assets', () => ({ css: shield.COSMETIC, cookies: shield.COOKIES, youtube: shield.YOUTUBE }));

// Окно: свернуть / развернуть / закрыть (своя шапка без системной рамки)
ipcMain.on('win', (_e, action) => {
  if (!win) return;
  if (action === 'min') win.minimize();
  if (action === 'max') (win.isMaximized() ? win.unmaximize() : win.maximize());
  if (action === 'close') win.close();
});

/* ---------- Загрузки ---------- */
const downloads = new Map();
let dlSeq = 0;
function uniquePath(dir, name) {
  const ext = path.extname(name), base = path.basename(name, ext);
  let p = path.join(dir, name), i = 1;
  while (fs.existsSync(p)) p = path.join(dir, base + ' (' + (i++) + ')' + ext);
  return p;
}
function watchDownloads(ses) {
  ses.on('will-download', (_e, item) => {
    const id = ++dlSeq;
    const file = uniquePath(app.getPath('downloads'), item.getFilename() || 'download');
    item.setSavePath(file);
    downloads.set(id, item);
    const info = (state) => ({
      id, name: path.basename(file), path: file, url: item.getURL(),
      total: item.getTotalBytes(), received: item.getReceivedBytes(),
      state: state || item.getState(), paused: item.isPaused(), started: item.getStartTime() * 1000
    });
    const send = (state) => { if (win && !win.isDestroyed()) win.webContents.send('download', info(state)); };
    send('progressing');
    let last = 0;
    item.on('updated', (_ev, st) => { const now = Date.now(); if (now - last > 250) { last = now; send(st === 'interrupted' ? 'interrupted' : 'progressing'); } });
    item.once('done', (_ev, st) => { send(st); downloads.delete(id); });
  });
}
ipcMain.on('dl-action', (_e, id, action, file) => {
  const item = downloads.get(id);
  if (action === 'cancel' && item) item.cancel();
  if (action === 'pause' && item) (item.isPaused() ? item.resume() : item.pause());
  if (action === 'open' && file) shell.openPath(file);
  if (action === 'show' && file) shell.showItemInFolder(file);
});

/* ---------- Перенос закладок из других браузеров ---------- */
function bookmarkFiles() {
  const local = process.env.LOCALAPPDATA || '', roaming = process.env.APPDATA || '';
  const home = app.getPath('home');
  const roots = [
    ['Google Chrome', path.join(local, 'Google', 'Chrome', 'User Data')],
    ['Яндекс Браузер', path.join(local, 'Yandex', 'YandexBrowser', 'User Data')],
    ['Microsoft Edge', path.join(local, 'Microsoft', 'Edge', 'User Data')],
    ['Brave', path.join(local, 'BraveSoftware', 'Brave-Browser', 'User Data')],
    ['Vivaldi', path.join(local, 'Vivaldi', 'User Data')],
    ['Opera', path.join(roaming, 'Opera Software', 'Opera Stable')],
    ['Opera GX', path.join(roaming, 'Opera Software', 'Opera GX Stable')],
    // macOS
    ['Google Chrome', path.join(home, 'Library', 'Application Support', 'Google', 'Chrome')],
    ['Яндекс Браузер', path.join(home, 'Library', 'Application Support', 'Yandex', 'YandexBrowser')]
  ];
  const out = [];
  roots.forEach(([name, root]) => {
    const tryFile = (f, profile) => { if (fs.existsSync(f)) out.push({ name: name + (profile && profile !== 'Default' ? ' · ' + profile : ''), file: f }); };
    try {
      tryFile(path.join(root, 'Bookmarks'), '');
      tryFile(path.join(root, 'Default', 'Bookmarks'), 'Default');
      if (fs.existsSync(root)) fs.readdirSync(root).filter((d) => /^Profile \d+$/.test(d)).forEach((d) => tryFile(path.join(root, d, 'Bookmarks'), d));
    } catch (e) {}
  });
  return out;
}
function readBookmarks(file) {
  const items = [];
  const walk = (node, folder) => {
    if (!node) return;
    if (node.type === 'url' && /^https?:/i.test(node.url || '')) items.push({ title: node.name || node.url, url: node.url, folder });
    (node.children || []).forEach((c) => walk(c, node.type === 'folder' && node.name ? node.name : folder));
  };
  try {
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    Object.keys(data.roots || {}).forEach((k) => walk(data.roots[k], ''));
  } catch (e) {}
  return items;
}
ipcMain.handle('import-sources', () => bookmarkFiles().map((s) => ({ name: s.name, items: readBookmarks(s.file) })).filter((s) => s.items.length));

// Работа в фоне: при закрытии окна Inver прячется в трей, чтобы скриншоты по клавише работали всегда
let tray = null, keepInTray = false, quitting = false;
app.on('before-quit', () => { quitting = true; });
function ensureTray() {
  if (tray || !keepInTray) return;
  const img = nativeImage.createFromPath(path.join(__dirname, 'build', 'tray.png')).resize({ width: 16, height: 16, quality: 'best' });
  tray = new Tray(img);
  tray.setToolTip('Inver');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Открыть Inver', click: () => { if (win) { win.show(); win.focus(); } } },
    { label: 'Скриншот экрана', click: () => snap.start() },
    { type: 'separator' },
    { label: 'Выйти', click: () => { quitting = true; app.quit(); } }
  ]));
  tray.on('click', () => { if (win) { win.show(); win.focus(); } });
}
function dropTray() { if (tray) { tray.destroy(); tray = null; } }

// Скриншот экрана по горячей клавише
ipcMain.handle('snap-config', (_e, cfg) => {
  if (cfg && cfg.accent) snap.accent = cfg.accent;
  keepInTray = !!(cfg && cfg.tray);
  if (keepInTray) ensureTray(); else dropTray();
  return snap.register(!cfg || cfg.enabled !== false);
});
ipcMain.on('snap-start', () => snap.start());
snap.onSaved = (file) => { if (win && !win.isDestroyed()) win.webContents.send('snap-saved', file); };
snap.onCopied = () => { if (win && !win.isDestroyed()) win.webContents.send('snap-saved', null); };

// Автообновления: тихо скачиваются, включаются при следующем запуске
ipcMain.handle('update-check', () => updater.check(true));
ipcMain.handle('update-status', () => ({ configured: updater.configured(), version: app.getVersion(), pending: updater.pending() }));
ipcMain.on('update-restart', () => { quitting = true; app.relaunch(); app.exit(0); });

// Встроенная нейросеть: скачивается и запускается сама
ipcMain.handle('ai-local-ensure', (_e, model) => aiLocal.ensure(model));
ipcMain.handle('ai-local-status', (_e, model) => aiLocal.status(model));
ipcMain.handle('ai-local-restart', (_e, model) => aiLocal.restart(model));
ipcMain.handle('ai-local-chat', (e, id, model, messages, system, maxTokens) => aiLocal.ensure(model).then(() => aiLocal.chat(messages, system, maxTokens, (text) => { try { e.sender.send('ai-local-delta', id, text); } catch (er) {} })).then((text) => ({ ok: true, text }), (err) => ({ ok: false, error: err.message || String(err) })));
ipcMain.handle('ai-local-remove', (_e, model) => { aiLocal.remove(model); return aiLocal.status(model); });

ipcMain.handle('site-icon', (_e, host) => icons.iconFor(tabsSession(), host));
ipcMain.handle('site-icon-hint', (_e, host, urls) => icons.hint(tabsSession(), host, urls));

ipcMain.on('copy', (_e, text) => clipboard.writeText(String(text || '')));

// Сохранение скриншота: файл в «Изображения/Inver» + копия в буфер обмена
ipcMain.handle('save-shot', async (_e, dataUrl) => {
  const img = nativeImage.createFromDataURL(dataUrl);
  const dir = path.join(app.getPath('pictures'), 'Inver');
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const file = path.join(dir, `inver-${stamp}.png`);
  fs.writeFileSync(file, img.toPNG());
  clipboard.writeImage(img);
  return file;
});

ipcMain.on('show-file', (_e, file) => shell.showItemInFolder(file));

// Сайты видят обычный Chrome, а не Electron: так меньше белых и сломанных страниц
app.userAgentFallback = app.userAgentFallback.replace(/\s(Electron|inver-browser|Inver)\/\S+/gi, '');

app.whenReady().then(() => {
  buildMenu();
  // Блокировщик: счётчик заблокированного уходит в интерфейс
  watchDownloads(tabsSession());
  watchDownloads(session.fromPartition('inver-private'));
  shield.attach(session.fromPartition('inver-private'), state, (id, n) => { if (win && !win.isDestroyed()) win.webContents.send('blocked', id, n); });
  updater.start(session.defaultSession, (info) => {
    // Окно спрятано в трей — перезапускаемся незаметно; иначе просто сообщаем
    if (win && !win.isDestroyed() && !win.isVisible()) { quitting = true; app.relaunch({ args: process.argv.slice(1).concat(['--hidden']) }); app.exit(0); return; }
    if (win && !win.isDestroyed()) win.webContents.send('update-ready', info);
  });
  aiLocal.init(tabsSession(), (st) => { if (win && !win.isDestroyed()) win.webContents.send('ai-local-state', st); });
  shield.attach(tabsSession(), state, (id, n) => { if (win && !win.isDestroyed()) win.webContents.send('blocked', id, n); });
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin' && !keepInTray) app.quit(); });
