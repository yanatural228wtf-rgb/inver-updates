/* Inver Snap — окно скриншота: выбор режима, область с ручками, инструменты рисования */
(function () {
  'use strict';
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  var body = document.body, base = $('#base'), ink = $('#ink'), sel = $('#sel'), bar = $('#bar'), textIn = $('#textIn');
  var bctx = base.getContext('2d'), ictx = ink.getContext('2d');
  var W = window.innerWidth, H = window.innerHeight, dpr = window.devicePixelRatio || 1;
  var PW = 0, PH = 0;                  // размер снимка в настоящих пикселях экрана
  var rect = null;                     // выделение в CSS-пикселях
  var mode = 'pick';                   // pick → edit
  var tool = null, color = '#7C3AED', width = 4;
  var shapes = [], redoStack = [], cur = null, drag = null, numSeq = 1;

  ink.width = Math.round(W * dpr); ink.height = Math.round(H * dpr);

  /* ---------- Захват экрана в родном разрешении ---------- */
  function useImage(src) {
    return new Promise(function (res) {
      var im = new Image();
      im.onload = function () { setBase(im, im.naturalWidth, im.naturalHeight); res(true); };
      im.onerror = function () { res(false); };
      im.src = src;
    });
  }
  function setBase(source, w, h) {
    PW = w; PH = h;
    base.width = w; base.height = h;
    bctx.imageSmoothingEnabled = false;
    bctx.drawImage(source, 0, 0, w, h);
  }
  function grab(info) {
    var pw = Math.round(info.w * info.sf), ph = Math.round(info.h * info.sf);
    return navigator.mediaDevices.getUserMedia({ audio: false, video: { mandatory: {
      chromeMediaSource: 'desktop', chromeMediaSourceId: info.sourceId,
      minWidth: pw, maxWidth: pw, minHeight: ph, maxHeight: ph, maxFrameRate: 30 } } })
      .then(function (stream) {
        var track = stream.getVideoTracks()[0];
        var stop = function () { stream.getTracks().forEach(function (t) { t.stop(); }); };
        if (window.ImageCapture) {
          return new ImageCapture(track).grabFrame().then(function (bmp) { setBase(bmp, bmp.width, bmp.height); stop(); return true; })
            .catch(function () { return viaVideo(stream, stop); });
        }
        return viaVideo(stream, stop);
      });
  }
  function viaVideo(stream, stop) {
    return new Promise(function (res, rej) {
      var v = document.createElement('video');
      v.muted = true; v.srcObject = stream;
      v.onloadedmetadata = function () {
        v.play().then(function () {
          setTimeout(function () { setBase(v, v.videoWidth, v.videoHeight); stop(); res(true); }, 60);
        }).catch(function (e) { stop(); rej(e); });
      };
    });
  }

  window.snap.init().then(function (info) {
    if (!info) return window.snap.cancel();
    if (info.accent) { document.documentElement.style.setProperty('--accent', info.accent); }
    buildColors(info.accent || '#7C3AED');
    return grab(info).catch(function () { return false; }).then(function (ok) {
      if (ok && PW) return true;
      return window.snap.fallback().then(function (src) { return src ? useImage(src) : false; });
    });
  }).then(function (ok) {
    if (!ok) return window.snap.cancel();
    window.snap.ready();
  });

  /* ---------- Цвета и толщина ---------- */
  function buildColors(acc) {
    var list = [acc, '#FF3B30', '#FFCC00', '#34C759', '#FFFFFF', '#111111'];
    var wrap = $('#colors');
    wrap.innerHTML = '';
    list.forEach(function (c, i) {
      var b = document.createElement('button');
      b.style.backgroundColor = c; b.title = 'Цвет'; b.setAttribute('aria-label', 'Цвет ' + c);
      b.addEventListener('click', function () { color = c; $$('#colors button').forEach(function (x) { x.classList.toggle('on', x === b); }); });
      if (i === 0) b.classList.add('on');
      wrap.appendChild(b);
    });
    color = acc;
  }
  $$('[data-w]').forEach(function (b) {
    b.classList.toggle('on', Number(b.dataset.w) === width);
    b.addEventListener('click', function () { width = Number(b.dataset.w); $$('[data-w]').forEach(function (x) { x.classList.toggle('on', x === b); }); });
  });

  /* ---------- Выделение ---------- */
  function norm(a, b) { return { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(a.x - b.x), h: Math.abs(a.y - b.y) }; }
  function clampRect(r) {
    r.x = Math.max(0, Math.min(W - 1, r.x)); r.y = Math.max(0, Math.min(H - 1, r.y));
    r.w = Math.max(1, Math.min(W - r.x, r.w)); r.h = Math.max(1, Math.min(H - r.y, r.h));
    return r;
  }
  function place() {
    body.classList.toggle('has-sel', !!rect);
    if (!rect) { sel.hidden = true; return; }
    sel.hidden = false;
    sel.style.left = rect.x + 'px'; sel.style.top = rect.y + 'px'; sel.style.width = rect.w + 'px'; sel.style.height = rect.h + 'px';
    var sx = PW / W || dpr;
    $('#size').textContent = Math.round(rect.w * sx) + ' × ' + Math.round(rect.h * sx);
    $('#size').style.top = rect.y < 32 ? '6px' : '-28px';
    $('#size').style.left = rect.y < 32 ? '6px' : '0';
  }
  function placeBar() {
    bar.hidden = false;
    var bw = bar.offsetWidth, bh = bar.offsetHeight;
    var x = Math.min(W - bw - 8, Math.max(8, rect.x + rect.w / 2 - bw / 2));
    var y = rect.y + rect.h + 12;
    if (y + bh > H - 8) y = rect.y - bh - 12;
    if (y < 8) y = Math.min(H - bh - 8, rect.y + rect.h - bh - 12);
    bar.style.left = x + 'px'; bar.style.top = Math.max(8, y) + 'px';
  }
  function enterEdit() {
    mode = 'edit'; body.classList.remove('pick'); body.classList.add('edit');
    setTool(null); place(); placeBar();
  }

  $$('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function (e) {
      e.stopPropagation();
      if (b.dataset.mode === 'full') { rect = { x: 0, y: 0, w: W, h: H }; enterEdit(); }
      else { $$('[data-mode]').forEach(function (x) { x.classList.toggle('on', x === b); }); }
    });
  });
  $('#cancel0').addEventListener('click', function () { window.snap.cancel(); });

  /* ---------- Рисование ---------- */
  function setTool(t) {
    commitText();
    tool = t;
    $$('[data-tool]').forEach(function (b) { b.classList.toggle('on', b.dataset.tool === t); });
    body.classList.toggle('no-tool', !t);
  }
  $$('[data-tool]').forEach(function (b) { b.addEventListener('click', function () { setTool(tool === b.dataset.tool ? null : b.dataset.tool); }); });

  function redraw() {
    ictx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ictx.clearRect(0, 0, W, H);
    shapes.concat(cur ? [cur] : []).forEach(function (s) { drawShape(ictx, s); });
  }
  function drawShape(g, s) {
    g.save();
    g.strokeStyle = s.color; g.fillStyle = s.color; g.lineWidth = s.w; g.lineCap = 'round'; g.lineJoin = 'round';
    if (s.t === 'pen' || s.t === 'marker') {
      if (s.t === 'marker') { g.globalAlpha = .38; g.lineWidth = s.w * 4 + 6; g.lineCap = 'square'; }
      g.beginPath(); s.pts.forEach(function (p, i) { i ? g.lineTo(p.x, p.y) : g.moveTo(p.x, p.y); }); g.stroke();
    }
    if (s.t === 'line' || s.t === 'arrow') {
      g.beginPath(); g.moveTo(s.a.x, s.a.y); g.lineTo(s.b.x, s.b.y); g.stroke();
      if (s.t === 'arrow') {
        var ang = Math.atan2(s.b.y - s.a.y, s.b.x - s.a.x), L = 10 + s.w * 3;
        g.beginPath(); g.moveTo(s.b.x, s.b.y);
        g.lineTo(s.b.x - L * Math.cos(ang - .42), s.b.y - L * Math.sin(ang - .42));
        g.lineTo(s.b.x - L * Math.cos(ang + .42), s.b.y - L * Math.sin(ang + .42));
        g.closePath(); g.fill();
      }
    }
    if (s.t === 'rect') { var r = norm(s.a, s.b); g.beginPath(); if (g.roundRect) g.roundRect(r.x, r.y, r.w, r.h, 6); else g.rect(r.x, r.y, r.w, r.h); g.stroke(); }
    if (s.t === 'ellipse') { var e = norm(s.a, s.b); g.beginPath(); g.ellipse(e.x + e.w / 2, e.y + e.h / 2, e.w / 2, e.h / 2, 0, 0, Math.PI * 2); g.stroke(); }
    if (s.t === 'pixel') {
      var q = norm(s.a, s.b), sx = PW / W, cell = 12;
      if (q.w > 2 && q.h > 2) {
        var tw = Math.max(1, Math.round(q.w / cell)), th = Math.max(1, Math.round(q.h / cell));
        var tmp = document.createElement('canvas'); tmp.width = tw; tmp.height = th;
        tmp.getContext('2d').drawImage(base, q.x * sx, q.y * sx, q.w * sx, q.h * sx, 0, 0, tw, th);
        g.imageSmoothingEnabled = false; g.drawImage(tmp, 0, 0, tw, th, q.x, q.y, q.w, q.h);
      }
    }
    if (s.t === 'text') {
      g.font = '700 ' + s.size + 'px "Segoe UI", system-ui, sans-serif'; g.textBaseline = 'top';
      g.lineWidth = Math.max(3, s.size / 7); g.strokeStyle = isLight(s.color) ? 'rgba(0,0,0,.55)' : 'rgba(255,255,255,.85)';
      s.text.split('\n').forEach(function (ln, i) { var y = s.x !== undefined ? s.y + i * s.size * 1.2 : 0; g.strokeText(ln, s.x, y); g.fillText(ln, s.x, y); });
    }
    if (s.t === 'num') {
      var rr = 11 + s.w * 1.5;
      g.beginPath(); g.arc(s.a.x, s.a.y, rr, 0, Math.PI * 2); g.fill();
      g.fillStyle = isLight(s.color) ? '#111' : '#fff'; g.font = '700 ' + Math.round(rr * 1.1) + 'px "Segoe UI", system-ui, sans-serif';
      g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(s.n), s.a.x, s.a.y + 1);
    }
    g.restore();
  }
  function isLight(c) {
    var m = /^#?([0-9a-f]{6})$/i.exec(c); if (!m) return false;
    var n = parseInt(m[1], 16); return (0.299 * (n >> 16 & 255) + 0.587 * (n >> 8 & 255) + 0.114 * (n & 255)) > 170;
  }
  function push(s) { shapes.push(s); redoStack = []; redraw(); }
  function undo() { if (shapes.length) { var s = shapes.pop(); if (s.t === 'num') numSeq--; redoStack.push(s); redraw(); } }
  function redo() { if (redoStack.length) { var s = redoStack.pop(); if (s.t === 'num') numSeq++; shapes.push(s); redraw(); } }
  $('#undo').addEventListener('click', undo);
  $('#redo').addEventListener('click', redo);

  /* ---------- Текст ---------- */
  var textAt = null;
  function startText(p) {
    commitText();
    textAt = { x: p.x, y: p.y, size: 14 + width * 3, color: color };
    textIn.hidden = false; textIn.value = '';
    textIn.style.left = p.x + 'px'; textIn.style.top = p.y + 'px';
    textIn.style.color = color; textIn.style.fontSize = textAt.size + 'px';
    fitText();
    textIn.focus();
  }
  function fitText() {
    var lines = textIn.value.split('\n');
    textIn.style.width = Math.max(40, Math.max.apply(null, lines.map(function (l) { return l.length; })) * textAt.size * .62 + 12) + 'px';
    textIn.style.height = (lines.length * textAt.size * 1.2 + 6) + 'px';
  }
  textIn.addEventListener('input', fitText);
  textIn.addEventListener('keydown', function (e) {
    e.stopPropagation();
    if (e.key === 'Escape') { textIn.value = ''; commitText(); }
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); commitText(); }
  });
  function commitText() {
    if (!textAt) return;
    var t = textIn.value.replace(/\s+$/, '');
    if (t) push({ t: 'text', text: t, x: textAt.x + 1, y: textAt.y + 1, size: textAt.size, color: textAt.color });
    textAt = null; textIn.hidden = true; textIn.value = '';
  }

  /* ---------- Мышь ---------- */
  function inside(p) { return rect && p.x >= rect.x && p.x <= rect.x + rect.w && p.y >= rect.y && p.y <= rect.y + rect.h; }
  function pt(e) { return { x: Math.max(0, Math.min(W, e.clientX)), y: Math.max(0, Math.min(H, e.clientY)) }; }

  document.addEventListener('mousedown', function (e) {
    if (e.button !== 0 || e.target.closest('.glass') || e.target === textIn) return;
    var p = pt(e);
    if (mode === 'edit') {
      var h = e.target.dataset && e.target.dataset.h;
      if (h) { drag = { kind: 'resize', h: h, start: p, r0: Object.assign({}, rect) }; bar.hidden = true; return; }
      if (tool && inside(p)) {
        if (tool === 'text') { e.preventDefault(); startText(p); return; }
        if (tool === 'num') { push({ t: 'num', a: p, n: numSeq++, color: color, w: width }); return; }
        commitText();
        cur = { t: tool, color: color, w: width, a: p, b: p, pts: [p] };
        return;
      }
      if (!tool && inside(p)) { drag = { kind: 'move', start: p, r0: Object.assign({}, rect) }; bar.hidden = true; return; }
      if (!tool && !inside(p) && shapes.length === 0) {
        // Начать заново
        mode = 'pick'; body.classList.remove('edit'); bar.hidden = true;
      } else return;
    }
    drag = { kind: 'new', start: p };
    rect = { x: p.x, y: p.y, w: 0, h: 0 }; place();
  });
  document.addEventListener('mousemove', function (e) {
    var p = pt(e);
    if (cur) { cur.b = p; if (cur.t === 'pen' || cur.t === 'marker') cur.pts.push(p); redraw(); return; }
    if (!drag) return;
    if (drag.kind === 'new') { rect = norm(drag.start, p); }
    if (drag.kind === 'move') {
      rect.x = Math.max(0, Math.min(W - rect.w, drag.r0.x + p.x - drag.start.x));
      rect.y = Math.max(0, Math.min(H - rect.h, drag.r0.y + p.y - drag.start.y));
    }
    if (drag.kind === 'resize') {
      var r = drag.r0, x1 = r.x, y1 = r.y, x2 = r.x + r.w, y2 = r.y + r.h, h = drag.h;
      if (h.indexOf('w') >= 0) x1 = p.x; if (h.indexOf('e') >= 0) x2 = p.x;
      if (h.indexOf('n') >= 0) y1 = p.y; if (h.indexOf('s') >= 0) y2 = p.y;
      rect = norm({ x: x1, y: y1 }, { x: x2, y: y2 });
    }
    place();
  });
  document.addEventListener('mouseup', function () {
    if (cur) {
      var moved = Math.abs(cur.b.x - cur.a.x) + Math.abs(cur.b.y - cur.a.y) > 3 || cur.pts.length > 2;
      if (moved) push(cur); cur = null; redraw(); return;
    }
    if (!drag) return;
    var kind = drag.kind; drag = null;
    if (rect.w < 5 || rect.h < 5) {
      if (kind === 'new') { rect = null; place(); mode = 'pick'; body.classList.add('pick'); body.classList.remove('edit'); }
      return;
    }
    clampRect(rect); place();
    if (mode !== 'edit') enterEdit(); else placeBar();
  });
  document.addEventListener('dblclick', function (e) {
    if (e.target.closest('.glass') || tool) return;
    rect = { x: 0, y: 0, w: W, h: H }; enterEdit();
  });

  /* ---------- Итог: склеиваем снимок и рисунок в полном разрешении ---------- */
  function result() {
    commitText();
    var r = rect || { x: 0, y: 0, w: W, h: H };
    var sx = PW / W;
    var out = document.createElement('canvas');
    out.width = Math.max(1, Math.round(r.w * sx)); out.height = Math.max(1, Math.round(r.h * sx));
    var g = out.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.drawImage(base, Math.round(r.x * sx), Math.round(r.y * sx), out.width, out.height, 0, 0, out.width, out.height);
    if (shapes.length) {
      // Рисунок перерисовываем векторно прямо в размере снимка — линии и текст остаются чёткими
      g.save(); g.setTransform(sx, 0, 0, sx, -r.x * sx, -r.y * sx);
      g.imageSmoothingEnabled = true;
      shapes.forEach(function (s) { drawShape(g, s); });
      g.restore();
    }
    return out.toDataURL('image/png');
  }
  function finish(action) { window.snap.done(action, result()); }
  $('#copy').addEventListener('click', function () { finish('copy'); });
  $('#save').addEventListener('click', function () { finish('save'); });
  $('#close').addEventListener('click', function () { window.snap.cancel(); });

  /* ---------- Клавиатура ---------- */
  var KEYS = { p: 'pen', 'з': 'pen', m: 'marker', 'ь': 'marker', a: 'arrow', 'ф': 'arrow', l: 'line', 'д': 'line', r: 'rect', 'к': 'rect', o: 'ellipse', 'щ': 'ellipse', t: 'text', 'е': 'text', b: 'pixel', 'и': 'pixel', n: 'num', 'т': 'num' };
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { if (tool) return setTool(null); return window.snap.cancel(); }
    if (e.key === 'Enter' || (e.ctrlKey && /^[cс]$/i.test(e.key))) { e.preventDefault(); if (!rect) rect = { x: 0, y: 0, w: W, h: H }; return finish('copy'); }
    if (e.ctrlKey && /^[sы]$/i.test(e.key)) { e.preventDefault(); if (!rect) rect = { x: 0, y: 0, w: W, h: H }; return finish('save'); }
    if (e.ctrlKey && /^[zя]$/i.test(e.key)) { e.preventDefault(); return e.shiftKey ? redo() : undo(); }
    if (e.ctrlKey && /^[yн]$/i.test(e.key)) { e.preventDefault(); return redo(); }
    if (mode === 'edit' && !e.ctrlKey && KEYS[e.key.toLowerCase()]) setTool(KEYS[e.key.toLowerCase()]);
  });
})();
