const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('snap', {
  init: () => ipcRenderer.invoke('snap-init'),
  fallback: () => ipcRenderer.invoke('snap-fallback'),
  ready: () => ipcRenderer.send('snap-ready'),
  done: (action, dataUrl) => ipcRenderer.invoke('snap-done', action, dataUrl),
  cancel: () => ipcRenderer.send('snap-cancel')
});
