/* Inver FX: живой пиксельный фон и синтезированные звуки (без файлов) */
(function () {
  'use strict';

  function hexRgb(h) {
    var m = /^#?([0-9a-f]{6})$/i.exec((h || '').trim());
    var n = parseInt(m ? m[1] : '7C3AED', 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  /* ---------------- Пиксельный фон ----------------
     Экономная схема: каждый квадратик сетки — это один пиксель маленького холста (cols × rows).
     Видеокарта растягивает его без сглаживания, а зазоры между квадратиками рисует
     неподвижный CSS-слой поверх. Так за кадр считается ~16 тыс. чисел вместо 16 тыс. отрисовок. */
  var SCENES = {
    normal: { cell: 12, bg: [11, 11, 16] },
    space: { cell: 16, bg: [5, 5, 7] }
  };
  var Pixels = {
    canvas: null, ctx: null, grid: null, W: 0, H: 0, cols: 0, rows: 0, img: null,
    mode: 'live', scene: 'normal', accent: '#7C3AED', perf: 'auto', wall: 'blobs', wstate: null, wkind: '',
    mouse: { x: 0, y: 0, active: false }, follow: { x: 0, y: 0 },
    sparks: [], sparkLife: null, calm: [], t0: 0, raf: 0, paused: false, last: 0, slow: 0,
    isCovered: function () { return false; },

    init: function (canvas) {
      var self = this;
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d', { alpha: false });
      this.grid = document.createElement('div');
      this.grid.id = 'bgGrid';
      this.grid.setAttribute('aria-hidden', 'true');
      canvas.parentNode.insertBefore(this.grid, canvas.nextSibling);
      this.t0 = performance.now();
      this.resize();
      window.addEventListener('resize', function () { self.resize(); });
      window.addEventListener('mousemove', function (e) { self.mouse.x = e.clientX; self.mouse.y = e.clientY; self.mouse.active = true; }, { passive: true });
      document.addEventListener('mouseleave', function () { self.mouse.active = false; });
      document.addEventListener('visibilitychange', function () { self.paused = document.hidden; });
      var reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
      var loop = function (now) {
        self.raf = requestAnimationFrame(loop);
        if (self.paused || self.isCovered()) return;
        // Частота кадров: 60 в обычном режиме, 30 когда окно в фоне или комп не тянет, 20 в экономии
        var fps = self.perf === 'eco' ? 20 : (self.perf === 'auto' && (!document.hasFocus() || self.slow > 20)) ? 30 : 60;
        if (reduce.matches) fps = 8;
        if (now - self.last < 1000 / fps - 2) return;
        self.last = now;
        var t1 = performance.now();
        self.draw(now);
        var cost = performance.now() - t1;
        // Если кадр стабильно дорогой — сами снижаем частоту, и обратно, когда стало легко
        self.slow = cost > 7 ? Math.min(60, self.slow + 1) : Math.max(0, self.slow - 1);
      };
      this.raf = requestAnimationFrame(loop);
    },
    resize: function () {
      var sc = SCENES[this.scene] || SCENES.normal;
      this.W = window.innerWidth; this.H = window.innerHeight;
      this.cols = Math.ceil(this.W / sc.cell); this.rows = Math.ceil(this.H / sc.cell);
      this.canvas.width = this.cols; this.canvas.height = this.rows;
      this.canvas.style.width = (this.cols * sc.cell) + 'px';
      this.canvas.style.height = (this.rows * sc.cell) + 'px';
      this.img = this.ctx.createImageData(this.cols, this.rows);
      this.sparkLife = new Float32Array(this.cols * this.rows);
      this.sparks = []; this.calm = [];
      this.sinCol = new Float32Array(this.cols); this.cosRow = new Float32Array(this.rows);
      this.grid.className = this.scene === 'space' ? 'space' : '';
      this._scene = this.scene;
      if (!this.follow.x) { this.follow.x = this.W / 2; this.follow.y = this.H / 2; }
    },
    draw: function (now) {
      if (this._scene !== this.scene) this.resize();
      var wk = this.scene + '|' + this.wall;
      if (this._wk !== wk) { this._wk = wk; if (this.sparkLife) this.sparkLife.fill(0); this.sparks = []; this.calm = []; this.wkind = ''; }
      if (this.scene === 'space') this.drawSpace(now); else if (this.wall && this.wall !== 'blobs' && this.wall !== 'image') this.drawWall(now); else this.drawNormal(now);
      this.ctx.putImageData(this.img, 0, 0);
    },
    drawNormal: function (now) {
      var W = this.W, H = this.H, cols = this.cols, rows = this.rows, cell = 12, d = this.img.data;
      var mode = this.mode;
      var t = (now - this.t0) / 1000 * (mode === 'calm' ? 0.35 : 1);
      var strength = mode === 'off' ? 0 : mode === 'calm' ? 0.55 : 1;
      var acc = hexRgb(this.accent), bg = SCENES.normal.bg;
      var defs = [[0.28, 0.35, 0.23, 0.31, 165, 0.0], [0.72, 0.30, 0.19, 0.27, 140, 1.3], [0.50, 0.72, 0.29, 0.17, 185, 2.1], [0.18, 0.76, 0.13, 0.23, 120, 3.7], [0.84, 0.70, 0.21, 0.15, 150, 4.4], [0.56, 0.22, 0.11, 0.29, 105, 5.2]];
      var k = Math.max(W, H) / 1280;
      var bx = [], by = [], br2 = [];
      for (var b = 0; b < defs.length; b++) {
        var q = defs[b], r = q[4] * k * (0.82 + 0.22 * Math.sin(t * 0.6 + q[5] * 2));
        bx.push(W * (q[0] + 0.17 * Math.sin(t * q[2] + q[5]))); by.push(H * (q[1] + 0.15 * Math.cos(t * q[3] + q[5] * 1.3))); br2.push(r * r);
      }
      var tx = this.mouse.active ? this.mouse.x : W * (0.5 + 0.3 * Math.sin(t * 0.21));
      var ty = this.mouse.active ? this.mouse.y : H * (0.5 + 0.25 * Math.cos(t * 0.17));
      this.follow.x += (tx - this.follow.x) * 0.05;
      this.follow.y += (ty - this.follow.y) * 0.05;
      var fr = (115 + 15 * Math.sin(t * 2.2)) * k;
      bx.push(this.follow.x); by.push(this.follow.y); br2.push(fr * fr);
      var nb = bx.length;

      // Огоньки
      var life = this.sparkLife;
      if (strength > 0 && Math.random() < 0.9 * strength) {
        for (var s = 0; s < 4; s++) { var idx = ((Math.random() * rows) | 0) * cols + ((Math.random() * cols) | 0); life[idx] = 1; this.sparks.push(idx); }
      }
      var keep = [];
      for (var i = 0; i < this.sparks.length; i++) { var id = this.sparks[i]; life[id] -= 0.035; if (life[id] > 0) keep.push(id); else life[id] = 0; }
      this.sparks = keep;

      // Волна разделяется на множители по столбцам и строкам — считаем их один раз за кадр
      var sc = this.sinCol, cr = this.cosRow, c, row;
      for (c = 0; c < cols; c++) sc[c] = Math.sin((c * cell + cell / 2) * 0.012 + t * 1.1);
      for (row = 0; row < rows; row++) cr[row] = Math.cos((row * cell + cell / 2) * 0.015 - t * 0.9);

      var p = 0;
      for (row = 0; row < rows; row++) {
        var py = row * cell + cell / 2;
        for (c = 0; c < cols; c++, p += 4) {
          var px = c * cell + cell / 2, f = 0;
          for (var j = 0; j < nb; j++) { var dx = px - bx[j], dy = py - by[j]; f += br2[j] / (dx * dx + dy * dy + 1); }
          f *= (1 + 0.24 * sc[c] * cr[row]) * strength;
          var R = bg[0], G = bg[1], B = bg[2], a;
          if (f > 1) {
            var m = Math.min(1, (f - 1) / 1.8) * 0.6;
            R = (acc[0] + (255 - acc[0]) * m) * 0.92 + bg[0] * 0.08;
            G = (acc[1] + (255 - acc[1]) * m) * 0.92 + bg[1] * 0.08;
            B = (acc[2] + (255 - acc[2]) * m) * 0.92 + bg[2] * 0.08;
          } else if (f > 0.6) {
            a = 0.14 + ((f - 0.6) / 0.4) * 0.4;
            R = acc[0] * a + bg[0] * (1 - a); G = acc[1] * a + bg[1] * (1 - a); B = acc[2] * a + bg[2] * (1 - a);
          } else {
            var lf = life[p >> 2];
            if (lf > 0) { a = lf * 0.7; R = 244 * a + bg[0] * (1 - a); G = 241 * a + bg[1] * (1 - a); B = 234 * a + bg[2] * (1 - a); }
          }
          d[p] = R; d[p + 1] = G; d[p + 2] = B; d[p + 3] = 255;
        }
      }
    },
    /* Живые сцены: дождь, звёзды, огонь, волны. Каждая клетка — пиксель маленького холста */
    drawWall: function (now) {
      var cols = this.cols, rows = this.rows, d = this.img.data, n = cols * rows;
      var mode = this.mode, k = mode === 'calm' ? 0.4 : 1, strength = mode === 'off' ? 0 : mode === 'calm' ? 0.6 : 1;
      var t = (now - this.t0) / 1000 * k;
      var acc = hexRgb(this.accent), bg = SCENES.normal.bg, wall = this.wall;
      if (this.wkind !== wall + cols + 'x' + rows) { this.wkind = wall + cols + 'x' + rows; this.wstate = { heat: new Float32Array(n), cols: [], stars: [], shoot: null, last: now }; }
      var S = this.wstate, dt = Math.min(0.1, (now - S.last) / 1000) * k; S.last = now;
      var v = this.sparkLife; // переиспользуем буфер как «яркость акцента»
      var wv = S.heat;
      var i, c, r;
      if (wall === 'rain') {
        if (!S.cols.length) for (c = 0; c < cols; c++) S.cols.push({ y: Math.random() * rows, sp: 8 + Math.random() * 18, len: 4 + Math.random() * 10, on: Math.random() < 0.55 });
        for (i = 0; i < n; i++) { v[i] *= 0.82; }
        for (c = 0; c < cols; c++) {
          var dr = S.cols[c];
          dr.y += dr.sp * dt;
          if (dr.y - dr.len > rows) { dr.y = -Math.random() * rows * 0.5; dr.sp = 8 + Math.random() * 18; dr.on = Math.random() < 0.6; }
          if (!dr.on) continue;
          var hy = Math.floor(dr.y);
          for (r = 0; r < dr.len; r++) { var yy = hy - r; if (yy >= 0 && yy < rows) v[yy * cols + c] = Math.max(v[yy * cols + c], (1 - r / dr.len) * strength); }
          if (hy >= 0 && hy < rows) wv[hy * cols + c] = strength; // яркая головка капли
        }
        for (i = 0; i < n; i++) wv[i] *= 0.6;
      } else if (wall === 'stars') {
        if (!S.stars.length) for (i = 0; i < n * 0.035; i++) S.stars.push({ i: (Math.random() * n) | 0, ph: Math.random() * 6.28, sp: 0.6 + Math.random() * 2.2, b: 0.3 + Math.random() * 0.7, acc: Math.random() < 0.25 });
        for (i = 0; i < n; i++) { v[i] = 0; wv[i] = 0; }
        S.stars.forEach(function (st) { var tw = (0.55 + 0.45 * Math.sin(t * st.sp + st.ph)) * st.b * strength; if (st.acc) v[st.i] = tw; else wv[st.i] = tw * 0.8; });
        if (!S.shoot && Math.random() < 0.006 * strength) S.shoot = { x: Math.random() * cols * 0.7, y: Math.random() * rows * 0.4, life: 1 };
        if (S.shoot) {
          var sh = S.shoot; sh.x += 40 * dt; sh.y += 18 * dt; sh.life -= dt * 0.9;
          for (r = 0; r < 12; r++) { var sx = Math.round(sh.x - r * 0.9), sy = Math.round(sh.y - r * 0.4); if (sx >= 0 && sx < cols && sy >= 0 && sy < rows) wv[sy * cols + sx] = Math.max(0, sh.life) * (1 - r / 12); }
          if (sh.life <= 0 || sh.x > cols) S.shoot = null;
        }
      } else if (wall === 'fire') {
        // Классический пиксельный огонь: тепло поднимается снизу и остывает
        var base = rows - 1;
        for (c = 0; c < cols; c++) wv[base * cols + c] = (0.75 + Math.random() * 0.25) * strength * (0.55 + 0.45 * Math.sin(c * 0.09 + t * 0.6) * Math.sin(c * 0.031 - t * 0.3) + 0.45);
        var steps = Math.max(1, Math.round(dt * 60));
        for (var stp = 0; stp < steps; stp++) {
          for (r = 0; r < base; r++) for (c = 0; c < cols; c++) {
            var src = (r + 1) * cols + Math.min(cols - 1, Math.max(0, c + ((Math.random() * 3) | 0) - 1));
            wv[r * cols + c] = Math.max(0, wv[src] - Math.random() * 0.045 - 0.006);
          }
        }
        for (i = 0; i < n; i++) v[i] = wv[i];
      } else {
        // Волны: несколько синусоид, видны как светящиеся контуры
        for (r = 0; r < rows; r++) for (c = 0; c < cols; c++) {
          i = r * cols + c;
          var y = r / rows;
          var w1 = 0.5 + 0.12 * Math.sin(c * 0.06 + t * 0.8) + 0.05 * Math.sin(c * 0.17 - t * 1.3);
          var w2 = 0.68 + 0.1 * Math.sin(c * 0.045 - t * 0.6 + 2) + 0.04 * Math.sin(c * 0.13 + t);
          var w3 = 0.84 + 0.07 * Math.sin(c * 0.08 + t * 0.5 + 4);
          var a = 0;
          [w1, w2, w3].forEach(function (w, j) { var dd = y - w; if (dd > 0) a = Math.max(a, (0.18 + j * 0.16) * Math.min(1, dd * 6)); var e = Math.abs(dd) * rows; if (e < 1.2) a = Math.max(a, 0.9 - e * 0.5); });
          v[i] = a * strength;
          wv[i] = 0;
        }
      }
      var p = 0;
      for (i = 0; i < n; i++, p += 4) {
        var av = Math.min(1, v[i]), wt = Math.min(1, wv[i]), R = bg[0], G = bg[1], B = bg[2];
        if (wall === 'fire') {
          // от тёмного к акценту, потом к белому
          if (av > 0.02) { var a1 = Math.min(1, av * 1.6), a2 = Math.max(0, av - 0.62) / 0.38; R = bg[0] + (acc[0] - bg[0]) * a1; G = bg[1] + (acc[1] - bg[1]) * a1; B = bg[2] + (acc[2] - bg[2]) * a1; R += (255 - R) * a2 * 0.8; G += (240 - G) * a2 * 0.8; B += (220 - B) * a2 * 0.8; }
        } else {
          if (av > 0.01) { R = bg[0] + (acc[0] - bg[0]) * av; G = bg[1] + (acc[1] - bg[1]) * av; B = bg[2] + (acc[2] - bg[2]) * av; }
          if (wt > 0.01) { R += (244 - R) * wt; G += (241 - G) * wt; B += (234 - B) * wt; }
        }
        d[p] = R; d[p + 1] = G; d[p + 2] = B; d[p + 3] = 255;
      }
    },
    // Спокойный фон Space: еле заметные пиксели, медленная волна, редкие огоньки
    drawSpace: function (now) {
      var cols = this.cols, rows = this.rows, d = this.img.data;
      var t = (now - this.t0) / 1000;
      var acc = hexRgb(this.accent), bg = SCENES.space.bg;
      var wave = ((t * 0.09) % 1.6) - 0.3;
      if (this.calm.length < 7 && Math.random() < 0.03) this.calm.push({ c: (Math.random() * cols) | 0, r: (Math.random() * rows) | 0, born: t, life: 3 + Math.random() * 3 });
      var lit = this.sparkLife, keep = [], k;
      for (k = 0; k < this.calm.length; k++) lit[this.calm[k].r * cols + this.calm[k].c] = 0;
      for (k = 0; k < this.calm.length; k++) {
        var q = this.calm[k], age = (t - q.born) / q.life;
        if (age < 1) { keep.push(q); lit[q.r * cols + q.c] = Math.sin(age * Math.PI); }
      }
      this.calm = keep;
      var p = 0;
      for (var row = 0; row < rows; row++) {
        var cRow = Math.cos(row * 0.29 - t * 0.17);
        for (var col = 0; col < cols; col++, p += 4) {
          var v = Math.sin(col * 0.33 + t * 0.22) * cRow + Math.sin((col + row) * 0.11 + t * 0.13);
          var band = Math.max(0, 1 - Math.abs((col / cols + row / rows) * 0.5 - wave) / 0.06);
          var glow = lit[p >> 2], R = bg[0], G = bg[1], B = bg[2], a;
          if (glow > 0) { a = 0.45 * glow; R = acc[0] * a + bg[0] * (1 - a); G = acc[1] * a + bg[1] * (1 - a); B = acc[2] * a + bg[2] * (1 - a); }
          else if (v > 1.15) { a = 0.035 + Math.min(1, (v - 1.15) / 0.8) * 0.05 + band * 0.05; R = 244 * a + bg[0] * (1 - a); G = 241 * a + bg[1] * (1 - a); B = 234 * a + bg[2] * (1 - a); }
          else if (band > 0.2) { a = band * 0.07; R = acc[0] * a + bg[0] * (1 - a); G = acc[1] * a + bg[1] * (1 - a); B = acc[2] * a + bg[2] * (1 - a); }
          d[p] = R; d[p + 1] = G; d[p + 2] = B; d[p + 3] = 255;
        }
      }
    }
  };

  /* ---------------- Звук ---------------- */
  var Sound = {
    ac: null, master: null, enabled: true, volume: 0.8, cache: {},
    ctx: function () {
      if (!this.enabled) return null;
      if (!this.ac) {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        this.ac = new AC();
        this.master = this.ac.createGain();
        this.master.connect(this.ac.destination);
      }
      if (this.ac.state === 'suspended') this.ac.resume();
      this.master.gain.value = this.volume * 1.1;
      return this.ac;
    },
    noise: function (ac, dur) {
      if (this.cache[dur]) return this.cache[dur];
      var len = Math.floor(ac.sampleRate * dur), buf = ac.createBuffer(1, len, ac.sampleRate), d = buf.getChannelData(0);
      for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      return (this.cache[dur] = buf);
    },
    crack: function (power) {
      var ac = this.ctx(); if (!ac) return;
      var t = ac.currentTime + 0.005, out = this.master;
      var grains = 3 + Math.round(power * 6);
      for (var i = 0; i < grains; i++) {
        var o = i === 0 ? 0 : Math.random() * 0.1 * (0.5 + power);
        var src = ac.createBufferSource(); src.buffer = this.noise(ac, 0.3);
        var bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1500 + Math.random() * 4500; bp.Q.value = 1.1;
        var g = ac.createGain(), peak = (i === 0 ? 1 : 0.4) * power, len = (i === 0 ? 0.09 : 0.035) * (0.6 + power);
        g.gain.setValueAtTime(0.0001, t + o); g.gain.linearRampToValueAtTime(peak, t + o + 0.002); g.gain.exponentialRampToValueAtTime(0.0001, t + o + len);
        src.connect(bp); bp.connect(g); g.connect(out); src.start(t + o); src.stop(t + o + 0.3);
      }
      var osc = ac.createOscillator(); osc.type = 'sine';
      osc.frequency.setValueAtTime(95, t); osc.frequency.exponentialRampToValueAtTime(36, t + 0.2);
      var og = ac.createGain(); og.gain.setValueAtTime(0.0001, t); og.gain.linearRampToValueAtTime(0.7 * power, t + 0.004); og.gain.exponentialRampToValueAtTime(0.0001, t + 0.18 + 0.12 * power);
      osc.connect(og); og.connect(out); osc.start(t); osc.stop(t + 0.5);
    },
    whoosh: function (up) {
      var ac = this.ctx(); if (!ac) return;
      var t = ac.currentTime + 0.005;
      var src = ac.createBufferSource(); src.buffer = this.noise(ac, 1.2);
      var bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 0.9;
      bp.frequency.setValueAtTime(up ? 250 : 3200, t); bp.frequency.exponentialRampToValueAtTime(up ? 3200 : 250, t + 0.75);
      var g = ac.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.45, t + 0.25); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.95);
      src.connect(bp); bp.connect(g); g.connect(this.master); src.start(t); src.stop(t + 1.2);
    },
    // Фирменный мотив Inver: три ноты вверх (вход) или вниз (выход)
    chime: function (up) {
      var ac = this.ctx(); if (!ac) return;
      var notes = up === false ? [1046.5, 783.99, 523.25] : [523.25, 783.99, 1046.5], t0 = ac.currentTime + 0.01;
      for (var i = 0; i < notes.length; i++) {
        var t = t0 + i * 0.11, last = i === notes.length - 1;
        var g = ac.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(last ? 0.24 : 0.17, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + (last ? 1.4 : 0.7)); g.connect(this.master);
        var a = ac.createOscillator(); a.type = 'triangle'; a.frequency.value = notes[i]; a.connect(g);
        var b = ac.createOscillator(); b.type = 'sine'; b.frequency.value = notes[i] * 2.005;
        var bg = ac.createGain(); bg.gain.value = 0.25; b.connect(bg); bg.connect(g);
        a.start(t); b.start(t); a.stop(t + 1.5); b.stop(t + 1.5);
      }
    },
    theme: 'inver',
    blip: function (freq, delay, vol) {
      var th = this.theme;
      if (th === 'off') return;
      if (th === 'keys') return this.key(delay, vol);
      if (th === 'retro') return this.retro(freq, delay, vol);
      if (th === 'soft') return this.soft(freq, delay, vol);
      var ac = this.ctx(); if (!ac) return;
      var t = ac.currentTime + 0.01 + (delay || 0);
      var o = ac.createOscillator(); o.type = 'square'; o.frequency.setValueAtTime(freq, t); o.frequency.exponentialRampToValueAtTime(freq * 1.5, t + 0.05);
      var lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3200;
      var g = ac.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol || 0.08, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.09);
      o.connect(lp); lp.connect(g); g.connect(this.master); o.start(t); o.stop(t + 0.12);
    },
    // Механическая клавиатура: короткий щелчок шума и низкий «тук»
    key: function (delay, vol) {
      var ac = this.ctx(); if (!ac) return;
      var t = ac.currentTime + 0.005 + (delay || 0), v = (vol || 0.06) * 6;
      var src = ac.createBufferSource(); src.buffer = this.noise(ac, 0.3);
      var bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 2600 + Math.random() * 1600; bp.Q.value = 2;
      var g = ac.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + 0.001); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.03);
      src.connect(bp); bp.connect(g); g.connect(this.master); src.start(t); src.stop(t + 0.05);
      var o = ac.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(180, t); o.frequency.exponentialRampToValueAtTime(90, t + 0.04);
      var og = ac.createGain(); og.gain.setValueAtTime(0.0001, t); og.gain.linearRampToValueAtTime(v * 0.5, t + 0.002); og.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
      o.connect(og); og.connect(this.master); o.start(t); o.stop(t + 0.07);
    },
    // Ретро 8-бит: квадратная волна, ступенчатая нота
    retro: function (freq, delay, vol) {
      var ac = this.ctx(); if (!ac) return;
      var t = ac.currentTime + 0.01 + (delay || 0), f = 110 * Math.pow(2, Math.round(12 * Math.log2(freq / 110)) / 12);
      var o = ac.createOscillator(); o.type = 'square';
      o.frequency.setValueAtTime(f, t); o.frequency.setValueAtTime(f * 1.5, t + 0.035);
      var g = ac.createGain(); g.gain.setValueAtTime((vol || 0.06) * 0.9, t); g.gain.setValueAtTime(0.0001, t + 0.075);
      o.connect(g); g.connect(this.master); o.start(t); o.stop(t + 0.08);
    },
    // Тихие: мягкий синус, едва слышно
    soft: function (freq, delay, vol) {
      var ac = this.ctx(); if (!ac) return;
      var t = ac.currentTime + 0.01 + (delay || 0);
      var o = ac.createOscillator(); o.type = 'sine'; o.frequency.value = freq * 0.75;
      var g = ac.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime((vol || 0.06) * 0.5, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);
      o.connect(g); g.connect(this.master); o.start(t); o.stop(t + 0.16);
    },
    shutter: function () {
      var ac = this.ctx(); if (!ac) return;
      var t = ac.currentTime + 0.005;
      for (var i = 0; i < 2; i++) {
        var o = i * 0.07, src = ac.createBufferSource(); src.buffer = this.noise(ac, 0.3);
        var hp = ac.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = i === 0 ? 2500 : 1600;
        var g = ac.createGain(); g.gain.setValueAtTime(0.0001, t + o); g.gain.linearRampToValueAtTime(i === 0 ? 0.5 : 0.35, t + o + 0.002); g.gain.exponentialRampToValueAtTime(0.0001, t + o + 0.05);
        src.connect(hp); hp.connect(g); g.connect(this.master); src.start(t + o); src.stop(t + o + 0.2);
      }
    }
  };

  window.FX = { Pixels: Pixels, Sound: Sound, hexRgb: hexRgb };
})();
