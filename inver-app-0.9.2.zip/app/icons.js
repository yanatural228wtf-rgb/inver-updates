// Inver Icons — подбор качественных иконок сайтов (главный процесс)
// Порядок: apple-touch-icon и иконки из манифеста (большие квадратные) → SVG-иконка → крупные PNG
// → сервис иконок 256px. Растровые картинки уменьшаются до 128px с хорошим качеством, маленькие отбрасываются.
const { app, nativeImage, net } = require('electron');
const path = require('path');
const fs = require('fs');

const MIN = 48;          // меньше — будет мыльно, лучше плитка в цвет темы
const OUT = 128;         // хранимый размер: чётко на экранах до 3x
const TTL_OK = 14 * 864e5, TTL_NONE = 6 * 3600e3;
let cache = null, cacheFile = '', saveT = null;
const pending = new Map();

function load() {
  if (cache) return;
  cacheFile = path.join(app.getPath('userData'), 'icon-cache-v2.json');
  try { cache = JSON.parse(fs.readFileSync(cacheFile, 'utf8')); } catch (e) { cache = {}; }
}
function save() {
  clearTimeout(saveT);
  saveT = setTimeout(() => {
    const keys = Object.keys(cache);
    if (keys.length > 400) keys.sort((a, b) => cache[a].ts - cache[b].ts).slice(0, keys.length - 400).forEach((k) => delete cache[k]);
    try { fs.writeFileSync(cacheFile, JSON.stringify(cache)); } catch (e) {}
  }, 800);
}

// Загрузка через сетевой модуль Electron (работает в любой версии и через прокси сессии)
function viaRequest(ses, url, ms) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (!done) { done = true; clearTimeout(t); resolve(v); } };
    const t = setTimeout(() => { try { req.abort(); } catch (e) {} finish(null); }, ms || 6000);
    let req;
    try { req = net.request({ url, session: ses, redirect: 'follow', useSessionCookies: true }); } catch (e) { return finish(null); }
    req.setHeader('accept-language', 'ru,en;q=0.8');
    req.setHeader('user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36');
    let finalUrl = url;
    req.on('redirect', (_s, _m, u) => { finalUrl = u; });
    req.on('response', (res) => {
      if (res.statusCode < 200 || res.statusCode >= 300) { finish(null); return; }
      const chunks = []; let size = 0;
      res.on('data', (c) => { size += c.length; if (size > 4e6) { try { req.abort(); } catch (e) {} finish(null); return; } chunks.push(c); });
      res.on('end', () => {
        const buf = Buffer.concat(chunks);
        const h = res.headers || {};
        const get = (k) => { const v = h[k.toLowerCase()]; return Array.isArray(v) ? v[0] : (v || ''); };
        finish({ ok: true, url: finalUrl, headers: { get }, text: async () => buf.toString('utf8'), json: async () => JSON.parse(buf.toString('utf8')), arrayBuffer: async () => buf });
      });
      res.on('error', () => finish(null));
    });
    req.on('error', () => finish(null));
    req.end();
  });
}

async function get(ses, url, ms) {
  if (ses && typeof ses.fetch === 'function' && !ses.__noFetch) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms || 6000);
    try {
      const r = await ses.fetch(url, { signal: ctrl.signal, redirect: 'follow', headers: { 'accept-language': 'ru,en;q=0.8' } });
      return r.ok ? r : null;
    } catch (e) {
      if (!(e && e.name === 'AbortError')) ses.__noFetch = true; else return null;
    } finally { clearTimeout(t); }
  }
  return viaRequest(ses, url, ms);
}

function attrs(tag) {
  const o = {};
  tag.replace(/([a-zA-Z-:]+)\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))/g, (_m, k, _v, a, b, c) => { o[k.toLowerCase()] = a !== undefined ? a : b !== undefined ? b : c; });
  return o;
}
function sizeOf(s) { const m = String(s || '').match(/(\d+)x(\d+)/i); return m ? Math.min(+m[1], +m[2]) : 0; }

const hints = new Map();
async function candidates(ses, host) {
  const base = 'https://' + host + '/';
  const list = (hints.get(host) || []).map((u) => ({ url: u, size: 0, full: false, svg: /\.svg(\?|$)/i.test(u), score: 150 }));
  const res = await get(ses, base, 7000);
  let finalBase = base;
  if (res) {
    finalBase = res.url || base;
    const ct = res.headers.get('content-type') || '';
    if (/html/i.test(ct)) {
      const html = (await res.text()).slice(0, 400000);
      const head = html.split(/<\/head>/i)[0];
      (head.match(/<link\b[^>]*>/gi) || []).forEach((tag) => {
        const a = attrs(tag); const rel = (a.rel || '').toLowerCase();
        if (!a.href) return;
        let href; try { href = new URL(a.href, finalBase).href; } catch (e) { return; }
        if (/apple-touch-icon/.test(rel)) list.push({ url: href, size: sizeOf(a.sizes) || 180, full: true, score: 300 });
        else if (/\bicon\b/.test(rel)) {
          const svg = /svg/i.test(a.type || '') || /\.svg(\?|$)/i.test(href);
          const sz = svg ? 512 : sizeOf(a.sizes);
          list.push({ url: href, size: sz, full: false, svg, score: svg ? 250 : sz });
        } else if (/manifest/.test(rel)) list.push({ manifest: href });
      });
    }
  }
  // Иконки из манифеста PWA — обычно 192/512px
  for (const m of list.filter((x) => x.manifest)) {
    const r = await get(ses, m.manifest, 5000);
    if (!r) continue;
    try {
      const j = await r.json();
      (j.icons || []).forEach((ic) => {
        if (!ic.src) return;
        const sz = Math.max(...String(ic.sizes || '0x0').split(/\s+/).map(sizeOf));
        let href; try { href = new URL(ic.src, m.manifest).href; } catch (e) { return; }
        const maskable = /maskable/.test(ic.purpose || '');
        list.push({ url: href, size: sz, full: maskable, score: 200 + Math.min(sz, 512) / 10 });
      });
    } catch (e) {}
  }
  list.push({ url: new URL('/apple-touch-icon.png', finalBase).href, size: 180, full: true, score: 120 });
  list.push({ url: 'https://www.google.com/s2/favicons?domain=' + encodeURIComponent(host) + '&sz=256', size: 256, full: false, score: 50 });
  list.push({ url: 'https://icons.duckduckgo.com/ip3/' + encodeURIComponent(host) + '.ico', size: 64, full: false, score: 10 });
  return list.filter((x) => x.url).sort((a, b) => b.score - a.score);
}

async function fetchImage(ses, c) {
  const r = await get(ses, c.url, 6000);
  if (!r) return null;
  const ct = (r.headers.get('content-type') || '').toLowerCase();
  const buf = Buffer.from(await r.arrayBuffer());
  if (!buf.length || buf.length > 3e6) return null;
  if (c.svg || /svg/.test(ct) || /^\s*<(\?xml|svg)/i.test(buf.slice(0, 100).toString())) {
    if (!/<svg[\s>]/i.test(buf.toString('utf8'))) return null;
    return { src: 'data:image/svg+xml;base64,' + buf.toString('base64'), size: 512, full: false, vector: true };
  }
  let img = nativeImage.createFromBuffer(buf);
  if (img.isEmpty()) return null;
  const { width, height } = img.getSize();
  const side = Math.min(width, height);
  if (side < MIN) return null;
  // Квадратная ли картинка без прозрачных краёв — тогда показываем её во всю плитку
  let opaqueCorners = false;
  try {
    const bmp = img.resize({ width: 16, height: 16 }).toBitmap();
    const a = (x, y) => bmp[(y * 16 + x) * 4 + 3];
    opaqueCorners = a(1, 1) > 240 && a(14, 1) > 240 && a(1, 14) > 240 && a(14, 14) > 240;
  } catch (e) {}
  if (side > OUT || width !== height) img = img.resize({ width: OUT, height: Math.round(OUT * height / width), quality: 'best' });
  return { src: img.toDataURL(), size: side, full: c.full || opaqueCorners };
}

async function resolve(ses, host) {
  const list = await candidates(ses, host);
  for (const c of list) {
    const got = await fetchImage(ses, c);
    if (got) return got;
  }
  return null;
}

function iconFor(ses, host) {
  load();
  host = String(host || '').toLowerCase().replace(/^www\./, '');
  if (!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(host)) return Promise.resolve(null);
  const hit = cache[host];
  if (hit && Date.now() - hit.ts < (hit.none ? TTL_NONE : TTL_OK)) return Promise.resolve(hit.none ? null : hit.icon);
  if (pending.has(host)) return pending.get(host);
  const p = resolve(ses, host).then((icon) => {
    cache[host] = icon ? { icon, ts: Date.now() } : { none: 1, ts: Date.now() };
    save(); pending.delete(host);
    return icon;
  }).catch(() => { pending.delete(host); return hit && hit.icon || null; });
  pending.set(host, p);
  return p;
}

// Сайт сам сообщил свои иконки (когда открыт во вкладке) — пробуем их, если хорошей иконки ещё нет
function hint(ses, host, urls) {
  load();
  host = String(host || '').toLowerCase().replace(/^www\./, '');
  const list = (urls || []).filter((u) => /^https?:/i.test(u)).slice(0, 6);
  if (!host || !list.length) return Promise.resolve(null);
  hints.set(host, list);
  const hit = cache[host];
  if (hit && hit.icon && hit.icon.size >= 128) return Promise.resolve(hit.icon);
  if (hit) delete cache[host];
  return iconFor(ses, host);
}

module.exports = { iconFor, hint };
