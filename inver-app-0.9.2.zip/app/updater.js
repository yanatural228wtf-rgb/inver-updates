// Inver Updater — тихие автообновления без участия пользователя.
// Раз в несколько часов Inver смотрит файл latest.json в репозитории обновлений на GitHub.
// Если версия новее — скачивает архив программы, сверяет контрольную сумму, распаковывает
// и кладёт новые файлы поверх старых. Новая версия включается при следующем запуске
// (или сразу, если окно Inver скрыто в трее).
const { app, net } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { execFile } = require('child_process');

const pkg = require('./package.json');
const cfg = pkg.inverUpdate || {};
const CHECK_EVERY = 3 * 3600e3;

let ses = null, notify = () => {}, busy = false, pending = null, timer = null;

function sources(file) {
  if (!cfg.owner || !cfg.repo) return [];
  const branch = cfg.branch || 'main';
  const bust = file === 'latest.json' ? '?t=' + Date.now() : '';
  return [
    'https://raw.githubusercontent.com/' + cfg.owner + '/' + cfg.repo + '/' + branch + '/' + file + bust,
    'https://cdn.jsdelivr.net/gh/' + cfg.owner + '/' + cfg.repo + '@' + branch + '/' + file + bust
  ];
}

function fetchBuffer(url, limit) {
  return new Promise((resolve, reject) => {
    let req;
    try { req = net.request({ url, session: ses || undefined, redirect: 'follow', useSessionCookies: false }); } catch (e) { return reject(e); }
    const t = setTimeout(() => { try { req.abort(); } catch (e) {} reject(new Error('timeout')); }, 60000);
    req.setHeader('user-agent', 'Inver-Updater');
    req.setHeader('cache-control', 'no-cache');
    req.on('response', (res) => {
      if (res.statusCode !== 200) { clearTimeout(t); res.on('data', () => {}); return reject(new Error('HTTP ' + res.statusCode)); }
      const chunks = []; let size = 0;
      res.on('data', (c) => { size += c.length; if (size > (limit || 60e6)) { try { req.abort(); } catch (e) {} clearTimeout(t); reject(new Error('too big')); return; } chunks.push(c); });
      res.on('end', () => { clearTimeout(t); resolve(Buffer.concat(chunks)); });
      res.on('error', (e) => { clearTimeout(t); reject(e); });
    });
    req.on('error', (e) => { clearTimeout(t); reject(e); });
    req.end();
  });
}
async function fetchFirst(file, limit) {
  let last;
  for (const u of sources(file)) { try { return await fetchBuffer(u, limit); } catch (e) { last = e; } }
  throw last || new Error('no source');
}

function newer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) > (pb[i] || 0)) return true; if ((pa[i] || 0) < (pb[i] || 0)) return false; }
  return false;
}

function unzip(zip, dir) {
  fs.mkdirSync(dir, { recursive: true });
  return new Promise((resolve, reject) => {
    execFile('tar', ['-xf', zip, '-C', dir], { windowsHide: true }, (err) => {
      if (!err) return resolve();
      execFile('powershell.exe', ['-NoProfile', '-Command', 'Expand-Archive -LiteralPath "' + zip + '" -DestinationPath "' + dir + '" -Force'], { windowsHide: true }, (e2) => e2 ? reject(e2) : resolve());
    });
  });
}

function findAppRoot(dir) {
  if (fs.existsSync(path.join(dir, 'main.js')) && fs.existsSync(path.join(dir, 'package.json'))) return dir;
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) if (ent.isDirectory()) { const f = findAppRoot(path.join(dir, ent.name)); if (f) return f; }
  return null;
}

async function check(manual) {
  if (busy || !app.isPackaged && !cfg.allowDev) return { ok: false, reason: 'dev' };
  if (!sources('latest.json').length) return { ok: false, reason: 'not-configured' };
  if (pending) return { ok: true, ready: pending };
  busy = true;
  try {
    const info = JSON.parse((await fetchFirst('latest.json', 1e6)).toString('utf8'));
    if (!info.version || !newer(info.version, app.getVersion())) return { ok: true, latest: true, version: app.getVersion() };
    if (info.minRuntime && newer(info.minRuntime, process.versions.electron)) return { ok: false, reason: 'runtime', version: info.version };
    const zipBuf = await fetchFirst(info.file || ('inver-app-' + info.version + '.zip'), 60e6);
    if (info.sha256 && crypto.createHash('sha256').update(zipBuf).digest('hex') !== String(info.sha256).toLowerCase()) throw new Error('Контрольная сумма не совпала');
    const work = path.join(app.getPath('temp'), 'inver-update-' + info.version);
    fs.rmSync(work, { recursive: true, force: true });
    fs.mkdirSync(work, { recursive: true });
    const zip = path.join(work, 'app.zip');
    fs.writeFileSync(zip, zipBuf);
    await unzip(zip, path.join(work, 'x'));
    const src = findAppRoot(path.join(work, 'x'));
    if (!src) throw new Error('В архиве обновления нет программы');
    const ver = JSON.parse(fs.readFileSync(path.join(src, 'package.json'), 'utf8')).version;
    if (ver !== info.version) throw new Error('Версия в архиве не совпала');
    // Кладём новые файлы поверх старых: запущенная версия их уже прочитала, новая включится при следующем запуске
    const dest = app.getAppPath();
    fs.cpSync(src, dest, { recursive: true, force: true });
    fs.rmSync(work, { recursive: true, force: true });
    try { execFile('reg', ['add', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Inver', '/v', 'DisplayVersion', '/d', info.version, '/f'], { windowsHide: true }, () => {}); } catch (e) {}
    pending = { version: info.version, notes: info.notes || '' };
    notify(pending);
    return { ok: true, ready: pending };
  } catch (e) {
    return { ok: false, error: e.message || String(e) };
  } finally { busy = false; }
}

function start(session, onReady) {
  ses = session; notify = onReady || notify;
  setTimeout(() => check(false), 45000);
  clearInterval(timer);
  timer = setInterval(() => check(false), CHECK_EVERY);
}

module.exports = { start, check, configured: () => sources('latest.json').length > 0, pending: () => pending };
