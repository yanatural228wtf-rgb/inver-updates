/* Inver — логика интерфейса */
(function () {
  'use strict';
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  var FX = window.FX, Pixels = FX.Pixels, Sound = FX.Sound;
  var api = window.inver || { win: function () {}, onWinState: function () {}, onShortcut: function () {}, saveShot: function () { return Promise.resolve(''); }, showFile: function () {}, platform: 'web', copy: function (t) { try { navigator.clipboard.writeText(t); } catch (e) {} }, config: function () { return Promise.resolve({ ok: true, proxyValid: true }); }, proxyTest: function () { return Promise.resolve({ ok: false, error: 'Проверка работает только в приложении' }); }, shieldAssets: function () { return Promise.resolve({ css: '', youtube: '' }); }, onBlocked: function () {}, onDownload: function () {}, dlAction: function () {}, importSources: function () { return Promise.resolve([]); }, siteIcon: function () { return Promise.resolve(null); } };
  if (api.platform === 'darwin') document.body.classList.add('mac');

  /* ---------- Настройки ---------- */
  var DEFAULTS = { accent: '#7C3AED', bg: 'live', splash: true, shake: true, sound: true, vol: 0.8, apiKey: '', ollama: false, ollamaModel: 'qwen2.5:3b', hideRecent: false, noHistory: false, perf: 'auto', snap: true, tray: true, siteTint: true, wall: 'blobs', soundTheme: 'inver', widgets: true, city: '', aiModel: 'light', sleepTabs: true };
  var settings = Object.assign({}, DEFAULTS, readJSON('inver.settings', {}));
  // 0.7.1: помощник по умолчанию работает на встроенной нейросети, Ollama больше не обязательна
  if (!settings.aiLocalV1) { settings.aiLocalV1 = true; settings.ollama = false; writeJSON('inver.settings', settings); }
  function readJSON(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } }
  function writeJSON(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function saveSettings() { writeJSON('inver.settings', settings); applySettings(); }

  /* Скриншот всего экрана по Print Screen */
  var snapKeys = null;
  function syncSnap() {
    if (!window.inver || !window.inver.snapConfig) return;
    window.inver.snapConfig({ enabled: !!settings.snap, tray: !!settings.tray, accent: settings.accent }).then(function (keys) {
      snapKeys = keys || [];
      var h = document.getElementById('snapHint'); if (!h) return;
      if (!settings.snap) { h.textContent = 'Выключено.'; return; }
      var ps = snapKeys.indexOf('PrintScreen') >= 0;
      h.textContent = (ps ? 'Жми Print Screen в любой программе.' : 'Print Screen занят Windows — используй Ctrl+Alt+S. Чтобы освободить Print Screen: Параметры → Специальные возможности → Клавиатура → выключи «Открывать захват экрана клавишей Print Screen».')
        + (settings.tray ? ' Inver остаётся в трее, когда закрываешь окно.' : ' Работает, пока окно Inver открыто.');
    }).catch(function () {});
  }

  /* Плавное появление и исчезновение окон */
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  function showEl(el) {
    clearTimeout(el._hideT);
    el.classList.remove('leaving');
    el.hidden = false;
  }
  function hideEl(el, ms) {
    if (el.hidden || el.classList.contains('leaving')) return;
    if (reduceMotion.matches) { el.hidden = true; return; }
    el.classList.add('leaving');
    el._hideT = setTimeout(function () { el.classList.remove('leaving'); el.hidden = true; }, ms || 180);
  }
  function isOpen(el) { return !el.hidden && !el.classList.contains('leaving'); }

  var ACCENTS = [['#7C3AED', 'Фиолетовый'], ['#D42A25', 'Красный'], ['#2563EB', 'Синий'], ['#DB2777', 'Малиновый'], ['#EA580C', 'Оранжевый'], ['#0891B2', 'Бирюзовый']];

  function applySettings() {
    var rgb = FX.hexRgb(settings.accent);
    var light = rgb.map(function (c) { return Math.round(c + (255 - c) * 0.45); });
    var root = document.documentElement.style;
    root.setProperty('--accent', settings.accent);
    root.setProperty('--accent-soft', 'rgba(' + rgb.join(',') + ',0.30)');
    root.setProperty('--accent-light', 'rgb(' + light.join(',') + ')');
    Pixels.accent = settings.accent;
    Pixels.mode = settings.bg;
    Pixels.perf = settings.perf;
    document.body.classList.toggle('eco', settings.perf === 'eco');
    $$('#perfModes button').forEach(function (b) { b.classList.toggle('on', b.dataset.perf === settings.perf); b.setAttribute('aria-checked', String(b.dataset.perf === settings.perf)); });
    $('#perfHint').textContent = settings.perf === 'eco' ? 'Фон 20 кадров в секунду, стекло без размытия. Для слабых ноутбуков и работы от батареи.' : settings.perf === 'max' ? 'Фон всегда 60 кадров в секунду, все эффекты включены.' : 'Фон 60 кадров в секунду, а когда окно в фоне или компьютер не успевает — сам снижает частоту.';
    Sound.enabled = settings.sound;
    Sound.volume = settings.vol;
    $$('#accents button').forEach(function (b) { b.setAttribute('aria-checked', String(b.dataset.hex === settings.accent)); });
    $$('#bgModes button').forEach(function (b) { b.classList.toggle('on', b.dataset.bg === settings.bg); b.setAttribute('aria-checked', String(b.dataset.bg === settings.bg)); });
    $$('[data-set]').forEach(function (i) { i.checked = !!settings[i.dataset.set]; });
    $('#vol').value = Math.round(settings.vol * 100);
    $('#apiKey').value = settings.apiKey || '';
    $('#ollamaModel').value = settings.ollamaModel || '';
    $$('#aiModels [data-aim]').forEach(function (b) { b.classList.toggle('on', b.dataset.aim === (settings.aiModel || 'light')); });
    syncSnap();
    $('#recentHide').setAttribute('aria-pressed', String(!!settings.hideRecent));
    $('#recentHide').title = settings.hideRecent ? 'Показать названия' : 'Скрыть названия';
    $('#recentHide span').textContent = settings.hideRecent ? 'Показать' : 'Скрыть';
    renderRecent();
  }

  ACCENTS.forEach(function (a) {
    var b = document.createElement('button');
    b.type = 'button'; b.setAttribute('role', 'radio'); b.setAttribute('aria-label', a[1]);
    b.dataset.hex = a[0]; b.style.backgroundColor = a[0];
    b.addEventListener('click', function () { settings.accent = a[0]; saveSettings(); Sound.blip(880, 0, 0.05); });
    $('#accents').appendChild(b);
  });
  $$('#perfModes button').forEach(function (b) { b.addEventListener('click', function () { settings.perf = b.dataset.perf; saveSettings(); }); });
  $$('#bgModes button').forEach(function (b) { b.addEventListener('click', function () { settings.bg = b.dataset.bg; saveSettings(); }); });
  $$('[data-set]').forEach(function (i) { i.addEventListener('change', function () { settings[i.dataset.set] = i.checked; saveSettings(); }); });
  $('#vol').addEventListener('input', function (e) { settings.vol = Number(e.target.value) / 100; saveSettings(); });
  $('#apiKey').addEventListener('change', function (e) { settings.apiKey = e.target.value.trim(); saveSettings(); });
  $('#ollamaModel').addEventListener('change', function (e) { settings.ollamaModel = e.target.value.trim() || 'qwen2.5:3b'; saveSettings(); });
  $('#snapTry').addEventListener('click', function () { closeSettings(); setTimeout(function () { window.inver && window.inver.snapStart && window.inver.snapStart(); }, 260); });
  if (window.inver && window.inver.onSnapSaved) window.inver.onSnapSaved(function (file) {
    if (file) toast('Скриншот сохранён и скопирован', 'Показать файл', function () { api.showFile(file); });
  });
  $('#testSound').addEventListener('click', function () { Sound.chime(true); });

  function openSettings() { showEl($('#settings')); Sound.blip(760, 0, 0.04); }
  function closeSettings() { hideEl($('#settings')); }
  $('#openSettings').addEventListener('click', openSettings);
  $$('#settings [data-close]').forEach(function (b) { b.addEventListener('click', closeSettings); });

  /* ---------- Окно ---------- */
  $$('[data-win]').forEach(function (b) { b.addEventListener('click', function () { api.win(b.dataset.win); }); });

  /* ---------- Вкладки ---------- */
  var tabs = [], activeId = null, seq = 0, closedTabs = [];
  // Комнаты: отдельные наборы вкладок со своим цветом
  var rooms = readJSON('inver.rooms', null) || [{ id: 'r1', name: 'Основная', color: '#7C3AED' }];
  var curRoom = (readJSON('inver.session', {}) || {}).cur || rooms[0].id;
  if (!rooms.some(function (r) { return r.id === curRoom; })) curRoom = rooms[0].id;
  var roomActive = {};
  var split = null; // { a: id, b: id, ratio }
  function roomTabs(room) { return tabs.filter(function (t) { return t.room === (room || curRoom); }); }
  var START = 'inver://start';

  function activeTab() { return tabs.find(function (t) { return t.id === activeId; }); }

  function toUrl(input) {
    var s = (input || '').trim();
    if (!s) return START;
    if (/^(https?|file):\/\//i.test(s)) return s;
    if (/^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?(\/|$)/i.test(s)) return 'http://' + s;
    if (/^[^\s]+\.[a-z]{2,}(\/|:|$)/i.test(s)) return 'https://' + s;
    return 'https://www.google.com/search?q=' + encodeURIComponent(s);
  }

  function newTab(url, opts) {
    var t = { id: ++seq, url: START, title: 'Новая вкладка', view: null, fresh: true, room: curRoom, priv: !!(opts && opts.priv) };
    tabs.push(t);
    activate(t.id);
    if (url && url !== START) navigate(url);
    else $('#addr').focus();
  }

  function closeTab(id, now) {
    var i = tabs.findIndex(function (t) { return t.id === id; });
    if (i < 0) return;
    var el = document.querySelector('.tab[data-id="' + id + '"]');
    if (!now && el && tabs.length > 1 && !reduceMotion.matches) {
      if (el.classList.contains('leaving')) return;
      el.classList.add('leaving');
      return setTimeout(function () { closeTab(id, true); }, 150);
    }
    var t = tabs[i];
    var inRoom = roomTabs(t.room), ri = inRoom.indexOf(t);
    if (t.url !== START && !t.priv) { closedTabs.push(t.url); if (closedTabs.length > 25) closedTabs.shift(); }
    if (split && (split.a === id || split.b === id)) { var other = split.a === id ? split.b : split.a; split = null; if (activeId === id) { tabs.splice(i, 1); if (t.view) t.view.remove(); return activate(other); } }
    if (t.view) t.view.remove();
    tabs.splice(i, 1);
    var left = roomTabs(t.room);
    if (!left.length) return newTab();
    if (activeId === id) activate(left[Math.max(0, Math.min(left.length - 1, ri - 1))].id);
    else renderTabs();
  }

  function ensureView(t) {
    if (t.view) return t.view;
    var v = document.createElement('webview');
    v.setAttribute('partition', t.priv ? 'inver-private' : 'persist:inver');
    v.setAttribute('allowpopups', '');
    if (t.muted) v.addEventListener('dom-ready', function () { try { v.setAudioMuted(true); } catch (e) {} }, { once: true });
    v.addEventListener('did-navigate', function (e) { onNav(t, e.url); });
    v.addEventListener('did-navigate-in-page', function (e) { if (e.isMainFrame) onNav(t, e.url); });
    v.addEventListener('page-title-updated', function (e) { t.title = e.title; renderTabs(); remember(t); addHistory(t); if (t.id === activeId) $('#spTitle').textContent = t.title; });
    v.addEventListener('console-message', function (e) { onPageMessage(t, e.message); });
    v.addEventListener('did-finish-load', function () { updateNav(); if (spaceOn && t.id === activeId) injectPicker(); readTheme(t); });
    v.addEventListener('did-start-loading', function () { t.loading = true; renderTabs(); });
    v.addEventListener('page-favicon-updated', function (e) { try { iconHint(hostOf(v.getURL()), e.favicons); } catch (er) {} });
    v.addEventListener('found-in-page', function (e) { if (t.id === activeId) onFound(e.result); });
    v.addEventListener('did-change-theme-color', function (e) { t.theme = e.themeColor || null; if (t.id === activeId) applyTint(t); });
    v.addEventListener('media-started-playing', function () { t.media = true; if (t.id === activeId) renderPageTools(); });
    v.addEventListener('media-paused', function () { t.media = false; if (t.id === activeId) renderPageTools(); });
    v.addEventListener('focus', function () { if (split && (split.a === t.id || split.b === t.id) && activeId !== t.id) activate(t.id); });
    v.addEventListener('dom-ready', function () {
      try { t.wcId = v.getWebContentsId(); } catch (e) {}
      applyCosmetics(v);
    });
    v.addEventListener('did-stop-loading', function () { t.loading = false; renderTabs(); updateNav(); });
    v.addEventListener('did-fail-load', function (e) { if (e.errorCode !== -3 && e.isMainFrame) toast('Не удалось открыть страницу: ' + (e.errorDescription || e.errorCode)); });
    $('#views').appendChild(v);
    t.view = v;
    return v;
  }

  function onNav(t, url) {
    if (/^data:/.test(url)) return;
    if (focusBlocked(url)) { blockPage(t, url); return; }
    t.url = url;
    t.theme = null; t.tint = null;
    if (t.id === activeId) $('#addr').value = url;
    remember(t);
    addHistory(t);
    updateNav();
    renderStar();
    if (isOpen($('#findBar')) && t.id === activeId) closeFind();
  }

  // Назад / вперёд / обновить активны только когда есть куда идти
  function updateNav() {
    var t = activeTab(), v = t && t.view, page = !!v && t.url !== START;
    var back = false, fwd = false;
    try { back = page && v.canGoBack(); fwd = page && v.canGoForward(); } catch (e) {}
    $('#back').disabled = !back;
    $('#fwd').disabled = !fwd;
    $('#reload').disabled = !page;
  }

  function navigate(input) {
    var t = activeTab();
    var url = toUrl(input);
    if (url === START) { t.url = START; t.title = 'Новая вкладка'; activate(t.id); return; }
    var v = ensureView(t);
    t.url = url;
    if (focusBlocked(url)) { activate(t.id); blockPage(t, url); return; }
    v.setAttribute('src', url);
    activate(t.id);
  }

  function activate(id) {
    var prev = activeTab();
    if (prev && prev.id !== id) { capturePreview(prev); prev.lastActive = Date.now(); }
    var t0 = tabs.find(function (x) { return x.id === id; });
    if (!t0) return;
    if (t0.room !== curRoom) { curRoom = t0.room; renderRooms(); }
    if (split && split.a !== id && split.b !== id) split = null;
    activeId = id;
    roomActive[curRoom] = id;
    var t = activeTab();
    if (t.lazy) { t.lazy = false; t.asleep = false; var lv = ensureView(t); lv.setAttribute('src', t.url); }
    tabs.forEach(function (x) {
      if (!x.view) return;
      var inSplit = split && (x.id === split.a || x.id === split.b);
      x.view.classList.toggle('active', (x.id === id || inSplit) && x.url !== START);
      x.view.classList.toggle('split-a', !!split && x.id === split.a);
      x.view.classList.toggle('split-b', !!split && x.id === split.b);
      x.view.classList.toggle('split-focus', !!split && x.id === id);
    });
    document.body.classList.toggle('split', !!split);
    var hasPage = t.url !== START && !!t.view;
    var hadPage = document.body.classList.contains('has-page');
    document.body.classList.toggle('has-page', hasPage);
    if (hasPage && !split) { t.view.classList.remove('enter'); void t.view.offsetWidth; t.view.classList.add('enter'); }
    else if (hadPage) playStart();
    $('#addr').value = hasPage ? t.url : '';
    $('#spTitle').textContent = hasPage ? t.title : '';
    renderTabs();
    updateNav();
    renderShield();
    renderStar();
    afterActivate(t);
    if (isOpen($('#findBar'))) closeFind();
    if (spaceOn) { clearInspector(); if (hasPage) injectPicker(); else { $('#tree').innerHTML = ''; renderPalette(null); renderFonts(null); } }
  }

  // Стартовый экран собирается по очереди: шар, недавние, избранное
  var startT;
  function playStart() {
    var st = $('#start');
    st.classList.remove('enter'); void st.offsetWidth; st.classList.add('enter');
    clearTimeout(startT);
    startT = setTimeout(function () { st.classList.remove('enter'); }, 1400);
  }

  function renderTabs() {
    var cur = activeTab();
    document.body.classList.toggle('loading', !!(cur && cur.loading && cur.url !== START));
    var wrap = $('#tabs');
    wrap.innerHTML = '';
    saveSession();
    roomTabs().forEach(function (t) {
      var b = document.createElement('div');
      b.className = 'tab' + (t.id === activeId ? ' active' : '') + (t.loading ? ' loading' : '') + (t.fresh ? ' enter' : '');
      t.fresh = false;
      b.dataset.id = t.id;
      b.setAttribute('role', 'tab');
      b.setAttribute('aria-selected', String(t.id === activeId));
      b.tabIndex = 0;
      b.innerHTML = '<span class="t-title"></span><button class="t-close" aria-label="Закрыть вкладку"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>';
      b.insertBefore(t.url === START ? (function () { var d = document.createElement('span'); d.className = 't-dot'; return d; })() : siteIcon(hostOf(t.url), 't-ico'), b.firstChild);
      b.querySelector('.t-title').textContent = t.title || t.url;
      b.addEventListener('click', function () { activate(t.id); });
      b.addEventListener('keydown', function (e) { if (e.key === 'Enter') activate(t.id); });
      b.querySelector('.t-close').addEventListener('click', function (e) { e.stopPropagation(); closeTab(t.id); });
      if (split && (t.id === split.a || t.id === split.b)) b.classList.add('in-split');
      if (t.priv) b.classList.add('private');
      if (t.asleep) { b.classList.add('asleep'); b.title = 'Вкладка спит, чтобы не тратить память. Нажми, и она проснётся'; }
      if (t.media || t.muted) {
        var snd = el('button', 't-sound' + (t.muted ? ' muted' : ''), t.muted ? '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M17 9l5 6M22 9l-5 6"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/></svg>');
        snd.setAttribute('aria-label', t.muted ? 'Включить звук' : 'Выключить звук'); snd.title = t.muted ? 'Включить звук вкладки' : 'Выключить звук вкладки';
        snd.addEventListener('click', function (e) { e.stopPropagation(); t.muted = !t.muted; try { t.view && t.view.setAudioMuted(t.muted); } catch (er) {} renderTabs(); });
        b.insertBefore(snd, b.querySelector('.t-close'));
      }
      tabHooks(b, t);
      wrap.appendChild(b);
    });
  }

  $('#newTab').addEventListener('click', function () { newTab(); });
  $('#addrForm').addEventListener('submit', function (e) { e.preventDefault(); navigate($('#addr').value); $('#addr').blur(); });
  $('#back').addEventListener('click', function () { var t = activeTab(); if (t.view && t.view.canGoBack()) t.view.goBack(); });
  $('#fwd').addEventListener('click', function () { var t = activeTab(); if (t.view && t.view.canGoForward()) t.view.goForward(); });
  $('#reload').addEventListener('click', function () { var t = activeTab(); if (t.view && t.url !== START) t.view.reload(); });

  /* ---------- Недавние и избранное ---------- */
  var PALETTE = [['#5A1414', '#2A0A0A'], ['#26262D', '#111116'], ['#3A1E5C', '#1A0F2E'], ['#5C1E3E', '#2A0E1C'], ['#14285A', '#0A1430'], ['#10372B', '#0A1A14'], ['#4A3214', '#21160A']];
  function hostOf(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return u; } }
  /* ---------- Иконки сайтов ----------
     Сначала настоящая иконка сайта (крупная из сервиса иконок), если её нет —
     плитка в цвет темы. У каждого сайта свой оттенок акцента, чтобы они различались. */
  var TONES = [
    'color-mix(in srgb, var(--accent) 100%, #000)', 'color-mix(in srgb, var(--accent) 72%, #000)', 'color-mix(in srgb, var(--accent) 52%, #000)',
    'color-mix(in srgb, var(--accent) 82%, #fff)', 'color-mix(in srgb, var(--accent) 64%, #fff)', 'color-mix(in srgb, var(--accent) 86%, #000)',
    'color-mix(in srgb, var(--accent) 40%, #000)'
  ];
  function hashOf(s) { var h = 0; s = String(s || ''); for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; }
  function toneFor(key) { return TONES[hashOf(key) % TONES.length]; }
  var GLOBE = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z"/></svg>';
  // Иконки подбирает главный процесс (качественные, с самого сайта); здесь только показываем
  var iconReq = {};
  try { localStorage.removeItem('inver.icons'); } catch (e) {}
  // Запасной путь, если главный процесс ничего не нашёл: сервис иконок, но только если картинка не крошечная
  function probeImg(src, min) {
    return new Promise(function (res) {
      var im = new Image(); im.referrerPolicy = 'no-referrer';
      im.onload = function () { res(im.naturalWidth >= min ? { src: src, full: false, size: im.naturalWidth } : null); };
      im.onerror = function () { res(null); };
      im.src = src;
    });
  }
  function loadIcon(host) {
    if (!iconReq[host]) {
      iconReq[host] = (api.siteIcon ? api.siteIcon(host) : Promise.resolve(null)).catch(function () { return null; }).then(function (ic) {
        if (ic && ic.src) return ic;
        return probeImg('https://www.google.com/s2/favicons?domain=' + encodeURIComponent(host) + '&sz=128', 48)
          .then(function (r) { return r || probeImg('https://icons.duckduckgo.com/ip3/' + encodeURIComponent(host) + '.ico', 32); });
      });
    }
    return iconReq[host];
  }
  // Когда сайт открыт во вкладке, он сам сообщает свою иконку — подхватываем её и обновляем все места
  function iconHint(host, urls) {
    if (!api.siteIconHint || !host) return;
    api.siteIconHint(host, urls).then(function (ic) {
      if (!ic || !ic.src) return;
      iconReq[host] = Promise.resolve(ic);
      $$('.sico[data-host="' + host + '"]').forEach(function (el) { setIconImg(el, ic); });
    }).catch(function () {});
  }
  function setIconImg(el, ic) {
    var old = el.querySelector('img'); if (old) old.remove();
    el.classList.remove('has-img', 'full', 'plate');
    var img = new Image();
    img.alt = ''; img.decoding = 'async'; img.draggable = false; img.referrerPolicy = 'no-referrer';
    img.onload = function () { el.classList.add('has-img', ic.full ? 'full' : 'plate'); };
    img.src = ic.src;
    el.appendChild(img);
  }
  function siteIcon(host, cls) {
    var el = document.createElement('span');
    el.className = 'sico' + (cls ? ' ' + cls : '');
    el.style.setProperty('--tone', toneFor(host));
    el.innerHTML = GLOBE;
    el.setAttribute('aria-hidden', 'true');
    if (!host) return el;
    el.dataset.host = host;
    loadIcon(host).then(function (ic) { if (ic && ic.src) setIconImg(el, ic); });
    return el;
  }

  function colorFor(s) { var h = 0; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return PALETTE[h % PALETTE.length]; }

  function remember(t) {
    if (settings.noHistory) return;
    if (t.priv || !t.url || t.url === START || !/^https?:/i.test(t.url) || /google\.com\/search/.test(t.url)) return;
    var host = hostOf(t.url);
    writeJSON('inver.recentRemoved', readJSON('inver.recentRemoved', []).filter(function (h) { return h !== host; }));
    var list = readJSON('inver.recent', []).filter(function (r) { return r.host !== host; });
    list.unshift({ host: host, url: t.url, title: t.title && t.title !== 'Новая вкладка' ? t.title : host });
    writeJSON('inver.recent', list.slice(0, 6));
    renderRecent();
  }

  function renderRecent() {
    var list = readJSON('inver.recent', []);
    var defaults = [['youtube.com', 'YouTube'], ['github.com', 'GitHub'], ['figma.com', 'Figma'], ['dribbble.com', 'Dribbble'], ['pinterest.com', 'Pinterest'], ['behance.net', 'Behance']];
    var removed = readJSON('inver.recentRemoved', []);
    defaults.forEach(function (d) {
      if (list.length < 6 && removed.indexOf(d[0]) < 0 && !list.some(function (r) { return r.host === d[0]; })) list.push({ host: d[0], url: 'https://' + d[0], title: d[1] });
    });
    var hide = !!settings.hideRecent;
    $('.recent').classList.toggle('private', hide);
    var wrap = $('#recent');
    wrap.innerHTML = '';
    if (!list.length) { wrap.innerHTML = '<div class="recent-empty">Здесь пусто</div>'; return; }
    list.slice(0, 6).forEach(function (r) {
      // Плитка — обычный div, а не button: Electron по-своему раскладывает содержимое кнопок
      var b = document.createElement('div');
      b.className = 'site';
      b.style.setProperty('--i', wrap.children.length);
      b.setAttribute('role', 'button');
      b.tabIndex = 0;
      if (!hide) b.title = r.title || r.host;
      b.setAttribute('aria-label', hide ? 'Скрытый сайт' : (r.title || r.host));
      b.innerHTML = '<div class="site-thumb"></div><div class="site-name"></div><span class="site-del" role="button" tabindex="-1" aria-label="Убрать из недавних" title="Убрать из недавних"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></span>';
      var th = b.querySelector('.site-thumb');
      th.style.setProperty('--tone', hide ? '#2E2E36' : toneFor(r.host));
      if (hide) th.classList.add('private'); else th.appendChild(siteIcon(r.host, 'site-ico'));
      b.querySelector('.site-name').textContent = hide ? '••••••••' : (r.title || r.host);
      b.querySelector('.site-del').addEventListener('click', function (e) { e.stopPropagation(); forgetRecent(r); });
      b.addEventListener('contextmenu', function (e) { e.preventDefault(); forgetRecent(r); });
      b.addEventListener('click', function () { navigate(r.url); });
      b.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); navigate(r.url); } });
      wrap.appendChild(b);
    });
  }

  function forgetRecent(r) {
    var before = readJSON('inver.recent', []), removedBefore = readJSON('inver.recentRemoved', []);
    writeJSON('inver.recent', before.filter(function (x) { return x.host !== r.host; }));
    writeJSON('inver.recentRemoved', removedBefore.concat([r.host]));
    renderRecent();
    toast('Убрано из недавних', 'Вернуть', function () {
      writeJSON('inver.recent', before); writeJSON('inver.recentRemoved', removedBefore); renderRecent(); $('#toast').classList.remove('on');
    });
  }

  function clearRecent() {
    var before = readJSON('inver.recent', []), removedBefore = readJSON('inver.recentRemoved', []);
    var all = before.map(function (x) { return x.host; }).concat(['youtube.com', 'github.com', 'figma.com', 'dribbble.com', 'pinterest.com', 'behance.net']);
    writeJSON('inver.recent', []);
    writeJSON('inver.recentRemoved', removedBefore.concat(all));
    renderRecent();
    toast('Недавно посещённые очищены', 'Вернуть', function () {
      writeJSON('inver.recent', before); writeJSON('inver.recentRemoved', removedBefore); renderRecent(); $('#toast').classList.remove('on');
    });
  }
  $('#recentClear').addEventListener('click', clearRecent);
  $('#clearRecent2').addEventListener('click', clearRecent);
  $('#recentHide').addEventListener('click', function () { settings.hideRecent = !settings.hideRecent; saveSettings(); });

  var FAV_DEFAULT = [
    { title: 'Почта', url: 'https://mail.google.com', color: '#1D4ED8' },
    { title: 'Telegram', url: 'https://web.telegram.org', color: '#0E7FB8' },
    { title: 'Notion', url: 'https://notion.so', color: '#3A3A42' },
    { title: 'Figma', url: 'https://figma.com', color: '#7C3AED' },
    { title: 'GitHub', url: 'https://github.com', color: '#26262D' },
    { title: 'Карты', url: 'https://yandex.ru/maps', color: '#0E9F6E' }
  ];
  function renderFavs() {
    var favs = readJSON('inver.favs', FAV_DEFAULT);
    var wrap = $('#favs');
    wrap.innerHTML = '';
    favs.slice(0, 8).forEach(function (f) {
      var b = document.createElement('button');
      b.className = 'fav';
      b.style.setProperty('--i', wrap.children.length);
      b.innerHTML = '<span></span>';
      b.insertBefore(siteIcon(hostOf(f.url), 'fav-ico'), b.firstChild);
      b.lastChild.textContent = f.title;
      b.addEventListener('click', function () { navigate(f.url); });
      b.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        writeJSON('inver.favs', favs.filter(function (x) { return x !== f; }));
        renderFavs(); toast('Убрано из избранного: ' + f.title);
      });
      wrap.appendChild(b);
    });
    var add = document.createElement('button');
    add.className = 'fav-add';
    add.setAttribute('aria-label', 'Добавить текущую страницу в избранное');
    add.innerHTML = '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>';
    add.addEventListener('click', function () {
      var cur = activeTab();
      var t = cur && cur.url !== START ? cur : tabs.slice().reverse().find(function (x) { return x.url !== START; });
      if (!t) return toast('Открой сайт, и его можно будет добавить в избранное');
      var host = hostOf(t.url);
      if (favs.some(function (f) { return hostOf(f.url) === host; })) return toast(host + ' уже в избранном');
      if (favs.length >= 8) return toast('В избранном максимум 8 сайтов. Убери лишний правой кнопкой мыши');
      var title = (t.title || host).split(/\s[-–—|·:]\s/)[0].slice(0, 18);
      favs.push({ title: title, url: t.url });
      writeJSON('inver.favs', favs); renderFavs(); toast('Добавлено в избранное: ' + title);
    });
    wrap.appendChild(add);
  }

  /* ---------- Уведомления и скриншоты ---------- */
  var toastTimer;
  function toast(text, actionLabel, action) {
    var el = $('#toast');
    el.innerHTML = '<span></span>';
    el.firstChild.textContent = text;
    if (actionLabel) {
      var b = document.createElement('button');
      b.textContent = actionLabel;
      b.addEventListener('click', action);
      el.appendChild(b);
    }
    el.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('on'); }, 3200);
  }

  function flash() {
    var f = $('#flash');
    f.classList.add('on');
    requestAnimationFrame(function () { requestAnimationFrame(function () { f.classList.remove('on'); }); });
  }

  function screenshot() {
    var t = activeTab();
    if (!t || !t.view || t.url === START) return toast('Открой сайт, чтобы сделать скриншот');
    t.view.capturePage().then(function (img) {
      flash(); Sound.shutter();
      return api.saveShot(img.toDataURL());
    }).then(function (file) {
      if (spaceOn) log('Скриншот сохранён: ' + file, 'ok');
      toast('Скриншот сохранён и скопирован', 'Показать файл', function () { api.showFile(file); });
    }).catch(function (err) { toast('Не получилось сделать скриншот: ' + err.message); });
  }
  $('#shotBtn').addEventListener('click', screenshot);

  /* ---------- Переход в Space: трещина в три удара ---------- */
  var spaceOn = false, busy = false;
  var body = document.body;

  function shake(size) {
    if (!settings.shake) return;
    ['#normal', '#space'].forEach(function (sel) {
      var el = $(sel);
      el.classList.remove('shake-s', 'shake-m', 'shake-l');
      void el.offsetWidth;
      el.classList.add('shake-' + size);
    });
  }

  function crackTo(toSpace) {
    if (busy) return;
    busy = true;
    closeSettings();
    var at = function (ms, fn) { setTimeout(fn, ms); };
    body.classList.add('cracking', 'crack-1');
    shake('s'); Sound.crack(0.45);
    at(560, function () { body.classList.add('crack-2'); shake('m'); Sound.crack(0.7); });
    at(1120, function () { body.classList.add('crack-3'); shake('l'); flash(); Sound.crack(1); });
    if (toSpace) {
      at(1120, function () { body.classList.add('space-vis'); });
      at(1380, function () { body.classList.add('space-open'); Sound.whoosh(true); $('#space').setAttribute('aria-hidden', 'false'); });
      at(1500, function () { Sound.chime(true); });
      at(2150, function () {
        Pixels.scene = 'space';
        body.classList.add('space-layout');
        spaceOn = true;
        applyDevice();
        log('Space открыт · ' + (activeTab().url === START ? 'нет страницы' : hostOf(activeTab().url)), 'info');
        if (activeTab().url !== START) injectPicker();
      });
    } else {
      at(1380, function () {
        stopPicker();
        spaceOn = false;
        resetDevice();
        body.classList.remove('space-layout', 'space-open');
        Pixels.scene = 'normal';
        Sound.whoosh(false);
        $('#space').setAttribute('aria-hidden', 'true');
      });
      at(1500, function () { Sound.chime(false); });
      at(2250, function () { body.classList.remove('space-vis'); });
    }
    at(2250, function () { body.classList.remove('cracking'); });
    at(2650, function () { body.classList.remove('crack-1', 'crack-2', 'crack-3'); busy = false; });
  }
  function toggleSpace() { crackTo(!spaceOn); }
  $('#spaceBtn').addEventListener('click', function () { crackTo(true); });
  $('#exitSpace').addEventListener('click', function () { crackTo(false); });

  /* ---------- Space: выбор элемента прямо на странице ---------- */
  var PICKER = function (accent) {
    return '(' + function (ACC) {
      if (window.__inver) { window.__inver.on(); return; }
      var box = document.createElement('div');
      box.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483647;border:2px solid ' + ACC + ';border-radius:4px;background:' + ACC + '22;transition:all .06s ease;display:none';
      var tag = document.createElement('div');
      tag.style.cssText = 'position:absolute;left:-2px;top:-22px;padding:2px 6px;border-radius:4px;background:' + ACC + ';color:#fff;font:600 11px/16px ui-monospace,Menlo,monospace;white-space:nowrap';
      box.appendChild(tag);
      document.documentElement.appendChild(box);
      var on = true, sel = null;
      function label(el) { var r = el.getBoundingClientRect(); return el.tagName.toLowerCase() + (el.classList.length ? '.' + Array.prototype.slice.call(el.classList, 0, 2).join('.') : '') + ' · ' + Math.round(r.width) + ' × ' + Math.round(r.height); }
      function info(el) {
        var r = el.getBoundingClientRect(), cs = getComputedStyle(el);
        return { tag: el.tagName.toLowerCase(), id: el.id || '', cls: Array.prototype.slice.call(el.classList, 0, 3).join('.'), w: Math.round(r.width), h: Math.round(r.height), color: cs.color, bg: cs.backgroundColor, font: cs.fontFamily.split(',')[0].replace(/["']/g, '') + ' ' + cs.fontSize + ' / ' + cs.fontWeight, pad: cs.padding, radius: cs.borderRadius, text: (el.innerText || '').trim().slice(0, 80), html: el.outerHTML.slice(0, 1500) };
      }
      function report(el) { console.log('__INVER_SEL__' + JSON.stringify(info(el))); }
      function select(el) {
        if (sel) sel.style.outline = sel.__io || '';
        sel = el; sel.__io = sel.style.outline;
        sel.style.outline = '2px solid ' + ACC; sel.style.outlineOffset = '2px';
        report(el);
      }
      document.addEventListener('mousemove', function (e) {
        if (!on) return;
        var el = e.target; if (!el || el === box) return;
        if (el === document.body || el === document.documentElement) { box.style.display = 'none'; return; }
        var r = el.getBoundingClientRect();
        box.style.display = 'block';
        box.style.left = r.left + 'px'; box.style.top = r.top + 'px'; box.style.width = r.width + 'px'; box.style.height = r.height + 'px';
        tag.textContent = label(el);
      }, true);
      document.addEventListener('mouseleave', function () { box.style.display = 'none'; });
      window.addEventListener('blur', function () { box.style.display = 'none'; });
      document.addEventListener('click', function (e) {
        if (!on) return;
        if (e.target === document.body || e.target === document.documentElement) return;
        e.preventDefault(); e.stopPropagation();
        select(e.target);
      }, true);
      function pathOf(el) { var p = []; while (el && el !== document.body) { p.unshift(Array.prototype.indexOf.call(el.parentNode.children, el)); el = el.parentNode; } return p; }
      function byPath(p) { var el = document.body; for (var i = 0; i < p.length && el; i++) el = el.children[p[i]]; return el; }
      window.__inver = {
        on: function () { on = true; },
        off: function () { on = false; box.style.display = 'none'; if (sel) { sel.style.outline = sel.__io || ''; sel = null; } },
        pause: function (v) { on = !v; if (v) box.style.display = 'none'; },
        tree: function () {
          var out = [];
          (function walk(el, d) {
            if (out.length > 70 || d > 3) return;
            Array.prototype.forEach.call(el.children, function (c) {
              if (c === box || /^(SCRIPT|STYLE|NOSCRIPT|LINK|META|SVG|PATH)$/i.test(c.tagName)) return;
              var r = c.getBoundingClientRect(); if (r.width < 4 || r.height < 4) return;
              out.push({ d: d, tag: c.tagName.toLowerCase(), name: (c.id ? '#' + c.id : '') || (c.classList[0] ? '.' + c.classList[0] : '') || (c.innerText || '').trim().slice(0, 24), path: pathOf(c) });
              walk(c, d + 1);
            });
          })(document.body, 0);
          return out;
        },
        css: function () {
          if (!sel) return '';
          var cs = getComputedStyle(sel), out = [];
          var skip = /^(none|normal|auto|0px|0px 0px|0px 0px 0px 0px|rgba\(0, 0, 0, 0\)|static|visible|start|0s|stretch)$/;
          ['display', 'position', 'width', 'height', 'margin', 'padding', 'gap', 'flex-direction', 'justify-content', 'align-items', 'border', 'border-radius', 'background-color', 'background-image', 'color', 'font-family', 'font-size', 'font-weight', 'line-height', 'letter-spacing', 'text-align', 'text-transform', 'box-shadow', 'opacity'].forEach(function (k) {
            var v = cs.getPropertyValue(k);
            if (/^(gap|flex-direction|justify-content|align-items)$/.test(k) && !/flex|grid/.test(cs.display)) return;
            if (!v || skip.test(v) || (k === 'border' && /^0px/.test(v)) || (k === 'opacity' && v === '1') || (k === 'font-weight' && v === '400')) return;
            out.push('  ' + k + ': ' + v + ';');
          });
          var name = sel.tagName.toLowerCase() + (sel.classList.length ? '.' + Array.prototype.slice.call(sel.classList, 0, 2).join('.') : '');
          return name + ' {\n' + out.join('\n') + '\n}';
        },
        html: function () {
          if (!sel) return '';
          var o = sel.style.outline, oo = sel.style.outlineOffset;
          sel.style.outline = sel.__io || ''; sel.style.outlineOffset = '';
          var h = sel.outerHTML;
          sel.style.outline = o; sel.style.outlineOffset = oo;
          if (!sel.getAttribute('style')) h = h.replace(/ style=""/, '');
          return h;
        },
        fonts: function () {
          var counts = {}, els = document.querySelectorAll('body, body *');
          for (var i = 0; i < els.length && i < 2500; i++) {
            var el = els[i];
            if (!el.firstChild || el.firstChild.nodeType !== 3 || !el.firstChild.nodeValue.trim()) continue;
            var cs = getComputedStyle(el), fam = cs.fontFamily.split(',')[0].replace(/["']/g, '').trim();
            if (!fam) continue;
            var c = counts[fam] || (counts[fam] = { n: 0, sizes: {} });
            c.n += el.firstChild.nodeValue.trim().length; c.sizes[cs.fontSize] = 1;
          }
          return Object.keys(counts).sort(function (a, b) { return counts[b].n - counts[a].n; }).slice(0, 6).map(function (f) {
            var sizes = Object.keys(counts[f].sizes).map(parseFloat).sort(function (a, b) { return a - b; });
            return { family: f, full: f, sizes: sizes.length > 1 ? sizes[0] + '–' + sizes[sizes.length - 1] + 'px' : (sizes[0] || '') + 'px' };
          });
        },
        palette: function () {
          var counts = {}, els = document.querySelectorAll('body, body *');
          function hex(c) { var m = c.match(/rgba?\((\d+), (\d+), (\d+)(?:, ([\d.]+))?\)/); if (!m || (m[4] !== undefined && Number(m[4]) < 0.3)) return null; return '#' + [m[1], m[2], m[3]].map(function (x) { return ('0' + Number(x).toString(16)).slice(-2); }).join('').toUpperCase(); }
          for (var i = 0; i < els.length && i < 2500; i++) {
            var cs = getComputedStyle(els[i]);
            [cs.backgroundColor, cs.color].forEach(function (c, j) { var h = hex(c); if (h) counts[h] = (counts[h] || 0) + (j === 0 ? 3 : 1); });
          }
          return Object.keys(counts).sort(function (a, b) { return counts[b] - counts[a]; }).slice(0, 12);
        },
        selectPath: function (p) { var el = byPath(p); if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); select(el); } },
        apply: function (css) { if (!sel) return false; if (sel.__orig === undefined) sel.__orig = sel.getAttribute('style') || ''; Object.keys(css).forEach(function (k) { sel.style[k] = css[k]; }); report(sel); return true; },
        op: function (name) {
          if (!sel) return false;
          var cs = getComputedStyle(sel);
          if (sel.__orig === undefined) sel.__orig = sel.getAttribute('style') || '';
          if (name === 'bigger') { sel.style.fontSize = (parseFloat(cs.fontSize) * 1.12).toFixed(1) + 'px'; sel.style.paddingTop = (parseFloat(cs.paddingTop) * 1.25 + 1).toFixed(0) + 'px'; sel.style.paddingBottom = sel.style.paddingTop; sel.style.paddingLeft = (parseFloat(cs.paddingLeft) * 1.25 + 2).toFixed(0) + 'px'; sel.style.paddingRight = sel.style.paddingLeft; }
          if (name === 'smaller') { sel.style.fontSize = (parseFloat(cs.fontSize) * 0.88).toFixed(1) + 'px'; sel.style.paddingTop = Math.max(0, parseFloat(cs.paddingTop) * 0.8).toFixed(0) + 'px'; sel.style.paddingBottom = sel.style.paddingTop; sel.style.paddingLeft = Math.max(0, parseFloat(cs.paddingLeft) * 0.8).toFixed(0) + 'px'; sel.style.paddingRight = sel.style.paddingLeft; }
          if (name === 'padMore') { sel.style.padding = (parseFloat(cs.paddingTop) * 1.4 + 4).toFixed(0) + 'px ' + (parseFloat(cs.paddingLeft) * 1.4 + 6).toFixed(0) + 'px'; }
          if (name === 'padLess') { sel.style.padding = (parseFloat(cs.paddingTop) * 0.6).toFixed(0) + 'px ' + (parseFloat(cs.paddingLeft) * 0.6).toFixed(0) + 'px'; }
          if (name === 'round') sel.style.borderRadius = '16px';
          if (name === 'accent') { sel.style.backgroundColor = ACC; sel.style.color = '#fff'; sel.style.borderColor = ACC; }
          if (name === 'shadow') sel.style.boxShadow = '0 10px 30px rgba(0,0,0,.25)';
          if (name === 'hide') sel.style.display = 'none';
          if (name === 'reset') { sel.setAttribute('style', sel.__orig); sel.style.outline = '2px solid ' + ACC; sel.style.outlineOffset = '2px'; }
          report(sel);
          return true;
        }
      };
    }.toString() + ')(' + JSON.stringify(accent) + ')';
  };

  function view() { var t = activeTab(); return t && t.view && t.url !== START ? t.view : null; }

  function injectPicker() {
    var v = view(); if (!v) return;
    v.executeJavaScript(PICKER(settings.accent)).then(function () { return v.executeJavaScript('window.__inver.tree()'); })
      .then(renderTree)
      .then(function () { return v.executeJavaScript('window.__inver.palette()'); })
      .then(renderPalette)
      .then(function () { return v.executeJavaScript('window.__inver.fonts()'); })
      .then(renderFonts).catch(function () {});
    setPickMode(true);
  }
  function stopPicker() { var v = view(); if (v) v.executeJavaScript('window.__inver && window.__inver.off()').catch(function () {}); clearInspector(); }

  var picking = true;
  function setPickMode(on) {
    picking = on;
    $('#pickBtn').classList.toggle('on', on);
    var v = view(); if (v) v.executeJavaScript('window.__inver && window.__inver.pause(' + (!on) + ')').catch(function () {});
  }
  $('#pickBtn').addEventListener('click', function () { setPickMode(!picking); });

  function renderTree(nodes) {
    var wrap = $('#tree');
    wrap.innerHTML = '';
    (nodes || []).forEach(function (n) {
      var b = document.createElement('button');
      b.style.paddingLeft = (6 + n.d * 12) + 'px';
      b.innerHTML = '<span class="tg"></span><span></span>';
      b.firstChild.textContent = n.tag;
      b.lastChild.textContent = n.name || '';
      b.addEventListener('click', function () {
        $$('#tree button.on').forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        var v = view(); if (v) v.executeJavaScript('window.__inver.selectPath(' + JSON.stringify(n.path) + ')');
        Sound.blip(700 + Math.min(n.d, 4) * 60, 0, 0.04);
      });
      wrap.appendChild(b);
    });
  }

  function renderPalette(colors) {
    var wrap = $('#palette');
    wrap.innerHTML = '';
    if (!colors || !colors.length) { wrap.innerHTML = '<p class="muted small">Цвета не найдены</p>'; return; }
    colors.forEach(function (c) {
      var b = document.createElement('button');
      b.style.background = c;
      b.title = c + ' — скопировать';
      b.setAttribute('aria-label', 'Скопировать цвет ' + c);
      b.addEventListener('click', function () { api.copy(c); toast('Цвет ' + c + ' скопирован'); log('Скопирован цвет ' + c, 'ok'); Sound.blip(990, 0, 0.04); });
      wrap.appendChild(b);
    });
  }

  function renderFonts(list) {
    var wrap = $('#fonts');
    wrap.innerHTML = '';
    if (!list || !list.length) { wrap.innerHTML = '<p class="muted small">Пока пусто</p>'; return; }
    list.forEach(function (f) {
      var b = document.createElement('button');
      b.innerHTML = '<span></span><span></span>';
      b.firstChild.textContent = f.family; b.lastChild.textContent = f.sizes;
      b.title = 'Скопировать font-family';
      b.addEventListener('click', function () { var css = 'font-family: "' + f.family + '", sans-serif;'; api.copy(css); toast('Скопировано: ' + css); log('Скопирован шрифт ' + f.family, 'ok'); });
      wrap.appendChild(b);
    });
  }

  $$('.quick button[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var v = view();
      if (!v || !selected) return toast('Сначала выбери элемент на странице');
      var kind = b.dataset.copy;
      Promise.all([kind !== 'html' ? v.executeJavaScript('window.__inver.css()') : '', kind !== 'css' ? v.executeJavaScript('window.__inver.html()') : ''])
        .then(function (r) {
          var text = kind === 'css' ? r[0] : kind === 'html' ? r[1] : '<style>\n' + r[0] + '\n</style>\n' + r[1];
          api.copy(text);
          var what = kind === 'css' ? 'CSS' : kind === 'html' ? 'HTML' : 'Блок с CSS и HTML';
          toast(what + ' скопирован в буфер');
          log(what + ' скопирован → ' + selected.tag + (selected.cls ? '.' + selected.cls : ''), 'ok');
          Sound.blip(990, 0, 0.05);
        }).catch(function () { toast('Не получилось скопировать'); });
    });
  });

  var selected = null;
  function onPageMessage(t, msg) {
    if (typeof msg !== 'string' || msg.indexOf('__INVER_SEL__') !== 0 || t.id !== activeId) return;
    try { selected = JSON.parse(msg.slice(13)); } catch (e) { return; }
    renderInspector(selected);
    Sound.blip(820, 0, 0.04);
  }

  function clearInspector() { selected = null; $('#inspector').innerHTML = '<p class="muted">Нажми на любой элемент на странице</p>'; }
  function renderInspector(s) {
    var rows = [['Размер', s.w + ' × ' + s.h], ['Фон', s.bg], ['Цвет текста', s.color], ['Шрифт', s.font], ['Отступы', s.pad], ['Скругление', s.radius]];
    var el = $('#inspector');
    el.innerHTML = '<div class="sel-name"></div>';
    el.firstChild.textContent = s.tag + (s.id ? '#' + s.id : '') + (s.cls ? '.' + s.cls : '');
    rows.forEach(function (r) {
      var row = document.createElement('div');
      row.className = 'row';
      row.innerHTML = '<span></span><span></span>';
      row.firstChild.textContent = r[0];
      if (r[0] === 'Фон' || r[0] === 'Цвет текста') { var sw = document.createElement('i'); sw.className = 'sw'; sw.style.background = r[1]; row.lastChild.appendChild(sw); }
      row.lastChild.appendChild(document.createTextNode(r[1]));
      el.appendChild(row);
    });
  }

  $$('.quick button[data-q]').forEach(function (b) {
    b.addEventListener('click', function () {
      var v = view();
      if (!v || !selected) return toast('Сначала выбери элемент на странице');
      v.executeJavaScript('window.__inver.op(' + JSON.stringify(b.dataset.q) + ')');
      log('Правка «' + b.textContent + '» → ' + selected.tag + (selected.cls ? '.' + selected.cls : ''), 'ai');
      Sound.blip(990, 0, 0.05);
    });
  });

  /* ---------- AI-помощник (ключ Anthropic API из настроек) ---------- */
  function aiMsg(text, who) {
    var m = document.createElement('div');
    m.className = 'msg ' + who;
    m.textContent = text;
    $('#aiLog').appendChild(m);
    $('#aiLog').scrollTop = 1e6;
    return m;
  }

  /* Бесплатный разбор команд: понимает простые просьбы по-русски без интернета */
  var COLOR_WORDS = [
    [/красн/, '#D42A25', 'красный'], [/голуб/, '#38BDF8', 'голубой'], [/син/, '#2563EB', 'синий'], [/зел[её]н/, '#16A34A', 'зелёный'],
    [/ж[её]лт/, '#EAB308', 'жёлтый'], [/оранж/, '#EA580C', 'оранжевый'], [/фиолет/, '#7C3AED', 'фиолетовый'], [/розов/, '#EC4899', 'розовый'],
    [/малинов/, '#DB2777', 'малиновый'], [/ч[её]рн/, '#111111', 'чёрный'], [/бел/, '#FFFFFF', 'белый'], [/сер/, '#6B7280', 'серый'],
    [/золот/, '#C8A27A', 'золотой'], [/бирюз/, '#0891B2', 'бирюзовый'], [/акцент/, null, 'акцентный']
  ];
  var TEXT_TAGS = /^(p|span|a|h1|h2|h3|h4|h5|h6|li|label|strong|em|small|b|i)$/;

  function parseCommand(q, sel) {
    var t = q.toLowerCase().replace(/ё/g, 'е');
    var acts = [], css = {}, done = [];
    var add = function (k, v) { css[k] = v; };
    if (/(крупн|больш|увелич)/.test(t) && !/отступ/.test(t)) { acts.push('bigger'); done.push('крупнее'); }
    if (/(мельч|меньш|уменьш)/.test(t) && !/отступ/.test(t)) { acts.push('smaller'); done.push('мельче'); }
    if (/отступ/.test(t)) { if (/(меньш|убав|уменьш)/.test(t)) { acts.push('padLess'); done.push('отступы меньше'); } else { acts.push('padMore'); done.push('отступы больше'); } }
    var hex = (t.match(/#[0-9a-f]{6}\b/) || [])[0], color = null, cname = '';
    if (hex) { color = hex; cname = hex; }
    else for (var i = 0; i < COLOR_WORDS.length; i++) if (COLOR_WORDS[i][0].test(t)) { color = COLOR_WORDS[i][1] || settings.accent; cname = COLOR_WORDS[i][2]; break; }
    if (color) {
      var textOnly = /(текст|шрифт|букв|надпис)/.test(t) && !/фон/.test(t);
      var isText = TEXT_TAGS.test(sel.tag) && !/фон/.test(t) && /rgba\(0, 0, 0, 0\)|transparent/.test(sel.bg);
      if (textOnly || isText) { add('color', color); done.push('цвет текста ' + cname); }
      else {
        add('backgroundColor', color); add('borderColor', color);
        var rgb = FX.hexRgb(color), lum = (0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]) / 255;
        add('color', lum > 0.6 ? '#111111' : '#FFFFFF');
        done.push('фон ' + cname);
      }
    }
    if (/(таблетк|пилюл|капсул)/.test(t)) { add('borderRadius', '999px'); done.push('форма таблетки'); }
    else if (/(без скругл|остр|квадрат)/.test(t)) { add('borderRadius', '0'); done.push('острые углы'); }
    else if (/(скругл|кругл|мягк)/.test(t)) { add('borderRadius', /(сильн|очень|больш)/.test(t) ? '28px' : '16px'); done.push('скругление'); }
    if (/(без тени|убери тен|тень убер)/.test(t)) { add('boxShadow', 'none'); done.push('без тени'); }
    else if (/тен/.test(t)) { add('boxShadow', '0 10px 30px rgba(0,0,0,.25)'); done.push('тень'); }
    if (/жирн/.test(t)) { add('fontWeight', '700'); done.push('жирный'); }
    if (/тонк/.test(t)) { add('fontWeight', '300'); done.push('тонкий'); }
    if (/(курсив|наклон)/.test(t)) { add('fontStyle', 'italic'); done.push('курсив'); }
    if (/(заглав|капс|верхн)/.test(t)) { add('textTransform', 'uppercase'); add('letterSpacing', '0.06em'); done.push('заглавные'); }
    if (/(по центру|центр)/.test(t)) { add('textAlign', 'center'); done.push('по центру'); }
    if (/(обвод|рамк|контур)/.test(t)) { add('border', '2px solid ' + (color || 'currentColor')); done.push('обводка'); }
    if (/(полупрозрач|прозрачн)/.test(t)) { add('opacity', '0.6'); done.push('прозрачность'); }
    var px = t.match(/(\d{1,3})\s*(px|пикс)/);
    if (px) { add('fontSize', px[1] + 'px'); done.push('размер ' + px[1] + ' px'); }
    if (/(скрой|спрячь|убери)/.test(t) && !/тен/.test(t) && !done.length) { acts.push('hide'); done.push('скрыт'); }
    if (/(верни|сброс|отмени|как было)/.test(t)) { return { acts: ['reset'], css: {}, note: 'Вернул элемент как было.' }; }
    if (!done.length) return null;
    return { acts: acts, css: css, note: 'Готово: ' + done.join(', ') + '.' };
  }

  function runActions(v, res) {
    var chain = Promise.resolve();
    res.acts.forEach(function (a) { chain = chain.then(function () { return v.executeJavaScript('window.__inver.op(' + JSON.stringify(a) + ')'); }); });
    if (Object.keys(res.css).length) chain = chain.then(function () { return v.executeJavaScript('window.__inver.apply(' + JSON.stringify(res.css) + ')'); });
    return chain;
  }

  var SYSTEM = 'Ты помощник в браузере Inver: меняешь внешний вид выбранного элемента веб-страницы. Отвечай ТОЛЬКО JSON без текста вокруг: {"css": {"свойствоВcamelCase": "значение"}, "note": "одно короткое предложение по-русски о том, что изменено"}. Используй только CSS-свойства элемента.';

  function askOllama(q) {
    return fetch('http://127.0.0.1:11434/api/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ model: settings.ollamaModel || 'qwen2.5:3b', stream: false, format: 'json', messages: [{ role: 'system', content: SYSTEM }, { role: 'user', content: 'Запрос: ' + q + '\n\nЭлемент: ' + JSON.stringify(selected) }] })
    }).then(function (r) {
      if (!r.ok) throw new Error('Ollama ответила ' + r.status + '. Проверь, что модель скачана: ollama pull ' + (settings.ollamaModel || 'qwen2.5:3b'));
      return r.json();
    }).then(function (d) { return (d.message && d.message.content) || ''; });
  }

  function askClaude(q) {
    return fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': settings.apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
      body: JSON.stringify({ model: 'claude-sonnet-5-5', max_tokens: 700, system: SYSTEM, messages: [{ role: 'user', content: 'Запрос: ' + q + '\n\nЭлемент: ' + JSON.stringify(selected) }] })
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (d.error) throw new Error(d.error.message);
      return (d.content || []).map(function (c) { return c.text || ''; }).join('');
    });
  }

  $('#aiForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var q = $('#aiInput').value.trim();
    if (!q) return;
    $('#aiInput').value = '';
    aiMsg(q, 'me');
    var v = view();
    if (!v || !selected) return aiMsg('Сначала выбери элемент на странице: кликни по нему или по слою слева.', 'ai');
    var label = selected.tag + (selected.cls ? '.' + selected.cls : '');

    var local = parseCommand(q, selected);
    if (local) {
      runActions(v, local).then(function () {
        aiMsg(local.note, 'ai');
        log('Правка: ' + local.note.replace('Готово: ', '') + ' → ' + label, 'ai');
        Sound.blip(880, 0, 0.06); Sound.blip(1320, 0.08, 0.06);
      });
      return;
    }
    var ask = settings.ollama ? askOllama : settings.apiKey ? askClaude : function (q) { return localChat([{ role: 'user', content: 'Запрос: ' + q + '\n\nЭлемент: ' + JSON.stringify(selected) }], SYSTEM, 400); };
    if (!ask) return aiMsg('Не понял команду. Попробуй так: «крупнее», «в синий», «скругли», «добавь тень», «жирный», «по центру», «больше отступов», «18px», «верни как было». Для сложных просьб включи Ollama в настройках.', 'ai');
    var wait = aiMsg('Думаю…', 'ai');
    log('AI: изучаю ' + label, 'ai');
    ask(q).then(function (text) {
      var json = JSON.parse(text.slice(text.indexOf('{'), text.lastIndexOf('}') + 1));
      return v.executeJavaScript('window.__inver.apply(' + JSON.stringify(json.css || {}) + ')').then(function () {
        wait.textContent = json.note || 'Готово.';
        log('AI применил: ' + Object.keys(json.css || {}).join(', '), 'ok');
        Sound.blip(880, 0, 0.06); Sound.blip(1320, 0.08, 0.06);
      });
    }).catch(function (err) {
      var msg = /Failed to fetch/i.test(err.message) && settings.ollama ? 'Ollama не отвечает. Запусти её и скачай модель: ollama pull ' + (settings.ollamaModel || 'qwen2.5:3b') : err.message;
      wait.textContent = 'Не получилось: ' + msg;
      log('AI: ошибка — ' + msg, 'warn');
    });
  });

  /* ---------- Консоль Space ---------- */
  var COLORS = { info: '#9BB4FF', ok: '#7FE3B6', warn: '#FFC877', ai: 'var(--accent-light)' };
  function log(text, lvl) {
    var c = $('#spConsole');
    var d = new Date(), pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var ln = document.createElement('div');
    ln.className = 'ln';
    ln.innerHTML = '<span class="tm"></span><span></span>';
    ln.firstChild.textContent = pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
    ln.lastChild.textContent = text;
    ln.lastChild.style.color = COLORS[lvl] || '#C4C4CC';
    c.appendChild(ln);
    while (c.children.length > 7) c.removeChild(c.firstChild);
  }

  /* ---------- Размер экрана в Space ---------- */
  var device = 'full';
  $$('[data-dev]').forEach(function (b) {
    b.addEventListener('click', function () {
      device = b.dataset.dev;
      $$('[data-dev]').forEach(function (x) { x.classList.toggle('on', x === b); });
      applyDevice();
      Sound.blip(820, 0, 0.04);
      log('Ширина превью: ' + (device === 'full' ? 'вся область' : device + ' px'), 'info');
    });
  });
  function applyDevice() {
    var v = $('#views');
    if (!spaceOn || device === 'full') { v.classList.remove('dev'); v.style.left = ''; v.style.width = ''; return; }
    var cs = getComputedStyle(document.documentElement);
    var left = parseInt(cs.getPropertyValue('--left-w'), 10) + 16;
    var right = parseInt(cs.getPropertyValue('--right-w'), 10) + 16;
    var avail = window.innerWidth - left - right;
    var w = Math.min(Number(device), avail);
    v.classList.add('dev');
    v.style.width = w + 'px';
    v.style.left = (left + (avail - w) / 2) + 'px';
  }
  function resetDevice() { var v = $('#views'); v.classList.remove('dev'); v.style.left = ''; v.style.width = ''; }
  window.addEventListener('resize', applyDevice);


  /* ---------- Блокировщик рекламы ---------- */
  var shieldCfg = Object.assign({ adblock: true, allow: [], cookies: true }, readJSON('inver.shield', {}));
  var VPN_DEFAULT = ['instagram.com', 'cdninstagram.com', 'facebook.com', 'fbcdn.net', 'x.com', 'twitter.com', 'twimg.com', 'discord.com', 'discord.gg', 'discordapp.com', 'discordapp.net', 'discord.media', 'youtube.com', 'youtu.be', 'googlevideo.com', 'ytimg.com', 'ggpht.com', 'linkedin.com', 'licdn.com', 'chatgpt.com', 'openai.com', 'oaistatic.com', 'oaiusercontent.com', 'claude.ai', 'anthropic.com', 'medium.com', 'patreon.com', 'soundcloud.com', 'spotify.com', 'scdn.co', 'notion.so', 'notion.site', 'figma.com', 'canva.com', 'netflix.com', 'twitch.tv'];
  var vpnCfg = Object.assign({ on: false, mode: 'list', proxy: 'socks5://127.0.0.1:40000', domains: VPN_DEFAULT }, readJSON('inver.vpn', {}));
  var shieldAssets = { css: '', youtube: '' };
  api.shieldAssets().then(function (a) { shieldAssets = a || shieldAssets; }).catch(function () {});

  function pushConfig() {
    writeJSON('inver.shield', shieldCfg);
    writeJSON('inver.vpn', vpnCfg);
    return api.config({ adblock: shieldCfg.adblock, allow: shieldCfg.allow, vpn: vpnCfg }).catch(function () { return {}; });
  }

  function pageHost() { var t = activeTab(); return t && t.url !== START ? hostOf(t.url) : ''; }
  function siteAllowed(host) { return shieldCfg.allow.indexOf(host) >= 0; }

  function applyCosmetics(v) {
    var host = '';
    try { host = hostOf(v.getURL()); } catch (e) {}
    if (!host || siteAllowed(host)) return;
    if (!shieldCfg.adblock) { if (shieldCfg.cookies && shieldAssets.cookies) v.insertCSS(shieldAssets.cookies).catch(function () {}); return; }
    if (shieldAssets.css) v.insertCSS(shieldAssets.css).catch(function () {});
    if (shieldCfg.cookies && shieldAssets.cookies) v.insertCSS(shieldAssets.cookies).catch(function () {});
    if (/(^|\.)youtube\.com$/.test(host) && shieldAssets.youtube) v.executeJavaScript(shieldAssets.youtube).catch(function () {});
  }

  api.onBlocked(function (id, n) {
    var t = tabs.find(function (x) { return x.wcId === id; });
    if (!t) return;
    t.blocked = n;
    if (t.id === activeId) renderShield();
  });

  function renderShield() {
    var t = activeTab(), n = t && t.url !== START ? (t.blocked || 0) : 0, host = pageHost();
    var off = !shieldCfg.adblock || (host && siteAllowed(host));
    $('#shieldBtn').classList.toggle('off', !!off);
    $('#shieldBtn').title = off ? 'Блокировщик выключен' : 'Блокировщик рекламы' + (n ? ' · заблокировано ' + n : '');
    var badge = $('#shieldCount');
    badge.textContent = n > 99 ? '99+' : String(n);
    badge.classList.toggle('on', n > 0 && !off);
    $('#shieldNum').textContent = String(n);
    $('#adblockOn').checked = shieldCfg.adblock;
    $('#cookieOn').checked = !!shieldCfg.cookies;
    $('#adblockSite').checked = !!host && !siteAllowed(host);
    $('#adblockSite').disabled = !host || !shieldCfg.adblock;
    $('#siteRowLabel').textContent = host ? 'На сайте ' + host : 'На этом сайте';
  }

  $('#cookieOn').addEventListener('change', function (e) { shieldCfg.cookies = e.target.checked; pushConfig(); renderShield(); });
  $('#adblockOn').addEventListener('change', function (e) { shieldCfg.adblock = e.target.checked; pushConfig(); renderShield(); });
  $('#adblockSite').addEventListener('change', function (e) {
    var host = pageHost(); if (!host) return;
    shieldCfg.allow = shieldCfg.allow.filter(function (h) { return h !== host; });
    if (!e.target.checked) shieldCfg.allow.push(host);
    pushConfig(); renderShield();
  });
  $('#shieldReload').addEventListener('click', function () { var t = activeTab(); if (t && t.view && t.url !== START) t.view.reload(); closePops(); });

  /* ---------- Обход блокировок ---------- */
  function renderVpn() {
    $('#vpnBtn').classList.toggle('on', vpnCfg.on);
    $('#vpnBtn').title = vpnCfg.on ? 'Обход блокировок включён' : 'Обход блокировок';
    $('#vpnOn').checked = vpnCfg.on;
    $('#vpnState').textContent = vpnCfg.on ? (vpnCfg.mode === 'all' ? 'Весь трафик' : 'Включён') : 'Выключен';
    $('#vpnState').classList.toggle('on', vpnCfg.on);
    $$('#vpnMode button').forEach(function (b) { b.classList.toggle('on', b.dataset.mode === vpnCfg.mode); b.setAttribute('aria-checked', String(b.dataset.mode === vpnCfg.mode)); });
    if (document.activeElement !== $('#vpnProxy')) $('#vpnProxy').value = vpnCfg.proxy;
    if (document.activeElement !== $('#vpnDomains')) $('#vpnDomains').value = vpnCfg.domains.join('\n');
  }
  function saveVpn(note) {
    renderVpn();
    pushConfig().then(function (r) {
      if (vpnCfg.on && r && r.proxyValid === false) toast('Проверь адрес прокси: нужен вид socks5://127.0.0.1:40000');
      else if (note) toast(note);
    });
  }
  $('#vpnOn').addEventListener('change', function (e) { vpnCfg.on = e.target.checked; saveVpn(vpnCfg.on ? 'Обход блокировок включён. Обнови страницу, если она уже открыта' : 'Обход блокировок выключен'); Sound.blip(vpnCfg.on ? 880 : 520, 0, 0.05); });
  $$('#vpnMode button').forEach(function (b) { b.addEventListener('click', function () { vpnCfg.mode = b.dataset.mode; saveVpn(); }); });
  $('#vpnProxy').addEventListener('change', function (e) { vpnCfg.proxy = e.target.value.trim() || 'socks5://127.0.0.1:40000'; saveVpn(); });
  $('#vpnDomains').addEventListener('change', function (e) {
    vpnCfg.domains = e.target.value.split(/[\s,]+/).map(function (d) { return d.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, ''); }).filter(Boolean);
    saveVpn();
  });
  $('#vpnAddSite').addEventListener('click', function () {
    var host = pageHost();
    if (!host) return toast('Открой сайт, чтобы добавить его');
    if (vpnCfg.domains.indexOf(host) < 0) vpnCfg.domains.push(host);
    $('#vpnDomains').value = vpnCfg.domains.join('\n');
    saveVpn(host + ' теперь открывается через прокси');
  });
  $('#vpnTest').addEventListener('click', function () {
    var out = $('#vpnTestOut'), proxy = $('#vpnProxy').value.trim() || vpnCfg.proxy;
    out.textContent = 'Проверяю…';
    api.proxyTest(proxy).then(function (r) {
      if (r && r.ok) out.textContent = 'Работает. Выход через ' + (r.loc || '?') + (r.warp && r.warp !== 'off' ? ' · WARP' : '') + (r.ip ? ' · IP ' + r.ip : '');
      else out.textContent = 'Не работает: ' + ((r && r.error) || 'нет ответа');
    });
  });

  /* ---------- Всплывающие окна ---------- */
  var POPS = { shieldBtn: '#shieldPop', vpnBtn: '#vpnPop' };
  function closePops() { Object.keys(POPS).forEach(function (k) { hideEl($(POPS[k]), 170); }); }
  Object.keys(POPS).forEach(function (id) {
    $('#' + id).addEventListener('click', function (e) {
      e.stopPropagation();
      var pop = $(POPS[id]), open = !isOpen(pop);
      closePops(); closeSettings();
      if (open) { renderShield(); renderVpn(); showEl(pop); Sound.blip(760, 0, 0.04); }
    });
  });
  document.addEventListener('mousedown', function (e) {
    if (e.target.closest && (e.target.closest('.pop') || e.target.closest('#shieldBtn') || e.target.closest('#vpnBtn'))) return;
    closePops();
  });
  window.addEventListener('blur', function () { setTimeout(function () { if (document.activeElement && document.activeElement.tagName === 'WEBVIEW') closePops(); }, 0); });

  /* ---------- Док с приложениями и боковая панель ----------
     Слева из края окна торчит стеклянная ручка с шестерёнкой. По клику выезжает док:
     приложения можно перетаскивать, добавлять свои и убирать в режиме правки. */
  var DOCK_DEFAULT = [
    { id: 'tg', title: 'Telegram', url: 'https://web.telegram.org/a/' },
    { id: 'ds', title: 'Discord', url: 'https://discord.com/app' },
    { id: 'ym', title: 'Яндекс Музыка', url: 'https://music.yandex.ru' },
    { id: 'wa', title: 'WhatsApp', url: 'https://web.whatsapp.com' },
    { id: 'gpt', title: 'ChatGPT', url: 'https://chatgpt.com' }
  ];
  var dockApps = readJSON('inver.dock', null) || DOCK_DEFAULT.slice();
  var panelViews = {}, panelCur = null, unread = {}, dockEdit = false, dragId = null;
  function saveDock() { writeJSON('inver.dock', dockApps); }
  function appById(id) { return dockApps.find(function (x) { return x.id === id; }); }

  function renderDock() {
    var wrap = $('#dockApps');
    // FLIP: запоминаем, где были иконки, чтобы после перестановки плавно доехать до нового места
    var before = {};
    $$('#dockApps .dock-app').forEach(function (el) { before[el.dataset.id] = el.getBoundingClientRect().top; });
    wrap.innerHTML = '';
    dockApps.forEach(function (a, i) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'dock-app' + (panelCur === a.id && body.classList.contains('panel-open') ? ' on' : '');
      b.dataset.id = a.id;
      b.title = a.title;
      b.setAttribute('aria-label', a.title);
      b.draggable = true;
      b.style.setProperty('--i', i);
      b.appendChild(siteIcon(hostOf(a.url), 'dock-ico'));
      var badge = document.createElement('span'); badge.className = 'badge'; b.appendChild(badge);
      if (unread[a.id]) { badge.textContent = unread[a.id] > 99 ? '99+' : String(unread[a.id]); badge.classList.add('on'); }
      var del = document.createElement('span'); del.className = 'dock-del'; del.setAttribute('aria-hidden', 'true');
      del.innerHTML = '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>'; b.appendChild(del);
      b.addEventListener('click', function () { if (dockEdit) return removeApp(a.id); openPanel(a.id, true); });
      b.addEventListener('contextmenu', function (e) { e.preventDefault(); setDockEdit(!dockEdit); });
      b.addEventListener('dragstart', function (e) { dragId = a.id; b.classList.add('dragging'); try { e.dataTransfer.setData('text/plain', a.id); e.dataTransfer.effectAllowed = 'move'; } catch (er) {} });
      b.addEventListener('dragend', function () { dragId = null; $$('.dock-app').forEach(function (x) { x.classList.remove('dragging', 'drop-before', 'drop-after'); }); });
      b.addEventListener('dragover', function (e) {
        if (!dragId || dragId === a.id) return;
        e.preventDefault();
        var r = b.getBoundingClientRect(), after = e.clientY > r.top + r.height / 2;
        b.classList.toggle('drop-after', after); b.classList.toggle('drop-before', !after);
      });
      b.addEventListener('dragleave', function () { b.classList.remove('drop-before', 'drop-after'); });
      b.addEventListener('drop', function (e) {
        e.preventDefault();
        if (!dragId || dragId === a.id) return;
        var r = b.getBoundingClientRect(), after = e.clientY > r.top + r.height / 2;
        var from = dockApps.findIndex(function (x) { return x.id === dragId; });
        var moved = dockApps.splice(from, 1)[0];
        var to = dockApps.findIndex(function (x) { return x.id === a.id; }) + (after ? 1 : 0);
        dockApps.splice(to, 0, moved);
        saveDock(); renderDock(); Sound.blip(700, 0, 0.04);
      });
      wrap.appendChild(b);
    });
    // FLIP-анимация перестановки
    $$('#dockApps .dock-app').forEach(function (el) {
      var was = before[el.dataset.id]; if (was === undefined) return;
      var dy = was - el.getBoundingClientRect().top; if (!dy) return;
      el.style.transform = 'translateY(' + dy + 'px)'; el.style.transition = 'none';
      requestAnimationFrame(function () { el.style.transition = ''; el.style.transform = ''; });
    });
    $('#dockEdit').classList.toggle('on', dockEdit);
    $('#dockEdit').title = dockEdit ? 'Готово' : 'Изменить: убрать или переставить';
  }

  function setDockEdit(on) { dockEdit = on; body.classList.toggle('dock-edit', on); renderDock(); }

  function removeApp(id) {
    var idx = dockApps.findIndex(function (x) { return x.id === id; }); if (idx < 0) return;
    var removed = dockApps.splice(idx, 1)[0];
    if (panelViews[id]) { panelViews[id].remove(); delete panelViews[id]; }
    if (panelCur === id) { closePanel(); panelCur = null; }
    saveDock(); renderDock();
    toast('Убрано из дока: ' + removed.title, 'Вернуть', function () { dockApps.splice(idx, 0, removed); saveDock(); renderDock(); $('#toast').classList.remove('on'); });
  }

  var dockAnimT;
  function openDock() { body.classList.add('dock-open', 'dock-anim'); clearTimeout(dockAnimT); dockAnimT = setTimeout(function () { body.classList.remove('dock-anim'); }, 900); $('#dockHandle').setAttribute('aria-expanded', 'true'); renderDock(); Sound.blip(640, 0, 0.04); }
  function closeDock() {
    if (!body.classList.contains('dock-open')) return;
    body.classList.remove('dock-open'); $('#dockHandle').setAttribute('aria-expanded', 'false');
    if (dockEdit) setDockEdit(false);
    hideEl($('#dockForm'), 170);
  }
  function toggleDock() { if (body.classList.contains('dock-open')) closeDock(); else openDock(); }
  $('#dockHandle').addEventListener('click', toggleDock);
  $('#dockEdit').addEventListener('click', function () { setDockEdit(!dockEdit); });

  // Клик мимо дока закрывает его (если не открыта панель приложения)
  document.addEventListener('mousedown', function (e) {
    if (!body.classList.contains('dock-open') || body.classList.contains('panel-open')) return;
    if (e.target.closest && (e.target.closest('#dock') || e.target.closest('#dockHandle') || e.target.closest('#dockForm') || e.target.closest('#toast'))) return;
    closeDock();
  });

  /* Добавить своё приложение */
  $('#dockAdd').addEventListener('click', function () {
    var f = $('#dockForm');
    if (isOpen(f)) return hideEl(f, 170);
    $('#dockName').value = ''; $('#dockUrl').value = '';
    var t = activeTab();
    $('#dockFromTab').hidden = !(t && t.url !== START);
    showEl(f);
    setTimeout(function () { $('#dockUrl').focus(); }, 30);
  });
  $('#dockFromTab').addEventListener('click', function () {
    var t = activeTab(); if (!t || t.url === START) return;
    $('#dockUrl').value = t.url;
    $('#dockName').value = (t.title || hostOf(t.url)).split(/\s[-–—|·:]\s/)[0].slice(0, 24);
  });
  $('#dockCancel').addEventListener('click', function () { hideEl($('#dockForm'), 170); });
  $('#dockForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var raw = $('#dockUrl').value.trim();
    if (!raw) return $('#dockUrl').focus();
    var url = /^https?:\/\//i.test(raw) ? raw : 'https://' + raw.replace(/^\/+/, '');
    var host = hostOf(url);
    if (!host || host.indexOf('.') < 0) { toast('Проверь адрес сайта'); return $('#dockUrl').focus(); }
    if (dockApps.some(function (x) { return hostOf(x.url) === host; })) { toast(host + ' уже в доке'); return; }
    var name = $('#dockName').value.trim() || host.split('.').slice(-2, -1)[0].replace(/^./, function (c) { return c.toUpperCase(); });
    dockApps.push({ id: 'c' + Date.now(), title: name, url: url });
    saveDock(); renderDock(); hideEl($('#dockForm'), 170);
    toast('Добавлено в док: ' + name); Sound.blip(990, 0, 0.05);
  });

  function panelView(a) {
    if (panelViews[a.id]) return panelViews[a.id];
    var v = document.createElement('webview');
    v.setAttribute('partition', 'persist:inver');
    v.setAttribute('allowpopups', '');
    v.setAttribute('src', a.url);
    v.addEventListener('page-favicon-updated', function (e) { try { iconHint(hostOf(v.getURL()), e.favicons); } catch (er) {} });
    v.addEventListener('page-title-updated', function (e) {
      var m = String(e.title).match(/^\((\d+)\)/) || String(e.title).match(/(\d+)\s+(?:непрочитан|unread)/i);
      var n = m ? Number(m[1]) : 0;
      if (n !== (unread[a.id] || 0)) { unread[a.id] = n; renderDock(); }
    });
    $('#panelViews').appendChild(v);
    panelViews[a.id] = v;
    return v;
  }

  function openPanel(id, toggle) {
    var a = appById(id) || dockApps[0];
    if (!a) return;
    var open = body.classList.contains('panel-open');
    if (toggle && open && panelCur === a.id) return closePanel();
    panelCur = a.id;
    var v = panelView(a);
    Object.keys(panelViews).forEach(function (k) { panelViews[k].classList.toggle('active', k === a.id); });
    $('#panelTitle').textContent = a.title;
    var old = $('#panelIco'); if (old) old.remove();
    var ico = siteIcon(hostOf(a.url), 'panel-ico'); ico.id = 'panelIco';
    $('#panelTitle').parentNode.insertBefore(ico, $('#panelTitle'));
    body.classList.add('panel-open');
    renderDock();
    Sound.blip(700, 0, 0.04);
    setTimeout(function () { try { v.focus(); } catch (e) {} }, 60);
  }
  function closePanel() { body.classList.remove('panel-open'); renderDock(); }
  function togglePanel() { toggleDock(); }

  $('#panelClose').addEventListener('click', closePanel);
  $('#panelReload').addEventListener('click', function () { var v = panelViews[panelCur]; if (v) v.reload(); });
  $('#panelTab').addEventListener('click', function () {
    var v = panelViews[panelCur]; if (!v) return;
    var u = ''; try { u = v.getURL(); } catch (e) {}
    newTab(u || (appById(panelCur) || {}).url);
    closePanel();
  });

  /* ---------- Вернуть закрытую вкладку ---------- */
  function reopenTab() {
    var url = closedTabs.pop();
    if (!url) return toast('Нет недавно закрытых вкладок');
    newTab(url);
  }

  /* ---------- Поиск по странице ---------- */
  var findText = '';
  function openFind() {
    var t = activeTab();
    if (!t || !t.view || t.url === START) return toast('Открой сайт, чтобы искать на странице');
    showEl($('#findBar'));
    $('#findInput').focus(); $('#findInput').select();
  }
  function closeFind() {
    hideEl($('#findBar'), 170); $('#findCount').textContent = ''; $('#findBar').classList.remove('miss');
    findText = '';
    tabs.forEach(function (t) { if (t.view) try { t.view.stopFindInPage('clearSelection'); } catch (e) {} });
  }
  function runFind(forward, next) {
    var t = activeTab(), q = $('#findInput').value;
    if (!t || !t.view) return;
    if (!q) { try { t.view.stopFindInPage('clearSelection'); } catch (e) {} $('#findCount').textContent = ''; $('#findBar').classList.remove('miss'); findText = ''; return; }
    var isNext = next && q === findText;
    findText = q;
    try { t.view.findInPage(q, { forward: forward !== false, findNext: !isNext }); } catch (e) {}
  }
  function onFound(r) {
    if (!r || !r.finalUpdate) return;
    $('#findCount').textContent = r.matches ? (r.activeMatchOrdinal + ' из ' + r.matches) : 'нет';
    $('#findBar').classList.toggle('miss', !r.matches && !!findText);
  }
  $('#findInput').addEventListener('input', function () { runFind(true, false); });
  $('#findBar').addEventListener('submit', function (e) { e.preventDefault(); runFind(true, true); });
  $('#findInput').addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && e.shiftKey) { e.preventDefault(); runFind(false, true); }
    if (e.key === 'Escape') { e.preventDefault(); closeFind(); }
  });
  $('#findNext').addEventListener('click', function () { runFind(true, true); });
  $('#findPrev').addEventListener('click', function () { runFind(false, true); });
  $('#findClose').addEventListener('click', closeFind);

  /* ---------- История ---------- */
  function addHistory(t) {
    if (settings.noHistory || t.priv || !t.url || t.url === START || !/^https?:/i.test(t.url)) return;
    var list = readJSON('inver.history', []);
    var title = t.title && t.title !== 'Новая вкладка' ? t.title : hostOf(t.url);
    if (list[0] && list[0].url === t.url && Date.now() - list[0].ts < 30 * 60 * 1000) list[0].title = title;
    else list.unshift({ url: t.url, title: title, ts: Date.now() });
    writeJSON('inver.history', list.slice(0, 3000));
    if (isOpen($('#library')) && libTab === 'history') renderLibrary();
  }

  /* ---------- Закладки ---------- */
  function bookmarks() { return readJSON('inver.bookmarks', []); }
  function isBookmarked(url) { return bookmarks().some(function (b) { return b.url === url; }); }
  function renderStar() {
    var t = activeTab(), on = !!(t && t.url !== START && isBookmarked(t.url));
    $('#starBtn').classList.toggle('on', on);
    $('#starBtn').title = on ? 'Убрать из закладок (Ctrl+D)' : 'Добавить в закладки (Ctrl+D)';
  }
  function toggleBookmark() {
    var t = activeTab();
    if (!t || t.url === START) return toast('Открой сайт, чтобы добавить его в закладки');
    var list = bookmarks();
    if (list.some(function (b) { return b.url === t.url; })) {
      writeJSON('inver.bookmarks', list.filter(function (b) { return b.url !== t.url; }));
      toast('Убрано из закладок');
    } else {
      list.unshift({ title: t.title && t.title !== 'Новая вкладка' ? t.title : hostOf(t.url), url: t.url, folder: '', ts: Date.now() });
      writeJSON('inver.bookmarks', list);
      toast('Добавлено в закладки', 'Открыть', function () { openLibrary('bookmarks'); $('#toast').classList.remove('on'); });
      Sound.blip(990, 0, 0.05);
    }
    renderStar();
    if (isOpen($('#library'))) renderLibrary();
  }
  $('#starBtn').addEventListener('click', toggleBookmark);

  /* ---------- Загрузки ---------- */
  var dlLive = {};
  function dlList() {
    var saved = readJSON('inver.downloads', []);
    var live = Object.keys(dlLive).map(function (k) { return dlLive[k]; });
    var ids = live.map(function (d) { return d.id + '|' + d.path; });
    return live.concat(saved.filter(function (d) { return ids.indexOf(d.id + '|' + d.path) < 0; })).sort(function (a, b) { return b.started - a.started; });
  }
  function fmtSize(n) { if (!n) return '0 Б'; var u = ['Б', 'КБ', 'МБ', 'ГБ'], i = Math.min(3, Math.floor(Math.log(n) / Math.log(1024))); return (n / Math.pow(1024, i)).toFixed(i ? 1 : 0).replace('.', ',') + ' ' + u[i]; }
  function renderDlBtn() {
    var live = Object.keys(dlLive).map(function (k) { return dlLive[k]; }).filter(function (d) { return d.state === 'progressing'; });
    var any = dlList().length > 0;
    $('#dlBtn').hidden = !any;
    $('#dlCount').textContent = String(live.length);
    $('#dlCount').classList.toggle('on', live.length > 0);
    var tot = 0, rec = 0; live.forEach(function (d) { tot += d.total || 0; rec += d.received || 0; });
    $('#dlRing').style.transform = 'scaleX(' + (live.length && tot ? Math.min(1, rec / tot) : 0) + ')';
  }
  api.onDownload(function (d) {
    var key = String(d.id) + '|' + d.path;
    var first = !dlLive[key];
    dlLive[key] = d;
    if (first && d.state === 'progressing') toast('Скачивается: ' + d.name, 'Загрузки', function () { openLibrary('downloads'); $('#toast').classList.remove('on'); });
    if (d.state !== 'progressing' && d.state !== 'interrupted') {
      delete dlLive[key];
      var saved = readJSON('inver.downloads', []).filter(function (x) { return x.path !== d.path; });
      saved.unshift(d);
      writeJSON('inver.downloads', saved.slice(0, 60));
      if (d.state === 'completed') { toast('Скачано: ' + d.name, 'Открыть', function () { api.dlAction(d.id, 'open', d.path); }); Sound.blip(880, 0, 0.05); Sound.blip(1320, 0.08, 0.06); }
      if (d.state === 'cancelled') toast('Загрузка отменена: ' + d.name);
    }
    renderDlBtn();
    if (isOpen($('#library')) && libTab === 'downloads') renderLibrary();
  });
  $('#dlBtn').addEventListener('click', function () { openLibrary('downloads'); });

  /* ---------- Библиотека ---------- */
  var libTab = 'history';
  function openLibrary(tab) {
    libTab = tab || libTab;
    closePops(); closeSettings();
    showEl($('#library'));
    $('#libSearch').value = '';
    renderLibrary();
    setTimeout(function () { $('#libSearch').focus(); }, 30);
  }
  function closeLibrary() { hideEl($('#library')); }
  $$('[data-libclose]').forEach(function (b) { b.addEventListener('click', closeLibrary); });
  $$('[data-lib]').forEach(function (b) { b.addEventListener('click', function () { libTab = b.dataset.lib; renderLibrary(); }); });
  $('#libSearch').addEventListener('input', renderLibrary);
  $('#libBtn').addEventListener('click', function () { openLibrary('history'); });

  function iconBtn(label, path, fn) {
    var b = document.createElement('button');
    b.className = 'icon-btn sm'; b.type = 'button';
    b.setAttribute('aria-label', label); b.title = label;
    b.innerHTML = '<svg viewBox="0 0 24 24">' + path + '</svg>';
    b.addEventListener('click', function (e) { e.stopPropagation(); fn(); });
    return b;
  }
  var ICON_X = '<path d="M6 6l12 12M18 6L6 18"/>';
  function libRow(title, sub, icon, onOpen) {
    var r = document.createElement('div');
    r.className = 'lib-row'; r.tabIndex = 0;
    r.innerHTML = '<div class="lib-main"><span class="lib-title"></span><span class="lib-sub"></span></div>';
    r.insertBefore(icon, r.firstChild);
    r.querySelector('.lib-title').textContent = title;
    r.querySelector('.lib-sub').textContent = sub;
    if (onOpen) { r.addEventListener('click', onOpen); r.addEventListener('keydown', function (e) { if (e.key === 'Enter') onOpen(); }); }
    return r;
  }
  function toolBtn(text, fn, cls) { var b = document.createElement('button'); b.className = cls || 'mini-btn'; b.type = 'button'; b.textContent = text; b.addEventListener('click', fn); return b; }
  function openUrl(url) { closeLibrary(); var t = activeTab(); if (t && t.url === START) navigate(url); else newTab(url); }
  function dayLabel(ts) {
    var d = new Date(ts), now = new Date(), start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    if (ts >= start) return 'Сегодня';
    if (ts >= start - 864e5) return 'Вчера';
    return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
  }

  function renderLibrary() {
    $$('[data-lib]').forEach(function (b) { b.classList.toggle('on', b.dataset.lib === libTab); b.setAttribute('aria-selected', String(b.dataset.lib === libTab)); });
    var q = $('#libSearch').value.trim().toLowerCase();
    var match = function (a, b) { return !q || (a || '').toLowerCase().indexOf(q) >= 0 || (b || '').toLowerCase().indexOf(q) >= 0; };
    var tools = $('#libTools'), list = $('#libList');
    tools.innerHTML = ''; list.innerHTML = '';
    var empty = function (text) { var p = document.createElement('p'); p.className = 'lib-empty'; p.textContent = text; list.appendChild(p); };

    if (libTab === 'history') {
      var hist = readJSON('inver.history', []);
      if (hist.length) tools.appendChild(toolBtn('Очистить историю', function () {
        var before = hist; writeJSON('inver.history', []); renderLibrary();
        toast('История очищена', 'Вернуть', function () { writeJSON('inver.history', before); renderLibrary(); $('#toast').classList.remove('on'); });
      }));
      if (settings.noHistory) { var n = document.createElement('span'); n.className = 'muted small'; n.textContent = 'Сейчас история не записывается (настройки → Приватность)'; tools.appendChild(n); }
      var shown = 0, lastDay = '';
      hist.forEach(function (h, idx) {
        if (shown >= 400 || !match(h.title, h.url)) return;
        var day = dayLabel(h.ts);
        if (day !== lastDay) { var c = document.createElement('p'); c.className = 'caps lib-day'; c.textContent = day; list.appendChild(c); lastDay = day; }
        var host = hostOf(h.url);
        var r = libRow(h.title || host, host, siteIcon(host, 'lib-ico'), function () { openUrl(h.url); });
        var tm = document.createElement('span'); tm.className = 'lib-time';
        var d = new Date(h.ts); tm.textContent = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
        var act = document.createElement('div'); act.className = 'lib-act';
        act.appendChild(iconBtn('Удалить из истории', ICON_X, function () { var l = readJSON('inver.history', []); l.splice(idx, 1); writeJSON('inver.history', l); renderLibrary(); }));
        r.appendChild(tm); r.appendChild(act);
        list.appendChild(r); shown++;
      });
      if (!shown) empty(q ? 'Ничего не найдено' : 'История пока пустая');
    }

    if (libTab === 'bookmarks') {
      var bms = bookmarks();
      var t = activeTab();
      if (t && t.url !== START) tools.appendChild(toolBtn(isBookmarked(t.url) ? 'Текущая страница уже в закладках' : 'Добавить текущую страницу', function () { if (!isBookmarked(t.url)) toggleBookmark(); }));
      tools.appendChild(toolBtn('Перенести из другого браузера', showImport));
      var shownB = 0;
      bms.forEach(function (b) {
        if (!match(b.title, b.url)) return;
        var host = hostOf(b.url);
        var r = libRow(b.title || host, (b.folder ? b.folder + ' · ' : '') + host, siteIcon(host, 'lib-ico'), function () { openUrl(b.url); });
        var act = document.createElement('div'); act.className = 'lib-act';
        act.appendChild(iconBtn('Удалить закладку', ICON_X, function () { writeJSON('inver.bookmarks', bookmarks().filter(function (x) { return x.url !== b.url; })); renderLibrary(); renderStar(); }));
        r.appendChild(act);
        list.appendChild(r); shownB++;
      });
      if (!shownB) empty(q ? 'Ничего не найдено' : 'Закладок пока нет. Нажми звёздочку в адресной строке или перенеси закладки из другого браузера.');
    }

    if (libTab === 'downloads') {
      var dls = dlList();
      if (dls.some(function (d) { return d.state !== 'progressing'; })) tools.appendChild(toolBtn('Очистить список', function () { writeJSON('inver.downloads', []); renderLibrary(); renderDlBtn(); }));
      var shownD = 0;
      dls.forEach(function (d) {
        if (!match(d.name, d.url)) return;
        var live = d.state === 'progressing' || d.state === 'interrupted';
        var status = live ? (fmtSize(d.received) + (d.total ? ' из ' + fmtSize(d.total) : '') + (d.paused ? ' · пауза' : '')) : d.state === 'completed' ? fmtSize(d.total || d.received) + ' · ' + hostOf(d.url) : d.state === 'cancelled' ? 'Отменено' : 'Ошибка загрузки';
        var ext = (d.name.split('.').pop() || '').slice(0, 3).toUpperCase();
        var fi = document.createElement('span'); fi.className = 'sico lib-ico file'; fi.style.setProperty('--tone', live ? 'var(--accent)' : toneFor(ext));
        fi.innerHTML = '<svg viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>';
        var r = libRow(d.name, status, fi, d.state === 'completed' ? function () { api.dlAction(d.id, 'open', d.path); } : null);
        r.classList.add('dl');
        if (live && d.total) { var bar = document.createElement('div'); bar.className = 'lib-bar'; bar.innerHTML = '<span></span>'; bar.firstChild.style.width = Math.round(100 * d.received / d.total) + '%'; r.querySelector('.lib-main').appendChild(bar); }
        var act = document.createElement('div'); act.className = 'lib-act';
        if (live) {
          act.appendChild(iconBtn(d.paused ? 'Продолжить' : 'Пауза', d.paused ? '<path d="M8 5l11 7-11 7z"/>' : '<path d="M8 5v14M16 5v14"/>', function () { api.dlAction(d.id, 'pause'); }));
          act.appendChild(iconBtn('Отменить', ICON_X, function () { api.dlAction(d.id, 'cancel'); }));
        } else if (d.state === 'completed') {
          act.appendChild(iconBtn('Показать в папке', '<path d="M3 7h6l2 2h10v10H3z"/>', function () { api.dlAction(d.id, 'show', d.path); }));
        }
        r.appendChild(act);
        list.appendChild(r); shownD++;
      });
      if (!shownD) empty(q ? 'Ничего не найдено' : 'Загрузок пока нет. Файлы сохраняются в папку «Загрузки».');
    }
  }

  function showImport() {
    var tools = $('#libTools'), list = $('#libList');
    list.innerHTML = '<p class="lib-empty">Ищу закладки в браузерах на этом компьютере…</p>';
    api.importSources().then(function (sources) {
      list.innerHTML = '';
      if (!sources || !sources.length) { list.innerHTML = '<p class="lib-empty">Не нашёл закладок Chrome, Оперы, Яндекс Браузера, Edge, Brave или Vivaldi на этом компьютере.</p>'; return; }
      var c = document.createElement('p'); c.className = 'caps lib-day'; c.textContent = 'Найдено на компьютере'; list.appendChild(c);
      sources.forEach(function (src) {
        var card = document.createElement('div'); card.className = 'import-card';
        card.innerHTML = '<span></span>';
        card.firstChild.textContent = src.name + ' · ' + src.items.length + ' закладок';
        card.appendChild(toolBtn('Перенести', function () {
          var have = bookmarks(), urls = have.map(function (b) { return b.url; }), added = 0;
          src.items.forEach(function (it) { if (urls.indexOf(it.url) < 0) { have.push({ title: it.title, url: it.url, folder: it.folder || src.name, ts: Date.now() }); urls.push(it.url); added++; } });
          writeJSON('inver.bookmarks', have);
          toast(added ? 'Перенесено закладок: ' + added : 'Все закладки уже были в Inver');
          libTab = 'bookmarks'; renderLibrary(); renderStar();
        }, 'outline-btn'));
        list.appendChild(card);
      });
    });
  }


  /* =====================================================================
     0.7.0 — Ctrl+K, цвет сайта, комнаты, превью, разделённый экран,
     картинка в картинке, чтение, фокус, обои, звуки, виджеты, AI сбоку
     ===================================================================== */
  var ICONS = {
    tab: '<path d="M4 6h16v13H4z"/><path d="M4 10h16"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
    shot: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><circle cx="12" cy="12" r="3"/>',
    space: '<path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/>',
    focus: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>',
    book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5"/>',
    pip: '<rect x="3" y="5" width="18" height="14" rx="2"/><rect x="12" y="11" width="7" height="6" rx="1"/>',
    spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
    split: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M12 4v16"/>',
    clock: '<path d="M3.5 12a8.5 8.5 0 1 0 2.5-6"/><path d="M3 4v4h4"/><path d="M12 8v4l3 2"/>',
    star: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
    down: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
    gear: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
    shield: '<path d="M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6l8-3z"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
    palette: '<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.2"/><circle cx="12" cy="7.5" r="1.2"/><circle cx="16" cy="10" r="1.2"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
    music: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
    room: '<rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="8" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/><rect x="13" y="13" width="8" height="8" rx="2"/>',
    translate: '<path d="M4 5h9M8.5 3v2M6 5c1 3 3.5 5.5 6 6.5M11 5c-1 3-3.5 6-7 7.5"/><path d="M13 21l4-9 4 9M14.5 18h5"/>',
    dock: '<rect x="3" y="4" width="7" height="16" rx="2"/><path d="M14 8h6M14 12h6M14 16h6"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    play: '<path d="M8 5l11 7-11 7z"/>', pause: '<path d="M8 5v14M16 5v14"/>',
    next: '<path d="M5 5l10 7-10 7zM19 5v14"/>', prev: '<path d="M19 5L9 12l10 7zM5 5v14"/>',
    send: '<path d="M5 12h14M13 6l6 6-6 6"/>'
  };
  // Безопасный вызов скрипта в странице: до готовности webview бросает исключение синхронно
  function runJs(v, code, gesture) { try { return Promise.resolve(v.executeJavaScript(code, !!gesture)); } catch (e) { return Promise.reject(e); } }
  function svg(name) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || ICONS.tab) + '</svg>'; }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---------- Сессия: вкладки и комнаты переживают перезапуск ---------- */
  var sessT;
  function saveSession() {
    clearTimeout(sessT);
    sessT = setTimeout(function () {
      writeJSON('inver.rooms', rooms);
      var act = {};
      Object.keys(roomActive).forEach(function (r) { var t = tabs.find(function (x) { return x.id === roomActive[r]; }); if (t && t.url !== START) act[r] = t.url; });
      writeJSON('inver.session', { cur: curRoom, act: act, tabs: tabs.filter(function (t) { return !t.priv && t.url !== START && /^https?:/.test(t.url); }).slice(0, 80).map(function (t) { return { room: t.room, url: t.url, title: t.title }; }) });
    }, 400);
  }
  function restoreSession() {
    var s = readJSON('inver.session', null);
    if (!s || !s.tabs || !s.tabs.length) return false;
    s.tabs.forEach(function (x) {
      if (!rooms.some(function (r) { return r.id === x.room; })) x.room = rooms[0].id;
      tabs.push({ id: ++seq, url: x.url, title: x.title || hostOf(x.url), view: null, room: x.room, lazy: true });
    });
    var mine = roomTabs();
    if (!mine.length) { newTab(); return true; }
    var want = s.act && s.act[curRoom];
    var pick = (want && mine.find(function (t) { return t.url === want; })) || mine[mine.length - 1];
    activate(pick.id);
    return true;
  }

  /* ---------- Цвет сайта красит браузер ---------- */
  function hexOf(rgb) { return '#' + rgb.map(function (c) { return ('0' + Math.round(Math.max(0, Math.min(255, c))).toString(16)).slice(-2); }).join(''); }
  function parseColor(c) {
    if (!c) return null;
    var m = /^#([0-9a-f]{3}){1,2}$/i.exec(c.trim());
    if (m) { var h = c.trim().slice(1); if (h.length === 3) h = h.replace(/./g, '$&$&'); var n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
    m = /rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i.exec(c);
    return m ? [+m[1], +m[2], +m[3]] : null;
  }
  function toHsl(r) { var R = r[0] / 255, G = r[1] / 255, B = r[2] / 255, mx = Math.max(R, G, B), mn = Math.min(R, G, B), l = (mx + mn) / 2, d = mx - mn, h = 0, s = 0; if (d) { s = d / (1 - Math.abs(2 * l - 1)); h = mx === R ? ((G - B) / d) % 6 : mx === G ? (B - R) / d + 2 : (R - G) / d + 4; h *= 60; if (h < 0) h += 360; } return [h, s, l]; }
  function fromHsl(h, s, l) { var c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2, r = [0, 0, 0]; if (h < 60) r = [c, x, 0]; else if (h < 120) r = [x, c, 0]; else if (h < 180) r = [0, c, x]; else if (h < 240) r = [0, x, c]; else if (h < 300) r = [x, 0, c]; else r = [c, 0, x]; return r.map(function (v) { return (v + m) * 255; }); }
  // Приводим цвет сайта к «акцентному»: достаточно насыщенный и средней яркости, серые и почти белые/чёрные не берём
  function usableAccent(rgb) {
    if (!rgb) return null;
    var hsl = toHsl(rgb);
    if (hsl[1] < 0.28 || hsl[2] < 0.08 || hsl[2] > 0.93) return null;
    return hexOf(fromHsl(hsl[0], Math.max(0.55, Math.min(0.9, hsl[1])), Math.max(0.42, Math.min(0.58, hsl[2]))));
  }
  function setAccentVars(hex) {
    var rgb = FX.hexRgb(hex), light = rgb.map(function (c) { return Math.round(c + (255 - c) * 0.45); }), root = document.documentElement.style;
    root.setProperty('--accent', hex);
    root.setProperty('--accent-soft', 'rgba(' + rgb.join(',') + ',0.30)');
    root.setProperty('--accent-light', 'rgb(' + light.join(',') + ')');
    Pixels.accent = hex;
  }
  function iconColor(host) {
    return loadIcon(host).then(function (ic) {
      if (!ic || !ic.src || !/^data:image\/(png|jpe?g|webp)/.test(ic.src)) return null;
      return new Promise(function (res) {
        var im = new Image();
        im.onload = function () {
          try {
            var c = document.createElement('canvas'); c.width = c.height = 24;
            var g = c.getContext('2d'); g.drawImage(im, 0, 0, 24, 24);
            var d = g.getImageData(0, 0, 24, 24).data, best = null, score = 0, buckets = {};
            for (var i = 0; i < d.length; i += 4) {
              if (d[i + 3] < 200) continue;
              var hsl = toHsl([d[i], d[i + 1], d[i + 2]]);
              if (hsl[1] < 0.3 || hsl[2] < 0.12 || hsl[2] > 0.9) continue;
              var k = Math.round(hsl[0] / 20);
              var b = buckets[k] || (buckets[k] = { n: 0, r: 0, g: 0, b: 0 });
              b.n++; b.r += d[i]; b.g += d[i + 1]; b.b += d[i + 2];
            }
            Object.keys(buckets).forEach(function (k) { var b = buckets[k]; if (b.n > score) { score = b.n; best = [b.r / b.n, b.g / b.n, b.b / b.n]; } });
            res(score > 12 ? best : null);
          } catch (e) { res(null); }
        };
        im.onerror = function () { res(null); };
        im.src = ic.src;
      });
    });
  }
  function readTheme(t) {
    if (!settings.siteTint || !t.view || t.theme) return;
    runJs(t.view, '(function(){var m=document.querySelector(\'meta[name="theme-color"]:not([media]),meta[name="theme-color"][media*="dark"],meta[name="theme-color"]\');return m?m.content:""})()')
      .then(function (c) { if (c && !t.theme) { t.theme = c; if (t.id === activeId) applyTint(t); } }).catch(function () {});
  }
  function applyTint(t) {
    if (!settings.siteTint || !t || t.url === START || spaceOn) { setAccentVars(settings.accent); return; }
    var direct = usableAccent(parseColor(t.theme));
    if (direct) { t.tint = direct; setAccentVars(direct); return; }
    if (t.tint) { setAccentVars(t.tint); return; }
    setAccentVars(settings.accent);
    var host = hostOf(t.url);
    iconColor(host).then(function (rgb) {
      var c = usableAccent(rgb);
      if (c && hostOf(t.url) === host) { t.tint = c; if (t.id === activeId) setAccentVars(c); }
    });
  }

  /* ---------- После переключения вкладки ---------- */
  function afterActivate(t) {
    applyTint(t);
    renderPageTools();
    layoutSplit();
    if (aiOpen) aiContextNote();
  }
  function renderPageTools() {
    var t = activeTab(), page = !!(t && t.url !== START && t.view);
    $('#pipBtn').hidden = !(page && t.media);
    $('#readBtn').hidden = !page;
  }

  /* ---------- Превью вкладок при наведении ---------- */
  function capturePreview(t) {
    if (!t || !t.view || t.url === START || t.lazy) return;
    try {
      t.view.capturePage().then(function (img) {
        try { var sm = img.resize ? img.resize({ width: 360 }) : img; t.thumb = sm.toDataURL(); } catch (e) {}
      }).catch(function () {});
    } catch (e) {}
  }
  var prevT, dragTab = null;
  function tabHooks(b, t) {
    b.addEventListener('mouseenter', function () {
      clearTimeout(prevT);
      prevT = setTimeout(function () { showPreview(b, t); }, 380);
    });
    b.addEventListener('mouseleave', function () { clearTimeout(prevT); hidePreview(); });
    b.addEventListener('contextmenu', function (e) { e.preventDefault(); tabMenu(t, e.clientX, e.clientY); });
    b.draggable = true;
    b.addEventListener('dragstart', function (e) { dragTab = t.id; hidePreview(); body.classList.add('tab-drag'); try { e.dataTransfer.setData('text/plain', String(t.id)); } catch (er) {} });
    b.addEventListener('dragend', function () { dragTab = null; body.classList.remove('tab-drag'); $('#splitDrop').classList.remove('hot'); });
  }
  function showPreview(b, t) {
    if (t.id === activeId && !split) return;
    var p = $('#tabPreview');
    var r = b.getBoundingClientRect();
    p.innerHTML = '';
    if (t.thumb) { var im = el('img'); im.src = t.thumb; im.alt = ''; p.appendChild(im); }
    else { var ph = el('div', 'tp-empty'); ph.appendChild(siteIcon(hostOf(t.url), 'tp-ico')); p.appendChild(ph); }
    var cap = el('div', 'tp-cap');
    cap.appendChild(el('strong', '', esc(t.title || 'Новая вкладка')));
    cap.appendChild(el('span', '', esc(t.url === START ? 'Стартовая страница' : hostOf(t.url))));
    p.appendChild(cap);
    p.style.left = Math.max(8, Math.min(window.innerWidth - 268, r.left)) + 'px';
    p.style.top = (r.bottom + 6) + 'px';
    showEl(p);
  }
  function hidePreview() { hideEl($('#tabPreview'), 140); }

  /* Меню вкладки по правому клику */
  function tabMenu(t, x, y) {
    var m = $('#tabMenu');
    m.innerHTML = '';
    var add = function (label, icon, fn) { var b = el('button', '', svg(icon) + '<span>' + esc(label) + '</span>'); b.addEventListener('click', function () { hideEl(m, 120); fn(); }); m.appendChild(b); };
    if (t.id !== activeId && t.url !== START && activeTab().url !== START) add('Открыть рядом с текущей', 'split', function () { startSplit(activeId, t.id); });
    add('Дублировать', 'tab', function () { newTab(t.url === START ? undefined : t.url, { priv: t.priv }); });
    if (t.url !== START && !t.priv) {
      add('Отложить на час', 'clock', function () { snooze(t, 3600e3); });
      add('Отложить до вечера', 'clock', function () { var d = new Date(); d.setHours(19, 0, 0, 0); if (d < Date.now() + 600e3) d.setDate(d.getDate() + 1); snooze(t, d - Date.now()); });
      add('Отложить до завтра', 'clock', function () { var d = new Date(); d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); snooze(t, d - Date.now()); });
    }
    if (t.view && t.url !== START) add(t.muted ? 'Включить звук' : 'Выключить звук', 'music', function () { t.muted = !t.muted; try { t.view.setAudioMuted(t.muted); } catch (e) {} renderTabs(); });
    if (rooms.length > 1) rooms.forEach(function (r) { if (r.id !== t.room) add('Перенести в «' + r.name + '»', 'room', function () { moveToRoom(t, r.id); }); });
    add('Закрыть', 'close', function () { closeTab(t.id); });
    m.style.left = Math.min(window.innerWidth - 250, x) + 'px'; m.style.top = y + 'px';
    showEl(m);
  }
  document.addEventListener('mousedown', function (e) { var m = $('#tabMenu'); if (isOpen(m) && !e.target.closest('#tabMenu')) hideEl(m, 120); });

  /* ---------- Разделённый экран ---------- */
  function startSplit(a, b) {
    var ta = tabs.find(function (x) { return x.id === a; }), tb = tabs.find(function (x) { return x.id === b; });
    if (!ta || !tb || ta.url === START || tb.url === START || a === b) return toast('Для разделения нужны две открытые страницы');
    if (spaceOn) return;
    if (tb.room !== ta.room) { tb.room = ta.room; }
    if (tb.lazy) { tb.lazy = false; ensureView(tb).setAttribute('src', tb.url); }
    split = { a: a, b: b, ratio: split ? split.ratio : 0.5 };
    activate(a);
    Sound.blip(780, 0, 0.05);
  }
  function exitSplit() { if (!split) return; split = null; var t = activeTab(); if (t) activate(t.id); }
  function toggleSplit() {
    if (split) return exitSplit();
    var cur = activeTab();
    var other = roomTabs().filter(function (x) { return x.id !== activeId && x.url !== START; }).pop();
    if (!cur || cur.url === START || !other) return toast('Открой ещё одну страницу в этой комнате или перетащи вкладку на правую половину экрана');
    startSplit(cur.id, other.id);
  }
  function layoutSplit() {
    var v = $('#views');
    v.style.setProperty('--split', ((split ? split.ratio : 0.5) * 100) + '%');
    $('#splitBar').hidden = !split;
  }
  (function () {
    var bar = $('#splitBar'), dragging = false;
    bar.addEventListener('mousedown', function (e) { if (e.target.closest('button')) return; dragging = true; body.classList.add('split-drag'); e.preventDefault(); });
    document.addEventListener('mousemove', function (e) {
      if (!dragging || !split) return;
      var r = $('#views').getBoundingClientRect();
      split.ratio = Math.max(0.2, Math.min(0.8, (e.clientX - r.left) / r.width));
      layoutSplit();
    });
    document.addEventListener('mouseup', function () { if (dragging) { dragging = false; body.classList.remove('split-drag'); } });
    $('#splitClose').addEventListener('click', exitSplit);
    $('#splitSwap').addEventListener('click', function () { if (!split) return; var a = split.a; split.a = split.b; split.b = a; activate(activeId); });
    // Перетащи вкладку на правую половину — откроется рядом
    var drop = $('#splitDrop');
    drop.addEventListener('dragover', function (e) { if (dragTab == null) return; e.preventDefault(); drop.classList.add('hot'); });
    drop.addEventListener('dragleave', function () { drop.classList.remove('hot'); });
    drop.addEventListener('drop', function (e) { e.preventDefault(); drop.classList.remove('hot'); var id = dragTab; dragTab = null; body.classList.remove('tab-drag'); if (id != null && id !== activeId) startSplit(activeId, id); });
  })();

  /* ---------- Комнаты ---------- */
  var ROOM_COLORS = ['#7C3AED', '#2563EB', '#0891B2', '#16A34A', '#EAB308', '#EA580C', '#D42A25', '#DB2777'];
  function renderRooms() {
    var r = rooms.find(function (x) { return x.id === curRoom; }) || rooms[0];
    var b = $('#roomBtn');
    b.style.setProperty('--room', r.color);
    $('#roomName').textContent = r.name;
    b.title = 'Комната: ' + r.name + ' (Alt+1…9)';
  }
  function switchRoom(id) {
    if (id === curRoom) return;
    exitSplit();
    var prev = activeTab(); if (prev) capturePreview(prev);
    curRoom = id;
    renderRooms();
    var mine = roomTabs();
    if (!mine.length) newTab();
    else activate((mine.find(function (t) { return t.id === roomActive[id]; }) || mine[mine.length - 1]).id);
    var r = rooms.find(function (x) { return x.id === id; });
    toast('Комната «' + r.name + '»');
    Sound.blip(640, 0, 0.04); Sound.blip(860, 0.06, 0.04);
  }
  function switchRoomByIndex(i) { if (rooms[i - 1]) switchRoom(rooms[i - 1].id); }
  function moveToRoom(t, room) {
    t.room = room;
    if (t.id === activeId) {
      var mine = roomTabs();
      if (mine.length) activate(mine[mine.length - 1].id); else newTab();
    } else renderTabs();
    toast('Вкладка перенесена');
  }
  function addRoom(name) {
    var used = rooms.map(function (r) { return r.color; });
    var color = ROOM_COLORS.find(function (c) { return used.indexOf(c) < 0; }) || ROOM_COLORS[rooms.length % ROOM_COLORS.length];
    var r = { id: 'r' + Date.now(), name: name || ('Комната ' + (rooms.length + 1)), color: color };
    rooms.push(r); saveSession(); switchRoom(r.id); renderRoomMenu();
    return r;
  }
  function renderRoomMenu() {
    var m = $('#roomMenu');
    m.innerHTML = '';
    rooms.forEach(function (r, i) {
      var row = el('div', 'room-row' + (r.id === curRoom ? ' on' : ''));
      row.style.setProperty('--room', r.color);
      var name = el('button', 'room-pick', '<i></i><span></span><small></small>');
      name.querySelector('span').textContent = r.name;
      name.querySelector('small').textContent = roomTabs(r.id).length + ' · Alt+' + (i + 1);
      name.addEventListener('click', function () { hideEl(m, 140); switchRoom(r.id); });
      name.addEventListener('dblclick', function () { renameRoom(r); });
      row.appendChild(name);
      var col = el('button', 'icon-btn sm', svg('palette')); col.title = 'Цвет'; col.setAttribute('aria-label', 'Цвет комнаты');
      col.addEventListener('click', function () { r.color = ROOM_COLORS[(ROOM_COLORS.indexOf(r.color) + 1) % ROOM_COLORS.length]; saveSession(); renderRooms(); renderRoomMenu(); });
      row.appendChild(col);
      var ren = el('button', 'icon-btn sm', '<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/></svg>'); ren.title = 'Переименовать'; ren.setAttribute('aria-label', 'Переименовать');
      ren.addEventListener('click', function () { renameRoom(r); });
      row.appendChild(ren);
      if (rooms.length > 1) {
        var del = el('button', 'icon-btn sm', svg('trash')); del.title = 'Удалить комнату'; del.setAttribute('aria-label', 'Удалить комнату');
        del.addEventListener('click', function () {
          var target = rooms.find(function (x) { return x.id !== r.id; });
          tabs.forEach(function (t) { if (t.room === r.id) t.room = target.id; });
          rooms = rooms.filter(function (x) { return x !== r; });
          if (curRoom === r.id) { curRoom = target.id; var mine = roomTabs(); if (mine.length) activate(mine[mine.length - 1].id); }
          saveSession(); renderRooms(); renderRoomMenu(); renderTabs();
          toast('Комната удалена, вкладки перенесены в «' + target.name + '»');
        });
        row.appendChild(del);
      }
      m.appendChild(row);
    });
    var add = el('button', 'room-add', svg('plus') + '<span>Новая комната</span>');
    add.addEventListener('click', function () { addRoom(); });
    m.appendChild(add);
  }
  function renameRoom(r) {
    var row = Array.prototype.find.call($$('#roomMenu .room-row'), function (x) { return x.querySelector('span').textContent === r.name; });
    if (!row) return;
    var inp = el('input', 'field room-input'); inp.value = r.name; inp.maxLength = 24;
    row.innerHTML = ''; row.appendChild(inp); inp.focus(); inp.select();
    var done = function () { var v = inp.value.trim(); if (v) r.name = v; saveSession(); renderRooms(); renderRoomMenu(); };
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') done(); if (e.key === 'Escape') { e.stopPropagation(); renderRoomMenu(); } });
    inp.addEventListener('blur', done);
  }
  $('#roomBtn').addEventListener('click', function (e) {
    e.stopPropagation();
    var m = $('#roomMenu');
    if (isOpen(m)) return hideEl(m, 140);
    renderRoomMenu(); showEl(m);
  });
  document.addEventListener('mousedown', function (e) { var m = $('#roomMenu'); if (isOpen(m) && !e.target.closest('#roomMenu') && !e.target.closest('#roomBtn')) hideEl(m, 140); });

  /* ---------- Картинка в картинке поверх всех окон ---------- */
  var PIP_JS = '(async function(){try{if(document.pictureInPictureElement){await document.exitPictureInPicture();return "off"}' +
    'var vs=[].slice.call(document.querySelectorAll("video")).filter(function(v){return v.readyState>0});' +
    'vs.sort(function(a,b){var pa=a.paused?0:1,pb=b.paused?0:1;if(pa!==pb)return pb-pa;var ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();return rb.width*rb.height-ra.width*ra.height});' +
    'var v=vs[0];if(!v)return "none";v.removeAttribute("disablepictureinpicture");v.disablePictureInPicture=false;await v.requestPictureInPicture();return "on"}catch(e){return "err:"+e.message}})()';
  function togglePip() {
    var t = activeTab();
    if (!t || !t.view || t.url === START) return toast('Открой страницу с видео');
    runJs(t.view, PIP_JS, true).then(function (r) {
      if (r === 'none') toast('На странице нет видео');
      else if (r === 'on') { toast('Видео в отдельном окошке поверх всех программ'); Sound.blip(880, 0, 0.05); }
      else if (/^err/.test(r)) toast('Сайт не дал вынести видео');
    }).catch(function () { toast('Не получилось вынести видео'); });
  }
  $('#pipBtn').addEventListener('click', togglePip);

  /* ---------- Режим чтения ---------- */
  var READER_JS = function (accent) {
    return '(' + function (ACC) {
      var old = document.getElementById('__inver_reader');
      if (old) { try { speechSynthesis.cancel(); } catch (e) {} old.remove(); document.documentElement.style.overflow = old.__ov || ''; return 'off'; }
      function score(n) { var s = 0; for (var i = 0; i < n.children.length; i++) { var c = n.children[i]; if (c.tagName === 'P') s += (c.innerText || '').length; } return s; }
      var best = null, bs = 0;
      [].slice.call(document.querySelectorAll('article, main, section, div')).forEach(function (n) { var s = score(n); if (n.tagName === 'ARTICLE') s *= 1.3; if (s > bs) { bs = s; best = n; } });
      if (!best || bs < 400) return 'none';
      var title = (document.querySelector('h1') || {}).innerText || document.title;
      var parts = [];
      [].slice.call(best.querySelectorAll('h2, h3, p, ul, ol, blockquote, pre, figure img, p img')).forEach(function (n) {
        if (n.closest('nav, aside, footer, form, [role="navigation"]')) return;
        var tag = n.tagName.toLowerCase();
        if (tag === 'img') { if (n.naturalWidth > 200 || n.width > 200) parts.push({ t: 'img', src: n.currentSrc || n.src }); return; }
        if ((tag === 'ul' || tag === 'ol') && n.closest('p')) return;
        var txt = (n.innerText || '').trim(); if (!txt) return;
        if (tag === 'p' && txt.length < 2) return;
        if (tag === 'ul' || tag === 'ol') parts.push({ t: tag, items: [].slice.call(n.querySelectorAll(':scope > li')).map(function (li) { return li.innerText.trim(); }).filter(Boolean) });
        else parts.push({ t: tag, text: txt });
      });
      var host = document.createElement('div'); host.id = '__inver_reader';
      host.style.cssText = 'position:fixed;inset:0;z-index:2147483646';
      var root = host.attachShadow({ mode: 'open' });
      var words = parts.reduce(function (n, p) { return n + (p.text || (p.items || []).join(' ')).split(/\s+/).length; }, 0);
      var css = ':host{all:initial}.w{position:fixed;inset:0;overflow:auto;background:var(--bg);color:var(--fg);font-family:Georgia,"Times New Roman",serif;transition:background .3s,color .3s;animation:in .35s ease}' +
        '.w.dark{--bg:#111116;--fg:#E8E6E0;--mut:#9A9AA5;--card:#1B1B22}.w.light{--bg:#FAFAF7;--fg:#1D1D20;--mut:#6B6B72;--card:#EEEEEA}.w.sepia{--bg:#F4ECD8;--fg:#3A2E1F;--mut:#7A6A55;--card:#E9DEC4}' +
        '.bar{position:sticky;top:0;display:flex;gap:6px;align-items:center;justify-content:center;padding:12px;background:color-mix(in srgb,var(--bg) 86%,transparent);backdrop-filter:blur(12px);z-index:2;font:600 13px "Segoe UI",system-ui,sans-serif}' +
        '.bar button{height:34px;min-width:34px;padding:0 12px;border:none;border-radius:10px;background:var(--card);color:var(--fg);cursor:pointer;font:inherit}.bar button.on{background:' + ACC + ';color:#fff}.bar .sp{width:1px;height:20px;background:var(--mut);opacity:.3;margin:0 4px}' +
        '.c{max-width:var(--mw,700px);margin:0 auto;padding:30px 24px 120px;font-size:var(--fs,20px);line-height:1.7}.meta{font:500 13px "Segoe UI",system-ui,sans-serif;color:var(--mut);margin-bottom:8px}' +
        'h1{font-size:1.9em;line-height:1.2;margin:0 0 .6em}h2{font-size:1.35em;margin:1.6em 0 .5em}h3{font-size:1.15em;margin:1.4em 0 .4em}p{margin:0 0 1em}img{max-width:100%;border-radius:10px;margin:1em 0}' +
        'blockquote{margin:1em 0;padding:.2em 1em;border-left:3px solid ' + ACC + ';color:var(--mut)}pre{white-space:pre-wrap;background:var(--card);padding:12px;border-radius:10px;font-size:.8em}.now{background:color-mix(in srgb,' + ACC + ' 22%,transparent);border-radius:6px}@keyframes in{from{opacity:0}}';
      var html = '<style>' + css + '</style><div class="w dark"><div class="bar">' +
        '<button data-a="close">Закрыть</button><span class="sp"></span><button data-a="minus">A−</button><button data-a="plus">A+</button><span class="sp"></span>' +
        '<button data-th="dark" class="on">Тёмная</button><button data-th="light">Светлая</button><button data-th="sepia">Сепия</button><span class="sp"></span><button data-a="speak">Слушать</button></div>' +
        '<div class="c"><div class="meta">' + location.hostname.replace(/^www\./, '') + ' · ' + Math.max(1, Math.round(words / 180)) + ' мин чтения</div><h1></h1><div class="body"></div></div></div>';
      root.innerHTML = html;
      root.querySelector('h1').textContent = title;
      var bodyEl = root.querySelector('.body');
      parts.forEach(function (p) {
        var n;
        if (p.t === 'img') { n = document.createElement('img'); n.src = p.src; n.alt = ''; }
        else if (p.t === 'ul' || p.t === 'ol') { n = document.createElement(p.t); p.items.forEach(function (it) { var li = document.createElement('li'); li.textContent = it; n.appendChild(li); }); }
        else { n = document.createElement(p.t); n.textContent = p.text; }
        bodyEl.appendChild(n);
      });
      var w = root.querySelector('.w'), fs = 20;
      host.__ov = document.documentElement.style.overflow; document.documentElement.style.overflow = 'hidden';
      function close() { try { speechSynthesis.cancel(); } catch (e) {} document.documentElement.style.overflow = host.__ov || ''; host.remove(); }
      root.addEventListener('click', function (e) {
        var b = e.target.closest('button'); if (!b) return;
        if (b.dataset.th) { w.className = 'w ' + b.dataset.th; [].slice.call(root.querySelectorAll('[data-th]')).forEach(function (x) { x.classList.toggle('on', x === b); }); }
        if (b.dataset.a === 'close') close();
        if (b.dataset.a === 'plus') { fs = Math.min(30, fs + 2); w.style.setProperty('--fs', fs + 'px'); }
        if (b.dataset.a === 'minus') { fs = Math.max(14, fs - 2); w.style.setProperty('--fs', fs + 'px'); }
        if (b.dataset.a === 'speak') {
          if (speechSynthesis.speaking) { speechSynthesis.cancel(); b.classList.remove('on'); b.textContent = 'Слушать'; return; }
          var nodes = [].slice.call(root.querySelectorAll('h1, .body > *')).filter(function (n) { return n.tagName !== 'IMG' && n.textContent.trim(); });
          var lang = (document.documentElement.lang || '').slice(0, 2) || (/[а-яё]/i.test(title) ? 'ru' : 'en');
          var voice = speechSynthesis.getVoices().find(function (v) { return v.lang.indexOf(lang) === 0; });
          b.classList.add('on'); b.textContent = 'Стоп';
          var i = 0;
          (function next() {
            nodes.forEach(function (n) { n.classList.remove('now'); });
            if (i >= nodes.length) { b.classList.remove('on'); b.textContent = 'Слушать'; return; }
            var n = nodes[i++]; n.classList.add('now'); n.scrollIntoView({ block: 'center', behavior: 'smooth' });
            var u = new SpeechSynthesisUtterance(n.textContent); if (voice) u.voice = voice; u.lang = voice ? voice.lang : lang; u.rate = 1.05;
            u.onend = next; u.onerror = function () { b.classList.remove('on'); b.textContent = 'Слушать'; };
            speechSynthesis.speak(u);
          })();
        }
      });
      host.tabIndex = -1;
      document.addEventListener('keydown', function k(e) { if (e.key === 'Escape' && document.getElementById('__inver_reader')) { close(); document.removeEventListener('keydown', k, true); } }, true);
      document.documentElement.appendChild(host);
      return 'on';
    }.toString() + ')(' + JSON.stringify(accent) + ')';
  };
  function toggleReader() {
    var t = activeTab();
    if (!t || !t.view || t.url === START) return toast('Открой статью, чтобы читать без мусора');
    runJs(t.view, READER_JS(getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || settings.accent), true).then(function (r) {
      if (r === 'none') toast('Не нашёл на странице статью');
      else if (r === 'on') Sound.blip(700, 0, 0.04);
    }).catch(function () { toast('Режим чтения недоступен на этой странице'); });
  }
  $('#readBtn').addEventListener('click', toggleReader);

  /* ---------- Режим фокуса ---------- */
  var FOCUS_BLOCK_DEFAULT = ['youtube.com', 'vk.com', 'tiktok.com', 'instagram.com', 'twitch.tv', 'reddit.com', 'x.com', 'twitter.com', 'dzen.ru', 'pikabu.ru'];
  var focus = { on: false, end: 0, paused: 0, block: true, list: readJSON('inver.focusBlock', FOCUS_BLOCK_DEFAULT) }, focusT;
  function focusBlocked(url) {
    if (!focus.on || !focus.block || !/^https?:/.test(url || '')) return false;
    var h = hostOf(url);
    return focus.list.some(function (d) { return h === d || h.slice(-(d.length + 1)) === '.' + d; });
  }
  function blockPage(t, url) {
    var acc = settings.accent, h = hostOf(url);
    var page = '<!doctype html><meta charset="utf-8"><title>Фокус</title><style>html,body{height:100%;margin:0;background:#0B0B10;color:#F4F1EA;font:16px "Segoe UI",system-ui,sans-serif;display:flex;align-items:center;justify-content:center;text-align:center}' +
      'div{max-width:420px;padding:32px;border-radius:24px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12)}b{display:block;font-size:22px;margin-bottom:8px}i{display:block;width:56px;height:56px;margin:0 auto 18px;border-radius:50%;border:3px solid ' + acc + ';box-shadow:0 0 30px ' + acc + '}p{color:#9A9AA5;margin:0}</style>' +
      '<div><i></i><b>' + esc(h) + ' на паузе</b><p>Сейчас идёт режим фокуса. Сайт откроется, когда таймер закончится или ты выйдешь из фокуса.</p></div>';
    var v = ensureView(t);
    t.url = url; t.title = 'Фокус · ' + h;
    v.setAttribute('src', 'data:text/html;charset=utf-8,' + encodeURIComponent(page));
    renderTabs();
  }
  function fmtTime(ms) { var s = Math.max(0, Math.round(ms / 1000)); return Math.floor(s / 60) + ':' + ('0' + s % 60).slice(-2); }
  function startFocus(min, block) {
    closeFocusPop();
    focus.on = true; focus.block = block; focus.end = min ? Date.now() + min * 60000 : 0; focus.paused = 0;
    body.classList.add('focus-mode');
    closeDock(); closePanel();
    renderFocus();
    clearInterval(focusT); focusT = setInterval(renderFocus, 1000);
    Sound.chime(true);
    var t = activeTab(); if (t && focusBlocked(t.url)) blockPage(t, t.url);
  }
  function stopFocus(done) {
    focus.on = false; clearInterval(focusT);
    body.classList.remove('focus-mode');
    tabs.forEach(function (t) { if (/^Фокус · /.test(t.title || '') && t.view) { t.title = hostOf(t.url); t.view.setAttribute('src', t.url); } });
    renderTabs();
    Sound.chime(false);
    if (done) toast('Фокус закончен. Отличная работа');
  }
  function renderFocus() {
    if (!focus.on) return;
    var left = focus.end ? (focus.paused ? focus.end - focus.paused : focus.end - Date.now()) : 0;
    $('#focusTime').textContent = focus.end ? fmtTime(left) : 'фокус';
    $('#focusPause').hidden = !focus.end;
    $('#focusPause').innerHTML = svg(focus.paused ? 'play' : 'pause');
    $('#focusPlus').hidden = !focus.end;
    if (focus.end && !focus.paused && left <= 0) stopFocus(true);
  }
  function toggleFocus() { if (focus.on) stopFocus(); else openFocusPop(); }
  function openFocusPop() { closePops(); renderFocusList(); showEl($('#focusPop')); }
  function closeFocusPop() { hideEl($('#focusPop'), 160); }
  function renderFocusList() { $('#focusList').value = focus.list.join('\n'); }
  $('#focusBtn').addEventListener('click', function (e) { e.stopPropagation(); if (focus.on) stopFocus(); else if (isOpen($('#focusPop'))) closeFocusPop(); else openFocusPop(); });
  $$('[data-focus]').forEach(function (b) { b.addEventListener('click', function () { startFocus(Number(b.dataset.focus), $('#focusBlock').checked); }); });
  $('#focusList').addEventListener('change', function (e) { focus.list = e.target.value.split(/[\s,]+/).map(function (d) { return d.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, ''); }).filter(Boolean); writeJSON('inver.focusBlock', focus.list); });
  $('#focusStop').addEventListener('click', function () { stopFocus(); });
  $('#focusPlus').addEventListener('click', function () { if (focus.end) { focus.end += 5 * 60000; renderFocus(); } });
  $('#focusPause').addEventListener('click', function () {
    if (!focus.end) return;
    if (focus.paused) { focus.end += Date.now() - focus.paused; focus.paused = 0; } else focus.paused = Date.now();
    renderFocus();
  });
  document.addEventListener('mousedown', function (e) { if (isOpen($('#focusPop')) && !e.target.closest('#focusPop') && !e.target.closest('#focusBtn')) closeFocusPop(); });

  /* ---------- Обои: живые сцены и своя картинка ---------- */
  function applyWall() {
    var img = settings.wall === 'image' ? (localStorage.getItem('inver.wallImage') || '') : '';
    body.classList.toggle('wall-image', !!img);
    $('#wallImg').style.backgroundImage = img ? 'url("' + img + '")' : '';
    Pixels.wall = img ? 'blobs' : (settings.wall || 'blobs');
    $$('#wallModes button').forEach(function (b) { b.classList.toggle('on', b.dataset.wall === settings.wall); });
  }
  $$('#wallModes button').forEach(function (b) {
    b.addEventListener('click', function () {
      if (b.dataset.wall === 'image' && !localStorage.getItem('inver.wallImage')) return $('#wallFile').click();
      settings.wall = b.dataset.wall; saveSettings();
    });
  });
  $('#wallPick').addEventListener('click', function () { $('#wallFile').click(); });
  $('#wallFile').addEventListener('change', function (e) {
    var f = e.target.files && e.target.files[0]; if (!f) return;
    var rd = new FileReader();
    rd.onload = function () {
      var im = new Image();
      im.onload = function () {
        var k = Math.min(1, 2560 / Math.max(im.width, im.height)), c = document.createElement('canvas');
        c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        var g = c.getContext('2d'); g.drawImage(im, 0, 0, c.width, c.height);
        var data = c.toDataURL('image/jpeg', 0.86);
        try { localStorage.setItem('inver.wallImage', data); } catch (er) { data = c.toDataURL('image/jpeg', 0.6); try { localStorage.setItem('inver.wallImage', data); } catch (er2) { return toast('Картинка слишком большая'); } }
        // Цвет темы из картинки: самый частый насыщенный оттенок
        var s = document.createElement('canvas'); s.width = s.height = 48; var sg = s.getContext('2d'); sg.drawImage(im, 0, 0, 48, 48);
        var d = sg.getImageData(0, 0, 48, 48).data, buckets = {}, best = null, n = 0;
        for (var i = 0; i < d.length; i += 4) { var hsl = toHsl([d[i], d[i + 1], d[i + 2]]); if (hsl[1] < 0.3 || hsl[2] < 0.15 || hsl[2] > 0.88) continue; var key = Math.round(hsl[0] / 18); var b = buckets[key] || (buckets[key] = { n: 0, r: 0, g: 0, b: 0 }); b.n++; b.r += d[i]; b.g += d[i + 1]; b.b += d[i + 2]; }
        Object.keys(buckets).forEach(function (key) { var b = buckets[key]; if (b.n > n) { n = b.n; best = [b.r / b.n, b.g / b.n, b.b / b.n]; } });
        var acc = usableAccent(best);
        settings.wall = 'image';
        if (acc) settings.accent = acc;
        saveSettings();
        toast(acc ? 'Обои поставлены, цвет темы взят из картинки' : 'Обои поставлены');
      };
      im.src = rd.result;
    };
    rd.readAsDataURL(f);
    e.target.value = '';
  });

  /* ---------- Звуковые темы ---------- */
  function applySoundTheme() {
    Sound.theme = settings.soundTheme || 'inver';
    $$('#soundModes button').forEach(function (b) { b.classList.toggle('on', b.dataset.st === Sound.theme); });
  }
  $$('#soundModes button').forEach(function (b) { b.addEventListener('click', function () { settings.soundTheme = b.dataset.st; saveSettings(); Sound.blip(760, 0, 0.06); Sound.blip(980, 0.08, 0.06); }); });

  /* ---------- Виджеты стартовой страницы ---------- */
  var MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
  var DAYS = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
  function tickClock() {
    var d = new Date();
    $('#wTime').textContent = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    $('#wDate').textContent = greet() + '\n' + DAYS[d.getDay()] + ', ' + d.getDate() + ' ' + MONTHS[d.getMonth()];
  }
  var WCODES = [[[0], 'Ясно', 'sun'], [[1, 2], 'Малооблачно', 'cloudsun'], [[3], 'Пасмурно', 'cloud'], [[45, 48], 'Туман', 'fog'], [[51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82], 'Дождь', 'rain'], [[71, 73, 75, 77, 85, 86], 'Снег', 'snow'], [[95, 96, 99], 'Гроза', 'storm']];
  var WICON = {
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    cloudsun: '<path d="M8 4v1M3.5 6l.8.8M2 11h1M12.5 6.8l.8-.8"/><path d="M5.6 12.5A4 4 0 0 1 12 8"/><path d="M17.5 20H8a4 4 0 1 1 .9-7.9 5 5 0 0 1 9.6 1.4 3.3 3.3 0 0 1-1 6.5z"/>',
    cloud: '<path d="M17.5 19H8a5 5 0 1 1 1.3-9.8 6 6 0 0 1 11.2 3 3.5 3.5 0 0 1-3 6.8z"/>',
    fog: '<path d="M4 9h16M3 13h18M5 17h14"/>',
    rain: '<path d="M17.5 15H8a5 5 0 1 1 1.3-9.8 6 6 0 0 1 11.2 3 3.5 3.5 0 0 1-3 6.8z"/><path d="M8 18l-1 3M12 18l-1 3M16 18l-1 3"/>',
    snow: '<path d="M17.5 14H8a5 5 0 1 1 1.3-9.8 6 6 0 0 1 11.2 3 3.5 3.5 0 0 1-3 6.8z"/><path d="M8 18h.01M12 19h.01M16 18h.01M10 21h.01M14 21h.01"/>',
    storm: '<path d="M17.5 14H8a5 5 0 1 1 1.3-9.8 6 6 0 0 1 11.2 3 3.5 3.5 0 0 1-3 6.8z"/><path d="M13 14l-3 4h4l-3 4"/>'
  };
  function weather(force) {
    var box = $('#wWeather');
    if (!settings.city) { box.innerHTML = '<button class="w-city-btn" id="wCitySet">' + svg('globe') + '<span>Укажи город для погоды</span></button>'; $('#wCitySet').addEventListener('click', askCity); return; }
    var cache = readJSON('inver.weather', null);
    if (!force && cache && cache.city === settings.city && Date.now() - cache.ts < 20 * 60000) return drawWeather(cache);
    fetch('https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&name=' + encodeURIComponent(settings.city))
      .then(function (r) { return r.json(); })
      .then(function (g) {
        var p = g.results && g.results[0]; if (!p) throw new Error('city');
        return fetch('https://api.open-meteo.com/v1/forecast?latitude=' + p.latitude + '&longitude=' + p.longitude + '&current=temperature_2m,weather_code,wind_speed_10m,apparent_temperature&daily=temperature_2m_max,temperature_2m_min&forecast_days=1&timezone=auto')
          .then(function (r) { return r.json(); }).then(function (w) {
            var c = { city: settings.city, name: p.name, t: w.current.temperature_2m, feel: w.current.apparent_temperature, code: w.current.weather_code, wind: w.current.wind_speed_10m, max: w.daily.temperature_2m_max[0], min: w.daily.temperature_2m_min[0], ts: Date.now() };
            writeJSON('inver.weather', c); drawWeather(c);
          });
      }).catch(function (e) {
        if (cache && cache.city === settings.city) return drawWeather(cache);
        box.innerHTML = '<button class="w-city-btn" id="wCitySet">' + svg('globe') + '<span>' + (e.message === 'city' ? 'Город не найден, укажи другой' : 'Погода недоступна, нет сети') + '</span></button>';
        $('#wCitySet').addEventListener('click', askCity);
      });
  }
  function drawWeather(c) {
    var w = WCODES.find(function (x) { return x[0].indexOf(c.code) >= 0; }) || WCODES[2];
    $('#wWeather').innerHTML = '<div class="w-wx"><svg viewBox="0 0 24 24" aria-hidden="true">' + WICON[w[2]] + '</svg><b>' + Math.round(c.t) + '°</b><div><span>' + esc(w[1]) + '</span><small>' + esc(c.name) + ' · ' + Math.round(c.min) + '° / ' + Math.round(c.max) + '°</small></div></div>';
    $('#wWeather').title = 'Ощущается как ' + Math.round(c.feel) + '°, ветер ' + Math.round(c.wind) + ' км/ч. Клик — сменить город';
    $('#wWeather').onclick = askCity;
  }
  function askCity() {
    var box = $('#wWeather');
    box.onclick = null;
    box.innerHTML = '<form class="w-city" autocomplete="off"><input class="field" placeholder="Город, например Москва" value="' + esc(settings.city) + '"><button class="mini-btn">ОК</button></form>';
    var f = box.querySelector('form'), inp = f.querySelector('input');
    inp.focus();
    f.addEventListener('submit', function (e) { e.preventDefault(); settings.city = inp.value.trim(); writeJSON('inver.settings', settings); weather(true); });
    inp.addEventListener('keydown', function (e) { if (e.key === 'Escape') { e.stopPropagation(); weather(); } });
  }
  // Что играет: Яндекс Музыка и другие приложения в доке, плюс вкладки с видео
  var MEDIA_JS = '(function(){var m=navigator.mediaSession&&navigator.mediaSession.metadata;var a=[].slice.call(document.querySelectorAll("audio,video")).find(function(x){return !x.paused});' +
    'var st=navigator.mediaSession?navigator.mediaSession.playbackState:"";var art="";if(m&&m.artwork&&m.artwork.length){art=m.artwork[m.artwork.length-1].src}' +
    'return {title:m?m.title:"",artist:m?m.artist:"",art:art,playing:!!a||st==="playing",has:!!m||!!a}})()';
  var CTRL_JS = function (what) {
    return '(function(w){var sel={play:["[aria-label*=\\"Воспроизвед\\"]","[aria-label*=\\"Пауза\\"]","[aria-label*=\\"Play\\"]","[aria-label*=\\"Pause\\"]","[data-test-id=\\"PLAY_BUTTON\\"]","[data-test-id=\\"PAUSE_BUTTON\\"]"],next:["[aria-label*=\\"Следующ\\"]","[aria-label*=\\"Next\\"]","[data-test-id=\\"NEXT_TRACK_BUTTON\\"]"],prev:["[aria-label*=\\"Предыдущ\\"]","[aria-label*=\\"Previous\\"]","[data-test-id=\\"PREV_TRACK_BUTTON\\"]"]};' +
      'if(w==="play"){var ms=[].slice.call(document.querySelectorAll("audio,video")).filter(function(x){return x.src||x.currentSrc});if(ms.length){var p=ms.find(function(x){return !x.paused});if(p)p.pause();else ms[0].play();return true}}' +
      'for(var i=0;i<sel[w].length;i++){var b=document.querySelector(sel[w][i]);if(b){b.click();return true}}return false})(' + JSON.stringify(what) + ')';
  };
  var mediaSrc = null;
  function mediaSources() {
    var list = [];
    Object.keys(panelViews).forEach(function (id) { list.push({ view: panelViews[id], name: (appById(id) || {}).title || '', dock: id }); });
    tabs.forEach(function (t) { if (t.view && t.media) list.push({ view: t.view, name: t.title, tab: t.id }); });
    return list;
  }
  function pollMedia() {
    if (!settings.widgets || body.classList.contains('has-page')) return;
    var src = mediaSources();
    if (!src.length) return drawMedia(null);
    Promise.all(src.map(function (s) { return runJs(s.view, MEDIA_JS).then(function (r) { return r && r.has ? Object.assign({ src: s }, r) : null; }).catch(function () { return null; }); }))
      .then(function (res) { res = res.filter(Boolean); drawMedia(res.find(function (r) { return r.playing; }) || res[0] || null); });
  }
  function drawMedia(m) {
    mediaSrc = m && m.src;
    var box = $('#wMusic');
    if (!m) {
      var ym = dockApps.find(function (a) { return /music\.yandex|music\.youtube|spotify|soundcloud/.test(a.url); });
      box.innerHTML = '<div class="w-mu empty"><span class="w-art">' + svg('music') + '</span><div><b>Ничего не играет</b><small>' + (ym ? 'Включи музыку в доке' : 'Добавь музыку в док') + '</small></div></div>';
      if (ym) { var b = el('button', 'mini-btn', 'Открыть'); b.addEventListener('click', function () { openDock(); openPanel(ym.id); }); box.firstChild.appendChild(b); }
      return;
    }
    box.innerHTML = '<div class="w-mu"><span class="w-art"></span><div class="w-mu-t"><b></b><small></small></div><div class="w-mu-c"><button data-m="prev" class="icon-btn sm" aria-label="Предыдущий">' + svg('prev') + '</button><button data-m="play" class="icon-btn sm" aria-label="Пауза или воспроизведение">' + svg(m.playing ? 'pause' : 'play') + '</button><button data-m="next" class="icon-btn sm" aria-label="Следующий">' + svg('next') + '</button></div></div>';
    var art = box.querySelector('.w-art');
    if (m.art) { var im = el('img'); im.src = m.art; im.alt = ''; im.referrerPolicy = 'no-referrer'; im.onerror = function () { art.innerHTML = svg('music'); }; art.appendChild(im); } else art.innerHTML = svg('music');
    box.querySelector('b').textContent = m.title || m.src.name || 'Музыка';
    box.querySelector('small').textContent = m.artist || m.src.name || '';
    $$('#wMusic [data-m]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (!mediaSrc) return;
        runJs(mediaSrc.view, CTRL_JS(b.dataset.m), true).then(function () { setTimeout(pollMedia, 400); }).catch(function () {});
      });
    });
  }
  function applyWidgets() {
    body.classList.toggle('widgets-on', !!settings.widgets);
    var n = $('#wNote');
    if (document.activeElement !== n) n.value = localStorage.getItem('inver.note') || '';
  }
  $('#wNote').addEventListener('input', function (e) { try { localStorage.setItem('inver.note', e.target.value); } catch (er) {} });

  /* ---------- AI-помощник сбоку ---------- */
  var aiOpen = false, aiHistory = [];
  var AI_SYSTEM = 'Ты — помощник, встроенный в браузер Inver. Отвечай по-русски, коротко и по делу, без воды. Если дан текст страницы, опирайся на него. Используй простое форматирование: абзацы и списки через «- ».';
  function toggleAi() { if (aiOpen) closeAi(); else openAi(); }
  function openAi() {
    aiOpen = true; body.classList.add('ai-open'); aiContextNote();
    setTimeout(function () { $('#aiPanelInput').focus(); }, 60);
    Sound.blip(760, 0, 0.04);
  }
  function closeAi() { aiOpen = false; body.classList.remove('ai-open'); }
  function aiContextNote() {
    var t = activeTab();
    $('#aiCtx').textContent = t && t.url !== START ? 'Страница: ' + (t.title || hostOf(t.url)) : 'Открой сайт, чтобы спрашивать про страницу';
    if (!settings.ollama && !settings.apiKey && LOCAL) { refreshAiLocal(); aiLocalReady().catch(function () {}); }
    else $('#aiSetup').hidden = true;
  }
  function pageText() {
    var t = activeTab();
    if (!t || !t.view || t.url === START) return Promise.resolve('');
    return runJs(t.view, '(function(){var a=document.querySelector("article,main")||document.body;return (document.title+"\\n"+location.href+"\\n\\n"+(a.innerText||"")).slice(0,14000)})()').catch(function () { return ''; });
  }
  function aiBubble(text, who) {
    var m = el('div', 'ai-msg ' + who);
    if (who === 'ai') {
      text.split(/\n{2,}/).forEach(function (para) {
        var lines = para.split('\n');
        if (lines.every(function (l) { return /^\s*([-•*]|\d+[.)])\s+/.test(l); })) {
          var ul = el('ul'); lines.forEach(function (l) { var li = el('li'); li.textContent = l.replace(/^\s*([-•*]|\d+[.)])\s+/, '').replace(/\*\*/g, ''); ul.appendChild(li); }); m.appendChild(ul);
        } else { var p = el('p'); p.textContent = para.replace(/\*\*/g, ''); m.appendChild(p); }
      });
    } else m.textContent = text;
    $('#aiThread').appendChild(m);
    $('#aiThread').scrollTop = 1e6;
    return m;
  }
  /* Встроенная нейросеть: Inver сам скачивает и запускает её, пользователю ничего делать не нужно */
  var aiLocalState = { phase: 'idle' };
  var LOCAL = window.inver && window.inver.aiLocal;
  function aiLocalReady() {
    if (!LOCAL) return Promise.reject(new Error('Встроенная нейросеть работает только в приложении'));
    return LOCAL.ensure(settings.aiModel || 'light').then(function (r) { if (!r || !r.ok) throw new Error((r && r.error) || 'Не получилось запустить нейросеть'); return r; });
  }
  // Ответ печатается по ходу: onDelta получает уже набранный текст
  var chatSeq = 0, chatWaiters = {};
  if (LOCAL && LOCAL.onDelta) LOCAL.onDelta(function (id, text) { if (chatWaiters[id]) chatWaiters[id](text); });
  function localChat(messages, system, maxTokens, onDelta) {
    if (!LOCAL || !LOCAL.chat) return Promise.reject(new Error('Встроенная нейросеть работает только в приложении'));
    var id = ++chatSeq;
    if (onDelta) chatWaiters[id] = onDelta;
    return LOCAL.chat(id, settings.aiModel || 'light', messages, system, maxTokens || 600).then(function (r) {
      delete chatWaiters[id];
      if (!r || !r.ok) throw new Error((r && r.error) || 'Нейросеть не ответила');
      return r.text;
    }, function (e) { delete chatWaiters[id]; throw e; });
  }
  function renderAiLocal(st) {
    aiLocalState = st || aiLocalState;
    var box = $('#aiSetup'), useLocal = !settings.ollama && !settings.apiKey;
    var show = useLocal && aiLocalState.phase !== 'ready' && (aiLocalState.phase !== 'idle' || !aiLocalState.installed);
    box.hidden = !show;
    box.classList.toggle('error', aiLocalState.phase === 'error');
    $('#aiSetupBtn').hidden = aiLocalState.phase !== 'error';
    $('#aiSetupText').textContent = aiLocalState.phase === 'error' ? 'Не получилось: ' + aiLocalState.error
      : aiLocalState.phase === 'downloading' ? 'Скачиваю нейросеть один раз, дальше без интернета. ' + (aiLocalState.text || '')
      : aiLocalState.phase === 'starting' ? 'Запускаю нейросеть…' : 'Готовлю встроенную нейросеть';
    $('#aiSetupBar').style.width = Math.round((aiLocalState.progress || 0) * 100) + '%';
    var hint = $('#aiLocalHint');
    if (hint) hint.textContent = aiLocalState.phase === 'ready' ? 'Работает на твоём компьютере, без интернета.' : aiLocalState.installed ? 'Скачана. Запустится сама, когда откроешь помощника.' : 'Скачается сама один раз при первом открытии помощника, дальше работает без интернета.';
  }
  if (LOCAL) LOCAL.onState(function (st) { renderAiLocal(Object.assign({ installed: aiLocalState.installed }, st)); });
  function refreshAiLocal() { if (LOCAL) LOCAL.status(settings.aiModel || 'light').then(renderAiLocal).catch(function () {}); }
  $('#aiSetupBtn').addEventListener('click', function () { aiLocalReady().catch(function () {}); });
  $$('#aiModels [data-aim]').forEach(function (b) { b.addEventListener('click', function () { settings.aiModel = b.dataset.aim; saveSettings(); refreshAiLocal(); }); });
  $('#aiLocalRemove').addEventListener('click', function () { if (!LOCAL) return; LOCAL.remove(settings.aiModel || 'light').then(function (st) { renderAiLocal(st); toast('Нейросеть удалена, место освобождено'); }); });

  function aiCall(messages, onDelta) {
    if (settings.ollama) {
      return fetch('http://127.0.0.1:11434/api/chat', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ model: settings.ollamaModel || 'qwen2.5:3b', stream: false, messages: [{ role: 'system', content: AI_SYSTEM }].concat(messages) }) })
        .then(function (r) { if (!r.ok) throw new Error('Ollama ответила ' + r.status + '. Скачай модель: ollama pull ' + (settings.ollamaModel || 'qwen2.5:3b')); return r.json(); })
        .then(function (d) { return (d.message && d.message.content) || ''; });
    }
    if (settings.apiKey) {
      return fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': settings.apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }, body: JSON.stringify({ model: 'claude-sonnet-5-5', max_tokens: 1200, system: AI_SYSTEM, messages: messages }) })
        .then(function (r) { return r.json(); }).then(function (d) { if (d.error) throw new Error(d.error.message); return (d.content || []).map(function (c) { return c.text || ''; }).join(''); });
    }
    return localChat(messages, AI_SYSTEM, 800, onDelta);
  }
  function aiAsk(q, withPage) {
    if (!q) return;
    if (!aiOpen) openAi();
    aiBubble(q, 'me');
    var wait = aiBubble(!settings.ollama && !settings.apiKey && aiLocalState.phase !== 'ready' ? 'Запускаю нейросеть, первый раз это до минуты…' : 'Думаю…', 'ai'); wait.classList.add('wait');
    pageText().then(function (txt) {
      if (!settings.ollama && !settings.apiKey) txt = txt.slice(0, 3500);
      var content = (withPage !== false && txt) ? ('Текст открытой страницы:\n"""\n' + txt + '\n"""\n\nЗадача: ' + q) : q;
      var msgs = aiHistory.slice(-6).concat([{ role: 'user', content: content }]);
      var live = null;
      return aiCall(msgs, function (txt) {
        if (!live) { wait.remove(); live = aiBubble('', 'ai'); live.classList.add('typing'); }
        live.textContent = txt; $('#aiThread').scrollTop = 1e6;
      }).then(function (ans) {
        wait.remove(); if (live) live.remove(); aiBubble(ans || 'Пустой ответ', 'ai');
        aiHistory.push({ role: 'user', content: q }, { role: 'assistant', content: ans });
      });
    }).catch(function (e) {
      wait.remove();
      var m = /Failed to fetch/i.test(e.message) && settings.ollama ? 'Ollama не отвечает. Запусти её и скачай модель: ollama pull ' + (settings.ollamaModel || 'qwen2.5:3b') : 'Не получилось: ' + e.message;
      aiBubble(m, 'ai');
    });
  }
  $('#aiBtn').addEventListener('click', toggleAi);
  $('#aiClose').addEventListener('click', closeAi);
  $$('[data-ai]').forEach(function (b) { b.addEventListener('click', function () { aiAsk(b.dataset.ai); }); });
  $('#aiPanelForm').addEventListener('submit', function (e) { e.preventDefault(); var q = $('#aiPanelInput').value.trim(); $('#aiPanelInput').value = ''; aiAsk(q); });
  $('#aiClear').addEventListener('click', function () { aiHistory = []; $('#aiThread').innerHTML = ''; });

  /* ---------- Командная строка Ctrl+K ---------- */
  var palItems = [], palIdx = 0;
  var COLOR_NAMES = { 'фиолет': '#7C3AED', 'красн': '#D42A25', 'син': '#2563EB', 'малин': '#DB2777', 'розов': '#DB2777', 'оранж': '#EA580C', 'бирюз': '#0891B2', 'зел': '#16A34A', 'жёлт': '#EAB308', 'желт': '#EAB308', 'голуб': '#0EA5E9' };
  function commands() {
    var t = activeTab(), page = t && t.url !== START;
    var c = [
      ['Новая вкладка', 'tab', 'Ctrl+T', function () { newTab(); }, 'new tab открыть'],
      ['Приватная вкладка', 'shield', 'Ctrl+Shift+N', function () { newTab(undefined, { priv: true }); }, 'инкогнито private скрытая'],
      [settings.sleepTabs ? 'Не усыплять вкладки' : 'Усыплять неактивные вкладки', 'clock', '', function () { settings.sleepTabs = !settings.sleepTabs; saveSettings(); toast(settings.sleepTabs ? 'Неактивные вкладки будут засыпать через 15 минут' : 'Вкладки больше не засыпают'); }, 'память ram сон экономия'],
      ['Закрыть вкладку', 'close', 'Ctrl+W', function () { closeTab(activeId); }, 'close'],
      ['Вернуть закрытую вкладку', 'undo', 'Ctrl+Shift+T', reopenTab, 'reopen восстановить'],
      ['Скриншот экрана', 'shot', 'Print Screen', function () { if (api.snapStart) api.snapStart(); }, 'screenshot снимок скрин экрана'],
      ['Скриншот страницы', 'shot', 'Ctrl+Shift+X', screenshot, 'screenshot скрин'],
      ['Перейти в Space', 'space', 'Ctrl+Shift+S', function () { exitSplit(); crackTo(!spaceOn); }, 'дизайн вайбкодинг'],
      [focus.on ? 'Выйти из фокуса' : 'Режим фокуса', 'focus', 'Alt+F', toggleFocus, 'focus помодоро таймер работа учёба'],
      ['Режим чтения', 'book', 'Alt+R', toggleReader, 'reader читать статья'],
      ['Картинка в картинке', 'pip', 'Alt+P', togglePip, 'pip видео окно поверх'],
      ['AI-помощник', 'spark', 'F11', toggleAi, 'ai нейросеть чат'],
      ['Пересказать страницу', 'spark', '', function () { aiAsk('Перескажи эту страницу в 5–7 пунктах.'); }, 'summary кратко'],
      ['Перевести страницу на русский', 'translate', '', function () { if (page) navigate('https://translate.google.com/translate?sl=auto&tl=ru&u=' + encodeURIComponent(t.url)); else toast('Открой страницу'); }, 'translate перевод'],
      [split ? 'Убрать разделение экрана' : 'Разделить экран', 'split', 'Alt+S', toggleSplit, 'split рядом две'],
      ['Найти на странице', 'search', 'Ctrl+F', openFind, 'find поиск'],
      ['Добавить в закладки', 'star', 'Ctrl+D', toggleBookmark, 'bookmark закладка'],
      ['История', 'clock', 'Ctrl+H', function () { openLibrary('history'); }, 'history'],
      ['Закладки', 'star', 'Ctrl+Shift+O', function () { openLibrary('bookmarks'); }, 'bookmarks'],
      ['Загрузки', 'down', 'Ctrl+J', function () { openLibrary('downloads'); }, 'downloads скачанное'],
      ['Настройки', 'gear', 'Ctrl+,', openSettings, 'settings'],
      ['Док приложений', 'dock', 'Ctrl+B', toggleDock, 'dock телеграм дискорд музыка'],
      [shieldCfg.adblock ? 'Выключить блокировщик рекламы' : 'Включить блокировщик рекламы', 'shield', '', function () { shieldCfg.adblock = !shieldCfg.adblock; pushConfig(); renderShield(); toast(shieldCfg.adblock ? 'Блокировщик включён' : 'Блокировщик выключен'); }, 'adblock реклама'],
      [vpnCfg.on ? 'Выключить обход блокировок' : 'Включить обход блокировок', 'globe', '', function () { vpnCfg.on = !vpnCfg.on; saveVpn(vpnCfg.on ? 'Обход блокировок включён' : 'Обход блокировок выключен'); }, 'vpn прокси'],
      ['Новая комната', 'room', '', function () { addRoom(); }, 'room пространство'],
      ['Очистить историю', 'trash', '', function () { writeJSON('inver.history', []); toast('История очищена'); }, 'clear'],
      ['Скрыть названия недавних', 'tab', '', function () { settings.hideRecent = !settings.hideRecent; saveSettings(); }, 'приватность']
    ];
    readJSON('inver.snoozed', []).forEach(function (z) { c.push(['Вернуть отложенную: ' + (z.title || hostOf(z.url)), 'clock', '', function () { wakeSnoozed(z, true); }, 'отложенные snooze']); });
    rooms.forEach(function (r, i) { c.push(['Комната: ' + r.name, 'room', 'Alt+' + (i + 1), function () { switchRoom(r.id); }, 'перейти room']); });
    ACCENTS.forEach(function (a) { c.push(['Тема: ' + a[1].toLowerCase(), 'palette', '', function () { settings.accent = a[0]; saveSettings(); }, 'цвет color акцент']); });
    [['blobs', 'капли'], ['rain', 'дождь'], ['stars', 'звёзды'], ['fire', 'огонь'], ['waves', 'волны']].forEach(function (w) { c.push(['Обои: ' + w[1], 'image', '', function () { settings.wall = w[0]; saveSettings(); }, 'фон wallpaper']); });
    [['inver', 'фирменные'], ['keys', 'клавиатура'], ['retro', 'ретро 8-бит'], ['soft', 'тихие'], ['off', 'без звуков']].forEach(function (w) { c.push(['Звуки: ' + w[1], 'music', '', function () { settings.soundTheme = w[0]; saveSettings(); }, 'sound']); });
    return c.map(function (x) { return { kind: 'cmd', title: x[0], icon: x[1], hint: x[2], run: x[3], keys: (x[0] + ' ' + (x[4] || '')).toLowerCase() }; });
  }
  function palMatch(q, s) {
    if (!q) return 1;
    var words = q.split(/\s+/).filter(Boolean), score = 0;
    for (var i = 0; i < words.length; i++) { var k = s.indexOf(words[i]); if (k < 0) return 0; score += k === 0 || s[k - 1] === ' ' ? 3 : 1; }
    return score;
  }
  function buildPalette(qRaw) {
    var q = qRaw.trim().toLowerCase(), out = [];
    // Особые команды с аргументом
    var tm = /^(тема|цвет)\s+(.+)$/.exec(q);
    var CN = { 'фиолет': 'фиолетовая', 'красн': 'красная', 'син': 'синяя', 'малин': 'малиновая', 'розов': 'розовая', 'оранж': 'оранжевая', 'бирюз': 'бирюзовая', 'зел': 'зелёная', 'жёлт': 'жёлтая', 'желт': 'жёлтая', 'голуб': 'голубая' };
    if (tm) { var shown = {}; Object.keys(COLOR_NAMES).forEach(function (k) { if ((tm[2].indexOf(k) === 0 || k.indexOf(tm[2]) === 0) && !shown[CN[k]]) { shown[CN[k]] = 1; out.push({ kind: 'cmd', title: 'Тема: ' + CN[k], icon: 'palette', hint: '', run: function () { settings.accent = COLOR_NAMES[k]; saveSettings(); }, score: 99 }); } }); }
    var cm = /^(закрыть|закрой)\s+(?:все\s+)?(?:вкладки\s+)?(?:с\s+)?(.{2,})$/.exec(q);
    if (cm) {
      var w = cm[2].trim(), hit = tabs.filter(function (t) { return (t.title + ' ' + hostOf(t.url)).toLowerCase().indexOf(w) >= 0; });
      if (hit.length) out.push({ kind: 'cmd', title: 'Закрыть вкладки с «' + w + '» (' + hit.length + ')', icon: 'close', hint: '', run: function () { hit.forEach(function (t) { closeTab(t.id, true); }); toast('Закрыто вкладок: ' + hit.length); }, score: 99 });
    }
    var am = /^(спроси|ai|ии)\s+(.+)$/.exec(q);
    if (am) out.push({ kind: 'cmd', title: 'Спросить AI: ' + am[2], icon: 'spark', hint: '', run: function () { aiAsk(qRaw.trim().replace(/^\S+\s+/, '')); }, score: 99 });
    commands().forEach(function (c) { var s = palMatch(q, c.keys); if (s) { c.score = s + 2; out.push(c); } });
    tabs.forEach(function (t) {
      if (t.url === START) return;
      var s = palMatch(q, (t.title + ' ' + t.url).toLowerCase());
      if (s && q) out.push({ kind: 'tab', title: t.title || hostOf(t.url), sub: (t.room !== curRoom ? 'Комната «' + (rooms.find(function (r) { return r.id === t.room; }) || {}).name + '» · ' : '') + hostOf(t.url), host: hostOf(t.url), hint: 'Вкладка', run: function () { activate(t.id); }, score: s + 1 });
    });
    if (q.length > 1) {
      var seen = {};
      bookmarks().concat(readJSON('inver.history', [])).forEach(function (h) {
        if (seen[h.url] || out.length > 60) return;
        var s = palMatch(q, ((h.title || '') + ' ' + h.url).toLowerCase());
        if (s) { seen[h.url] = 1; out.push({ kind: 'url', title: h.title || hostOf(h.url), sub: hostOf(h.url), host: hostOf(h.url), hint: '', run: function () { openFromPalette(h.url); }, score: s }); }
      });
    }
    out.sort(function (a, b) { return b.score - a.score; });
    if (q) {
      var looksUrl = /^[^\s]+\.[a-z]{2,}(\/|:|$)/i.test(q) || /^(https?:\/\/|localhost)/i.test(q);
      var web = { kind: 'web', title: looksUrl ? 'Открыть ' + qRaw.trim() : 'Искать «' + qRaw.trim() + '»', icon: looksUrl ? 'globe' : 'search', hint: '', run: function () { openFromPalette(qRaw.trim()); } };
      // Поиск в сети идёт первым, только если это адрес или нет точных совпадений среди команд
      var nWords = q.split(/\s+/).filter(Boolean).length, strong = 0;
      while (strong < out.length && strong < 4 && out[strong].score >= Math.min(99, nWords * 3 + 2)) strong++;
      out.splice(looksUrl ? 0 : strong, 0, web);
    }
    return out.slice(0, 40);
  }
  function openFromPalette(u) { var t = activeTab(); if (t && t.url === START) navigate(u); else newTab(u); }
  function renderCmd() {
    var list = $('#palList');
    list.innerHTML = '';
    palItems.forEach(function (it, i) {
      var r = el('div', 'pal-row' + (i === palIdx ? ' on' : ''));
      r.setAttribute('role', 'option');
      var ic = it.host ? siteIcon(it.host, 'pal-ico') : el('span', 'pal-ico sv', svg(it.icon));
      r.appendChild(ic);
      var m = el('div', 'pal-main'); m.appendChild(el('span', 'pal-title', esc(it.title))); if (it.sub) m.appendChild(el('span', 'pal-sub', esc(it.sub)));
      r.appendChild(m);
      if (it.hint) r.appendChild(el('kbd', 'pal-kbd', esc(it.hint)));
      r.addEventListener('mousemove', function () { if (palIdx !== i) { palIdx = i; $$('#palList .pal-row').forEach(function (x, j) { x.classList.toggle('on', j === i); }); } });
      r.addEventListener('click', function () { runPal(i); });
      list.appendChild(r);
    });
    if (!palItems.length) list.appendChild(el('p', 'pal-empty', 'Ничего не нашлось'));
  }
  function runPal(i) { var it = palItems[i]; if (!it) return; closePalette(); setTimeout(function () { it.run(); }, 30); }
  function openPalette() {
    closePops(); closeSettings();
    $('#palInput').value = ''; palItems = buildPalette(''); palIdx = 0; renderCmd();
    showEl($('#cmdk')); setTimeout(function () { $('#palInput').focus(); }, 20);
    Sound.blip(820, 0, 0.04);
  }
  function closePalette() { hideEl($('#cmdk'), 160); }
  function togglePalette() { if (isOpen($('#cmdk'))) closePalette(); else openPalette(); }
  $('#palInput').addEventListener('input', function (e) { palItems = buildPalette(e.target.value); palIdx = 0; renderCmd(); });
  $('#palInput').addEventListener('keydown', function (e) {
    if (e.key === 'ArrowDown') { e.preventDefault(); palIdx = Math.min(palItems.length - 1, palIdx + 1); renderCmd(); scrollPal(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); palIdx = Math.max(0, palIdx - 1); renderCmd(); scrollPal(); }
    if (e.key === 'Enter') { e.preventDefault(); runPal(palIdx); }
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closePalette(); }
  });
  function scrollPal() { var r = $$('#palList .pal-row')[palIdx]; if (r) r.scrollIntoView({ block: 'nearest' }); }
  $('#cmdk .modal-backdrop').addEventListener('click', closePalette);
  $('#palBtn').addEventListener('click', openPalette);


  /* ---------- Спящие вкладки: неактивные выгружаются из памяти ---------- */
  function sleepTick() {
    if (!settings.sleepTabs) return;
    var now = Date.now();
    tabs.forEach(function (t) {
      if (!t.view || t.id === activeId || t.media || t.lazy || t.url === START || t.priv) return;
      if (split && (t.id === split.a || t.id === split.b)) return;
      if (!t.lastActive || now - t.lastActive < 15 * 60000) return;
      try { t.view.remove(); } catch (e) {}
      t.view = null; t.lazy = true; t.asleep = true; t.loading = false;
    });
    renderTabs();
  }

  /* ---------- Отложенные вкладки: закрываются и сами возвращаются в нужное время ---------- */
  function snooze(t, ms) {
    var list = readJSON('inver.snoozed', []);
    var at = Date.now() + ms;
    list.push({ url: t.url, title: t.title, room: t.room, at: at });
    writeJSON('inver.snoozed', list);
    closeTab(t.id, true);
    var d = new Date(at);
    toast('Вкладка вернётся ' + (d.toDateString() === new Date().toDateString() ? 'сегодня' : 'завтра') + ' в ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2));
    Sound.blip(620, 0, 0.04);
  }
  function wakeSnoozed(z, now) {
    writeJSON('inver.snoozed', readJSON('inver.snoozed', []).filter(function (x) { return !(x.url === z.url && x.at === z.at); }));
    if (rooms.some(function (r) { return r.id === z.room; }) && z.room !== curRoom) switchRoom(z.room);
    newTab(z.url);
    if (!now) { toast('Вернулась отложенная вкладка: ' + (z.title || hostOf(z.url))); Sound.chime(true); }
  }
  function snoozeTick() { var now = Date.now(); readJSON('inver.snoozed', []).forEach(function (z) { if (z.at <= now) wakeSnoozed(z); }); }

  /* ---------- Свет за курсором на стекле и наклон шара ---------- */
  (function () {
    var cur = null, raf = 0, mx = 0, my = 0;
    document.addEventListener('pointermove', function (e) {
      mx = e.clientX; my = e.clientY;
      if (raf) return;
      raf = requestAnimationFrame(function () {
        raf = 0;
        if (settings.perf === 'eco') return;
        var t = document.elementFromPoint(mx, my);
        var g = t && t.closest ? t.closest('.glass, .widget, .pop, .sheet, .pal, #aiPanel, #dock, .favs') : null;
        if (cur && cur !== g) cur.classList.remove('lit');
        cur = g;
        if (g) { var r = g.getBoundingClientRect(); g.style.setProperty('--mx', (mx - r.left) + 'px'); g.style.setProperty('--my', (my - r.top) + 'px'); g.classList.add('lit'); }
        var orb = $('#orb');
        if (orb && !body.classList.contains('has-page')) {
          var o = orb.getBoundingClientRect(), cx = o.left + o.width / 2, cy = o.top + o.height / 2;
          var dx = Math.max(-1, Math.min(1, (mx - cx) / 500)), dy = Math.max(-1, Math.min(1, (my - cy) / 400));
          orb.style.setProperty('--tx', (-dy * 9).toFixed(2) + 'deg'); orb.style.setProperty('--ty', (dx * 11).toFixed(2) + 'deg');
          orb.style.setProperty('--sx', (dx * 18).toFixed(1) + 'px'); orb.style.setProperty('--sy', (dy * 14).toFixed(1) + 'px');
        }
      });
    }, { passive: true });
    document.addEventListener('pointerleave', function () { var orb = $('#orb'); if (orb) { orb.style.setProperty('--tx', '0deg'); orb.style.setProperty('--ty', '0deg'); } });
  })();

  /* Приветствие по времени суток */
  function greet() { var h = new Date().getHours(); return h < 5 ? 'Доброй ночи' : h < 12 ? 'Доброе утро' : h < 18 ? 'Добрый день' : 'Добрый вечер'; }


  /* ---------- Автообновления ---------- */
  function updHint(text) { var h = $('#updHint'); if (h) h.textContent = text; }
  function refreshUpd() {
    if (!api.updateStatus) return;
    api.updateStatus().then(function (s) {
      if (!s.configured) return updHint('Версия ' + s.version + '. Автообновления включатся, когда будет подключено хранилище обновлений.');
      updHint(s.pending ? 'Скачана версия ' + s.pending.version + '. Включится после перезапуска.' : 'Версия ' + s.version + '. Обновления ставятся сами, ничего делать не нужно.');
    });
  }
  if (api.onUpdateReady) api.onUpdateReady(function (info) {
    refreshUpd();
    toast('Inver обновился до ' + info.version, 'Перезапустить', function () { api.updateRestart(); });
  });
  $('#updCheck').addEventListener('click', function () {
    if (!api.updateCheck) return;
    updHint('Проверяю…');
    api.updateCheck().then(function (r) {
      if (r.ready) { updHint('Скачана версия ' + r.ready.version + '. Включится после перезапуска.'); toast('Inver обновился до ' + r.ready.version, 'Перезапустить', function () { api.updateRestart(); }); }
      else if (r.latest) updHint('У тебя последняя версия ' + r.version + '.');
      else if (r.reason === 'not-configured') refreshUpd();
      else updHint('Не получилось проверить: ' + (r.error || r.reason || 'нет связи') + '. Попробую сам позже.');
    });
  });

  /* ---------- Запуск ---------- */
  function initFeatures() {
    renderRooms();
    applyWall();
    applySoundTheme();
    applyWidgets();
    tickClock(); setInterval(tickClock, 15000);
    weather(); setInterval(function () { weather(); }, 20 * 60000);
    pollMedia(); setInterval(pollMedia, 2500);
    setInterval(sleepTick, 60000); snoozeTick(); setInterval(snoozeTick, 30000);
    $('#spaceBtn').addEventListener('click', exitSplit, true);
    renderPageTools();
    refreshUpd();
    // Alt+цифра — комнаты, когда фокус в интерфейсе (внутри страниц работают пункты меню)
  }
  // Применяем новые настройки вместе со старыми
  var _applySettings = applySettings;
  applySettings = function () {
    _applySettings();
    if (!$('#wallImg')) return;
    applyWall(); applySoundTheme(); applyWidgets();
    $$('[data-set="siteTint"]').forEach(function (i) { i.checked = !!settings.siteTint; });
    var t = activeTab(); if (t) applyTint(t);
  };

  /* ---------- Заставка ---------- */
  function splash() {
    var el = $('#splash');
    if (!settings.splash) { el.classList.add('gone'); playStart(); return; }
    var cells = [[26, 2, 60], [50, 2, 90], [74, 2, 120], [98, 2, 260, 1], [50, 26, 40], [50, 74, 40], [26, 98, 120], [50, 98, 90], [74, 98, 60]];
    var g = el.querySelector('.pxs');
    cells.forEach(function (c) {
      var r = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      r.setAttribute('x', c[0]); r.setAttribute('y', c[1]); r.setAttribute('width', 20); r.setAttribute('height', 20); r.setAttribute('rx', 5);
      r.style.transitionDelay = c[2] + 'ms';
      if (c[3]) r.setAttribute('class', 'acc');
      g.appendChild(r);
    });
    var at = function (ms, fn) { setTimeout(fn, ms); };
    at(150, function () { el.classList.add('s1'); Sound.blip(660, 0, 0.1); });
    at(600, function () { el.classList.add('s2'); [0.04, 0.04, 0.06, 0.06, 0.09, 0.09, 0.12, 0.12, 0.26].forEach(function (d, i) { Sound.blip(520 + i * 70, d, 0.06); }); });
    at(1400, function () { el.classList.remove('s1', 's2'); el.classList.add('s3'); Sound.whoosh(true); });
    at(2050, function () { el.classList.add('s4'); Sound.chime(true); });
    at(3050, function () { el.classList.add('s5'); });
    at(3750, function () { el.classList.add('gone'); });
    at(3250, playStart);
  }

  /* ---------- Горячие клавиши ---------- */
  api.onShortcut(function (name, arg) {
    if (name === 'space') toggleSpace();
    if (name === 'screenshot') screenshot();
    if (name === 'new-tab') newTab();
    if (name === 'close-tab') closeTab(activeId);
    if (name === 'focus-address') { $('#addr').focus(); $('#addr').select(); }
    if (name === 'reload') $('#reload').click();
    if (name === 'settings') (isOpen($('#settings')) ? closeSettings() : openSettings());
    if (name === 'open-url') newTab(arg);
    if (name === 'panel') togglePanel();
    if (name === 'find') openFind();
    if (name === 'history') openLibrary('history');
    if (name === 'bookmarks') openLibrary('bookmarks');
    if (name === 'downloads') openLibrary('downloads');
    if (name === 'bookmark') toggleBookmark();
    if (name === 'reopen') reopenTab();
    if (name === 'palette') togglePalette();
    if (name === 'private') newTab(undefined, { priv: true });
    if (name === 'pip') togglePip();
    if (name === 'reader') toggleReader();
    if (name === 'ai') toggleAi();
    if (name === 'focus') toggleFocus();
    if (name === 'split') toggleSplit();
    if (name === 'room') switchRoomByIndex(Number(arg));
    if (name === 'space') exitSplit();
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { closeSettings(); closePops(); closeLibrary(); if (isOpen($('#dockForm'))) hideEl($('#dockForm'), 170); else if (!body.classList.contains('panel-open')) closeDock(); if (isOpen($('#findBar'))) closeFind(); } });

  /* ---------- Старт ---------- */
  applySettings();
  Pixels.isCovered = function () { var c = document.body.classList; return c.contains('has-page') && !c.contains('space-vis'); };
  Pixels.init($('#bg'));
  renderRecent();
  renderFavs();
  renderDock();
  renderVpn();
  renderDlBtn();
  pushConfig();
  initFeatures();
  if (!restoreSession()) newTab();
  $('#addr').blur();
  splash();
})();
