// Мост между интерфейсом и системой: только то, что реально нужно интерфейсу
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('inver', {
  platform: process.platform,
  win: (action) => ipcRenderer.send('win', action),
  onWinState: (cb) => ipcRenderer.on('win-state', (_e, s) => cb(s)),
  onShortcut: (cb) => ipcRenderer.on('shortcut', (_e, name, arg) => cb(name, arg)),
  saveShot: (dataUrl) => ipcRenderer.invoke('save-shot', dataUrl),
  showFile: (file) => ipcRenderer.send('show-file', file),
  copy: (text) => ipcRenderer.send('copy', text),
  config: (cfg) => ipcRenderer.invoke('config', cfg),
  proxyTest: (proxy) => ipcRenderer.invoke('proxy-test', proxy),
  shieldAssets: () => ipcRenderer.invoke('shield-assets'),
  onBlocked: (cb) => ipcRenderer.on('blocked', (_e, id, n) => cb(id, n)),
  onDownload: (cb) => ipcRenderer.on('download', (_e, d) => cb(d)),
  dlAction: (id, action, file) => ipcRenderer.send('dl-action', id, action, file),
  importSources: () => ipcRenderer.invoke('import-sources'),
  siteIcon: (host) => ipcRenderer.invoke('site-icon', host),
  siteIconHint: (host, urls) => ipcRenderer.invoke('site-icon-hint', host, urls),
  snapConfig: (cfg) => ipcRenderer.invoke('snap-config', cfg),
  updateCheck: () => ipcRenderer.invoke('update-check'),
  updateStatus: () => ipcRenderer.invoke('update-status'),
  updateRestart: () => ipcRenderer.send('update-restart'),
  onUpdateReady: (cb) => ipcRenderer.on('update-ready', (_e, i) => cb(i)),
  aiLocal: {
    ensure: (m) => ipcRenderer.invoke('ai-local-ensure', m),
    status: (m) => ipcRenderer.invoke('ai-local-status', m),
    chat: (id, m, messages, system, maxTokens) => ipcRenderer.invoke('ai-local-chat', id, m, messages, system, maxTokens),
    onDelta: (cb) => ipcRenderer.on('ai-local-delta', (_e, id, text) => cb(id, text)),
    remove: (m) => ipcRenderer.invoke('ai-local-remove', m),
    onState: (cb) => ipcRenderer.on('ai-local-state', (_e, s) => cb(s))
  },
  snapStart: () => ipcRenderer.send('snap-start'),
  onSnapSaved: (cb) => ipcRenderer.on('snap-saved', (_e, f) => cb(f))
});
